# QR Pro Max — DOCUMENTACION.md

Este archivo debe permanecer en la raíz del proyecto, fuera de `app/`.

## 1. Proyecto

- Nombre: QR Pro Max
- Package: `com.alehei.qrpromax`
- Kotlin + Jetpack Compose
- minSdk: API 26
- targetSdk: 35
- IDE: AIDE / JStudio

QR Pro Max permite:
- Crear códigos QR de diferentes tipos.
- Personalizar módulos, ojos, colores, corrección de errores y logos.
- Verificar internamente los códigos generados.
- Comprobar contraste.
- Guardar QR como PNG, JPG o SVG.
- Compartir códigos QR.
- Escanear códigos QR y códigos de barras mediante cámara.
- Escanear códigos QR y códigos de barras desde imágenes de la galería.
- Interpretar inteligentemente el contenido escaneado.
- Ejecutar acciones según el tipo de contenido.
- Elegir y conservar diferentes estilos del scanner.
- Mostrar publicidad mediante Google AdMob.

## 2. Estructura

QRProMax/
├── DOCUMENTACION.md
├── app/
│   └── src/main/
│       ├── AndroidManifest.xml
│       ├── java/com/alehei/qrpromax/
│       │   ├── MainActivity.kt
│       │   ├── model/
│       │   │   ├── QRConfig.kt
│       │   │   ├── QRType.kt
│       │   │   ├── QRSaveFormat.kt
│       │   │   └── ScannerStyle.kt
│       │   ├── qr/
│       │   │   ├── QRGenerator.kt
│       │   │   ├── QRRenderer.kt
│       │   │   ├── QRVerifier.kt
│       │   │   ├── QRContrast.kt
│       │   │   ├── QRScannerAnalyzer.kt
│       │   │   ├── QRImageDecoder.kt
│       │   │   ├── QRScanParser.kt
│       │   │   └── WifiConnector.kt
│       │   └── ui/
│       │       ├── screens/
│       │       │   ├── QRConfigScreen.kt
│       │       │   ├── QRResultScreen.kt
│       │       │   ├── QRScannerScreen.kt
│       │       │   ├── QRScanResultScreen.kt
│       │       │   ├── QRSettingsScreen.kt
│       │       │   ├── QRAboutScreen.kt
│       │       │   └── QRSuggestScreen.kt
│       │       └── components/
│       │           ├── QRTypeTab.kt
│       │           └── ColorPicker.kt
│       └── res/
│           ├── drawable/
│           └── ...
├── build.gradle.kts
└── settings.gradle.kts

## 3. Dependencias

implementation("com.google.zxing:core:3.5.3")
implementation("androidx.camera:camera-camera2:1.4.2")
implementation("androidx.camera:camera-lifecycle:1.4.2")
implementation("androidx.camera:camera-view:1.4.2")
implementation("io.coil-kt:coil-compose:2.7.0")
implementation("com.google.android.gms:play-services-ads-lite:25.0.0")

AdMob usa actualmente Google Mobile Ads SDK Lite. No mezclar `play-services-ads` con `play-services-ads-lite`.

## 4. Permisos

En `app/src/main/AndroidManifest.xml`:

<uses-permission android:name="android.permission.CAMERA" />

El permiso se solicita cuando el usuario utiliza el scanner.

## 5. Modelos

### QRType.kt

Tipos actuales:

URL
TEXT
WIFI
CONTACT
EMAIL
PHONE
SMS
LOCATION

Cada tipo tiene título, icono y comportamiento específico de generación y escaneo.

## 6. QRConfig.kt

Centraliza contenido y personalización.

Contenido:
- URL
- Texto
- Teléfono
- SMS
- Ubicación
- Wi-Fi
- Contacto
- Email

Wi-Fi:
- wifiName
- wifiPassword
- wifiSecurity
- wifiHidden

Contacto:
- contactFirstName
- contactLastName
- contactPhone
- contactEmail
- contactCompany
- contactAddress
- contactWebsite

Email:
- emailAddress
- emailSubject
- emailMessage

Ubicación:
- latitude
- longitude
- locationName

Diseño:
- foregroundColor
- backgroundColor
- moduleStyle
- eyeStyle
- errorCorrection
- logoEnabled
- logoResId
- logoAssetName
- logoSize
- scannerStyle

El diseño se conserva al cambiar de tipo QR.

## 7. Cambio de tipo QR

Al seleccionar otro tipo desde QRConfigScreen.kt se limpian los datos específicos del tipo anterior mediante una función equivalente a:

clearQRContent(config, newType)

Se limpian los campos de contenido de URL, texto, teléfono, SMS, ubicación, Wi-Fi, contacto y email.

Se conservan las opciones de diseño:
- foregroundColor
- backgroundColor
- moduleStyle
- eyeStyle
- errorCorrection
- logo
- logoSize
- scannerStyle

Objetivo: evitar que información del QR anterior aparezca accidentalmente al cambiar de tipo.

## 8. ModuleStyle

Estilos actuales:

SQUARE
ROUNDED
DOTS
HEART
STAR
TRIANGLE
HEXAGON
CLOVER
PIECE
MSG
LIKE

Procesados por `qr/QRRenderer.kt`.

## 9. EyeStyle

Estilos actuales:

SQUARE
ROUNDED
CIRCLE
OCTAGON
FLOWER
BOW
PUZZLE

Los ojos son independientes del estilo de módulo.

## 10. ErrorCorrection

Niveles:

LOW
MEDIUM
QUARTILE
HIGH

La corrección de errores es especialmente importante cuando se utiliza un logo. Un logo demasiado grande puede perjudicar la lectura.

## 11. Logos

Los recursos Android están en:

app/src/main/res/drawable/

También existen recursos SVG para exportación:

assets/logos/

Logos previstos:
- Android
- Apple
- Facebook
- Pinterest
- X
- WhatsApp
- YouTube

Puede haber recursos antiguos que no estén en uso.

## 12. Cómo agregar un nuevo logo

1. Agregar `logo_nuevo.xml` a `res/drawable/`.
2. Agregar la opción en `ui/screens/QRConfigScreen.kt`.
3. Configurar `logoEnabled`, `logoResId`, `logoAssetName` y `logoSize`.
4. Si se exporta a SVG, agregar el SVG correspondiente a `assets/logos/`.
5. Comprobar `QRRenderer.kt`.

Ejemplo:

config.copy(
    logoEnabled = true,
    logoResId = R.drawable.logo_pinterest,
    logoAssetName = "pinterest"
)

Agregar el XML al drawable no basta: debe existir una opción visible en la UI.

## 13. Colores de los logos

Los logos personalizados deben conservar sus colores originales.

No aplicar accidentalmente el tintado usado por los iconos de interfaz o scanner.

## 14. Generación

Flujo:

QRConfigScreen
    ↓
QRGenerator
    ↓
QRRenderer
    ↓
Bitmap
    ↓
QRResultScreen

QRGenerator prepara el contenido y QRRenderer la representación visual.

## 15. Renderer

QRRenderer.kt controla:
- Módulos
- Ojos
- Colores
- Corrección de errores
- Margen
- Logo
- Tamaño del logo

Regla: no sacrificar legibilidad por estética.

## 16. Verificación

QRVerifier.kt intenta decodificar internamente el QR generado usando diferentes tamaños.

La verificación es una comprobación interna, no una garantía universal. Un QR que funciona con ZXing puede comportarse diferente con otros lectores, cámaras o condiciones físicas.

Siempre realizar pruebas reales.

## 17. Contraste

QRContrast.kt calcula luminancia relativa y contraste.

La comprobación actual considera aceptable una relación de contraste de 3.0 o superior.

Un contraste calculado como bueno no sustituye una prueba física.

## 18. Pantalla de resultado generado

Archivo:

ui/screens/QRResultScreen.kt

Muestra:
- Tu código QR
- Tipo de QR
- Código generado
- Guardar
- Compartir
- Editar QR

También muestra mensajes según verificación y contraste:
- QR verificado 😃
- Este QR podría no funcionar 😟
- Este QR es poco legible 🫠

## 19. Guardado del QR

El botón Guardar incluye un selector de formato.

Formatos:
- PNG
- JPG
- SVG

Modelo:

QRSaveFormat.kt

El usuario selecciona formato y pulsa Guardar.

## 20. Exportación SVG

El SVG es una exportación vectorial real, no una imagen rasterizada dentro de SVG.

Reproduce:
- Módulos
- Ojos
- Colores
- Logo

Los logos SVG pueden incluir formas, paths, gradientes y colores originales.

No modificar la geometría de módulos u ojos para solucionar exclusivamente un problema del logo SVG.

## 21. Compartir

La pantalla de resultado tiene un botón Compartir para compartir el QR generado.

También existen funciones para compartir texto y la aplicación desde otros apartados.

## 22. Scanner

Archivo principal:

ui/screens/QRScannerScreen.kt

Utiliza CameraX.

El scanner permite detectar:
- Códigos QR
- EAN-13
- EAN-8
- UPC-A
- UPC-E
- Code 128
- Code 39
- Code 93
- ITF
- Codabar

Flujo:

Cámara
 ↓
PreviewView
 ↓
ImageAnalysis
 ↓
QRScannerAnalyzer
 ↓
ZXing
 ↓
QRScanResultScreen

El analyzer:
- usa el plano Y;
- maneja rowStride;
- maneja pixelStride;
- utiliza HybridBinarizer;
- utiliza TRY_HARDER;
- permite múltiples formatos QR y códigos de barras;
- utiliza GenericMultipleBarcodeReader;
- acepta únicamente un resultado válido por frame;
- rechaza frames en los que se detectan dos o más códigos;
- requiere confirmar el mismo resultado en dos frames consecutivos;
- deja de procesar después de confirmar un resultado.

Regla de lectura:

1 código detectado
    ↓
confirmación en frames consecutivos
    ↓
resultado

2 o más códigos detectados
    ↓
se descarta el frame
    ↓
el scanner continúa esperando

Esto evita que el scanner seleccione arbitrariamente uno de varios códigos visibles.

## 23. Marcos del scanner

Geometría normalizada:

viewport: 1450 × 1450
área QR: 1050 × 1050
offset: 200 px

200 + 1050 + 200 = 1450

No cambiar arbitrariamente porque la línea de escaneo depende de estas proporciones.

## 24. Línea de escaneo

Archivo:

res/drawable/scan_line.xml

Viewport:

966 × 42

Se escala respecto al área QR de 1050 px.

Constantes:

FRAME_SIZE_PX = 1450f
QR_AREA_SIZE_PX = 1050f
QR_OFFSET_PX = 200f

## 25. Controles del scanner

Vectores:
- icon_back.xml
- icon_flashlight.xml
- icon_frame.xml
- icon_scan_image.xml

Controles:
- Foto
- Luz
- Marco
- Volver

La linterna utiliza CameraX `enableTorch()` y el icono cambia cuando está activa.

El selector de marcos permanece abierto al seleccionar un diseño. Pulsar Marco nuevamente confirma/cierra.

## 26. Persistencia del estilo del scanner

Se utiliza SharedPreferences:

qr_pro_max_prefs

El estilo seleccionado se carga al iniciar y se mantiene entre sesiones.

También se conserva en:

currentConfig.scannerStyle

## 27. Galería

Se utiliza:

ActivityResultContracts.GetContent()

con:

image/*

La galería permite analizar imágenes que contengan:
- Códigos QR
- Códigos de barras compatibles con ZXing

Flujo:

Foto
 ↓
Galería
 ↓
Bitmap
 ↓
QRImageDecoder
 ↓
ZXing
 ↓
QRScanResultScreen

QRImageDecoder utiliza múltiples formatos compatibles con ZXing.

La detección desde galería puede tardar más que la detección de QR simples debido al procesamiento de imágenes y a los diferentes intentos de decodificación.

## 28. Bitmap de galería

Cuando sea necesario convertir a Bitmap de software:

bitmap.copy(
    Bitmap.Config.ARGB_8888,
    false
)

Es importante antes de operaciones como getPixels() cuando el Bitmap original no es mutable/software.

## 29. Parser inteligente

Archivo:

qr/QRScanParser.kt

Convierte contenido en:

QRScanData

Tipos:
- URL
- TEXT
- WIFI
- CONTACT
- EMAIL
- PHONE
- SMS
- LOCATION

`rawContent` debe conservar siempre el contenido original.

`value1`, `value2` y `value3` cambian de significado según el tipo.

## 30. Detección de URLs

Reconocer:

https://google.com
http://google.com
www.google.com
google.com
google.com/ruta

Cuando no existe esquema se puede normalizar internamente con `https://`.

No modificar `rawContent`.

Ejemplo:
rawContent = google.com

Puede abrirse como:
https://google.com

Pero al copiar debe conservar:
google.com

## 31. Contactos

El generador utiliza vCard.

Campos:
- FN
- TEL
- EMAIL
- ORG
- ADR
- URL

El resultado debe evitar duplicar el nombre.

Acción principal:

Guardar contacto

El parser puede ampliarse para múltiples teléfonos, múltiples emails y más campos vCard.

## 32. Resultado de escaneo

Archivo:

ui/screens/QRScanResultScreen.kt

Acciones:

URL        → Abrir enlace
Teléfono   → Llamar
Email      → Enviar email
SMS        → Enviar SMS
Ubicación  → Abrir mapa
Wi-Fi      → Copiar datos Wi-Fi
Contacto   → Guardar contacto
Texto      → Copiar texto

Los contenidos largos usan maxLines y TextOverflow.Ellipsis sin modificar rawContent.

## 33. Wi-Fi

El contenido Wi-Fi se interpreta y muestra de forma estructurada.

Se conserva la información original.

Puede utilizarse `WifiConnector.kt` para funciones relacionadas con Wi-Fi según la implementación actual.

## 34. Navegación de MainActivity

Estados principales:

currentConfig
currentBitmap
showResult
showScanner
showSettings
showAbout
showSuggest
scannedContent
qrContrastGood
qrVerified

Flujo:

Configuración
    │
    ├── Generar → Resultado generado
    │
    └── Escanear → Scanner → Resultado escaneado

También existen rutas para:
- Configuración
- Ajustes
- Acerca de
- Sugerir mejora

## 35. Ajustes

Archivo:

ui/screens/QRSettingsScreen.kt

Opciones:
- Sugerir una mejora
- Compartir QR Pro Max
- Calificar en Google Play
- Acerca de QR Pro Max

También:
- QR Pro Max
- Versión 1.0.0

No referenciar drawables inexistentes.

## 36. Sugerir una mejora

Archivo:

ui/screens/QRSuggestScreen.kt

Permite enviar sugerencias.

La implementación actual utiliza un correo específico para recibir sugerencias y puede incluir una imagen adjunta cuando corresponde.

La lógica de envío está integrada con MainActivity.kt.

## 37. Acerca de

Archivo:

ui/screens/QRAboutScreen.kt

Muestra:
- QR Pro Max
- Versión 1.0.0
- Sobre la aplicación
- Licencia
- Créditos

Descripción:

QR Pro Max es una herramienta completa para crear, guardar, compartir y escanear códigos QR de diferentes tipos.

Licencia indicada actualmente:

QR Pro Max es software propietario.

También se informa que utiliza bibliotecas de código abierto para generación y lectura de códigos QR.

## 38. AdMob

QR Pro Max integra:

Google Mobile Ads SDK Lite

Dependencia:

implementation("com.google.android.gms:play-services-ads-lite:25.0.0")

El banner funciona actualmente y la lógica permanece integrada en la pantalla donde se utiliza.

Si posteriormente se usan anuncios en varias pantallas, puede extraerse un componente reutilizable.

## 39. AdMob y tiendas Android

Se contempla distribución mediante:
- Google Play
- OPPO App Market
- Otras plataformas Android que resulten adecuadas.

El package debe permanecer:

com.alehei.qrpromax

No crear un package diferente por tienda salvo razón técnica real.

## 40. Firmado

Usar siempre la misma clave de firma para futuras actualizaciones.

Conservar de forma segura:
- Keystore
- Alias
- Contraseña del keystore
- Contraseña del alias

No perder la clave de producción.

## 41. Estado de Play Console

La aplicación está siendo preparada para Google Play.

La cuenta de desarrollador requiere completar los procesos de verificación correspondientes.

Para cuentas personales nuevas pueden existir requisitos de prueba cerrada antes de producción.

Estos requisitos pertenecen a Play Console y no al funcionamiento técnico de la app.

## 42. Pruebas de generación

[ ] URL
[ ] Texto
[ ] Wi-Fi
[ ] Contacto
[ ] Email
[ ] Teléfono
[ ] SMS
[ ] Ubicación

## 43. Pruebas de personalización

[ ] Colores
[ ] Módulos
[ ] Ojos
[ ] Corrección de errores
[ ] Logos
[ ] Tamaño de logo
[ ] Todos los estilos actuales

Probar combinaciones importantes con:
- QRVerifier
- scanner de QR Pro Max
- otro lector QR
- cámara física

## 44. Pruebas de exportación

[ ] PNG
[ ] JPG
[ ] SVG
[ ] QR sin logo
[ ] QR con logo
[ ] Colores personalizados
[ ] Módulos personalizados
[ ] Ojos personalizados

Para SVG:
[ ] Abre correctamente
[ ] Es realmente vectorial
[ ] Conserva colores
[ ] Conserva logo
[ ] Conserva tamaño
[ ] Conserva módulos
[ ] Conserva ojos

## 45. Pruebas del scanner

### Cámara

[ ] Permiso de cámara
[ ] QR estándar
[ ] QR personalizado
[ ] QR con logo
[ ] Código EAN-13
[ ] Código EAN-8
[ ] Código UPC-A
[ ] Código UPC-E
[ ] Code 128
[ ] Code 39
[ ] Code 93
[ ] ITF
[ ] Codabar
[ ] Un solo código visible
[ ] Dos códigos visibles
[ ] QR + código de barras visibles
[ ] Linterna
[ ] Marcos
[ ] Línea de escaneo
[ ] Volver
[ ] Cambio de estilo
[ ] Persistencia del estilo

### Galería

[ ] Imagen con QR
[ ] Imagen con código de barras
[ ] Imagen con código EAN
[ ] Imagen con UPC
[ ] Imagen con Code 128
[ ] Imagen con varios códigos
[ ] Imagen sin código
[ ] Imagen de alta resolución
[ ] Imagen con código pequeño

### Comportamiento ante múltiples códigos

[ ] No seleccionar arbitrariamente un código
[ ] Rechazar cuando hay dos o más códigos detectados
[ ] Continuar buscando después de un frame ambiguo
[ ] Escanear cuando queda un único código
[ ] Confirmar el mismo código en frames consecutivos

## 46. Pruebas de resultados

[ ] URL
[ ] Texto
[ ] Wi-Fi
[ ] Contacto
[ ] Email
[ ] Teléfono
[ ] SMS
[ ] Ubicación
[ ] Copiar
[ ] Abrir enlace
[ ] Llamar
[ ] Email
[ ] SMS
[ ] Mapa
[ ] Guardar contacto

## 47. Pruebas de UI

[ ] Tema claro
[ ] Tema oscuro
[ ] Iconos correctamente tintados
[ ] Texto legible
[ ] Botones
[ ] Dropdown Guardar
[ ] Settings
[ ] About
[ ] Suggest
[ ] Scanner
[ ] Resultado

Los iconos de interfaz deben respetar el color del texto.

Los logos del QR deben conservar sus colores originales.

## 48. Status bar

Los iconos de la barra de estado deben ser visibles tanto en tema claro como oscuro.

Si se utiliza WindowCompat.getInsetsController(), la apariencia debe corresponder al tema actual.

No fijar permanentemente iconos blancos o negros si se soportan ambos temas.

## 49 Si algo falla.

### Cámara no detecta QR o código de barras

Revisar:
QRScannerScreen.kt
QRScannerAnalyzer.kt

Comprobar:
ImageAnalysis
plano Y
rowStride
pixelStride
TRY_HARDER
POSSIBLE_FORMATS
GenericMultipleBarcodeReader

Si hay varios códigos visibles, el scanner debe rechazarlos y continuar buscando.

No modificar el comportamiento para seleccionar arbitrariamente uno de varios códigos.

### Logo no aparece

Revisar:
res/drawable/
QRConfigScreen.kt
QRConfig.kt
QRRenderer.kt

Si es SVG:
assets/logos/
logoAssetName

### Logo aparece con color incorrecto

Revisar tintado en QRRenderer.kt y comprobar que no se aplique ColorFilter.tint() a un logo que debe conservar sus colores.

### QR con logo no se lee

Revisar:
QRRenderer.kt
QRVerifier.kt
QRContrast.kt

Reducir logoSize si es necesario y probar una corrección de errores mayor.

### Imagen de galería no se lee

Revisar:
QRImageDecoder.kt

Comprobar:
Bitmap.Config.ARGB_8888 cuando sea necesario.
POSSIBLE_FORMATS.
TRY_HARDER.
Métodos de binarización utilizados.

Comprobar primero con una imagen donde exista un único código claramente visible.

### URL aparece como texto

Revisar:
QRScanParser.kt

Comprobar:
https://
http://
www.
dominio sin esquema
dominio/ruta

### Resultado repetido

Revisar:
QRScannerAnalyzer.kt
QRScannerScreen.kt
QRScanResultScreen.kt

Comprobar que el analyzer deje de procesar después de encontrar un resultado y que rawContent no se duplique visualmente.

### SVG incorrecto

Revisar:
QRSaveFormat.kt
QRResultScreen.kt
QRRenderer.kt
exportador SVG
assets/logos/

No modificar módulos u ojos para solucionar exclusivamente un problema del logo SVG.

### Error de compilación después de agregar una dependencia

1. Revisar la dependencia nueva.
2. Compilar.
3. Revisar memoria disponible.
4. Comprobar conflictos.
5. Evitar librerías innecesarias.

AIDE/JStudio puede tener limitaciones de memoria durante la compilación, por lo que el tamaño de dependencias es especialmente importante.

## 50. Nuevos tipos de QR

Revisar como mínimo:

QRType.kt
QRConfig.kt
QRConfigScreen.kt
QRGenerator.kt
QRScanParser.kt
QRScanResultScreen.kt

No asumir que agregar un valor al enum es suficiente.

## 51. Nuevos estilos

Nuevo módulo:
QRConfig.kt
QRRenderer.kt
QRConfigScreen.kt

Nuevo ojo:
QRConfig.kt
QRRenderer.kt
QRConfigScreen.kt

Nuevo marco:
ScannerStyle.kt
QRScannerScreen.kt
res/drawable/

Mantener la geometría 1450 / 1050 / 200 salvo modificación deliberada de todo el sistema.

## 52. Antes de borrar código

No eliminar un archivo, función o recurso solo porque parece no utilizarse.

Primero:
1. Buscar referencias.
2. Compilar.
3. Probar la función.
4. Confirmar que no afecta otro flujo.
5. Eliminar solo después.

Especialmente importante para:
- logos
- estilos
- renderer
- scanner
- parser
- exportación SVG

## 53. Regla de desarrollo incremental

1. Cambiar una cosa.
2. Compilar.
3. Instalar.
4. Probar.
5. Continuar.

Evitar cambios grandes simultáneos.

Prioridad:
1. Funcionalidad
2. Legibilidad
3. Robustez
4. Experiencia de uso
5. Diseño

## 54. Filosofía del proyecto

QR Pro Max busca:

PERSONALIZACIÓN
       +
LEGIBILIDAD
       +
ROBUSTEZ
       +
BUENA EXPERIENCIA

Un QR bonito pero ilegible no cumple su objetivo.

## 55. Estado actual del proyecto

### Generación
- Ocho tipos implementados.
- Módulos personalizados.
- Ojos personalizados.
- Colores personalizados.
- Corrección de errores.
- Logos.
- Tamaño de logo.
- Verificación.
- Contraste.

### Exportación
- PNG.
- JPG.
- SVG.
- Exportación SVG vectorial.
- Logos SVG.
- Colores y gradientes de logos SVG.

### Scanner
- Cámara funcionando.
- Lectura de códigos QR.
- Lectura de códigos de barras.
- Detección mediante ZXing.
- Detección de múltiples formatos.
- Rechazo de frames con múltiples códigos.
- Confirmación del mismo resultado en frames consecutivos.
- Linterna funcionando.
- Marcos funcionando.
- Persistencia de marco funcionando.
- Línea de escaneo funcionando.
- Galería funcionando para QR y códigos de barras en los casos probados.
- Parser inteligente.
- Resultado inteligente.
- Acciones específicas por tipo.

### Interfaz
- Selección de tipos con iconos.
- Iconos adaptados al tema.
- Resultado.
- Guardar con PNG/JPG/SVG.
- Compartir.
- Editar QR.
- Ajustes.
- Acerca de.
- Sugerir mejora.
- Versión 1.0.0.

### Monetización
- Google AdMob integrado.
- play-services-ads-lite:25.0.0.
- Banner funcionando.

### Distribución
- Google Play en preparación.
- OPPO App Market considerado como canal adicional.
- Otras tiendas Android en evaluación.

## 56. Próximas áreas de trabajo

[ ] Ampliar compatibilidad del parser vCard
[ ] Mejorar detección de formatos URL
[ ] Añadir más logos
[ ] Añadir más estilos si aportan valor
[ ] Mejorar compatibilidad con lectores externos
[ ] Pulir UI
[ ] Pruebas extensivas en dispositivos físicos
[ ] Preparación final para Google Play
[ ] Distribución en tiendas Android adicionales
[ ] Optimización de monetización
[ ] Mejorar detección de códigos dentro del área visual del marco
[ ] Optimizar velocidad de lectura desde galería
[ ] Ampliar compatibilidad con otros formatos de códigos de barras

No implementar nuevas funciones únicamente por cantidad. Cada función debe aportar valor sin comprometer legibilidad, estabilidad o tamaño.

## 57. Regla de oro

Si una modificación rompe algo que ya funcionaba, volver al último estado compilable y hacer el cambio de forma más pequeña.

¿Funciona actualmente?
        ↓
      SÍ
        ↓
Cambiar lo mínimo posible
        ↓
     Compilar
        ↓
      Probar
        ↓
   Continuar

QR Pro Max = Personalización + Legibilidad + Robustez + Buena experiencia.
