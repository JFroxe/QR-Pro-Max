package com.alehei.qrpromax.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.alehei.qrpromax.BuildConfig

@Composable
fun QRAboutScreen(
    onBack: () -> Unit
) {
    
    val versionName = BuildConfig.VERSION_NAME
    
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .statusBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 24.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Button(onClick = onBack) { Text("Volver") }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Encabezado
        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "QR Pro Max",
                style = MaterialTheme.typography.headlineLarge,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground
            )
            Text(
                text = "Versión $versionName",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(top = 4.dp)
            )
        }

        Spacer(modifier = Modifier.height(24.dp))

        AboutSection(
            title = "Sobre la aplicación",
            content = "QR Pro Max es una aplicación creada para facilitar el escaneo y manejo de códigos QR de diferentes tipos. Su objetivo es ofrecer una experiencia sencilla, rápida y práctica, permitiendo consultar la información de los códigos y realizar acciones útiles directamente desde el dispositivo."
        )

        AboutSection(
            title = "Privacidad",
            content = "QR Pro Max respeta tu privacidad. La aplicación no recopila, almacena ni comparte información personal ni datos de los códigos que escaneas. La aplicación no se conecta a ningún servidor para procesar esta información y funciona de forma local en tu dispositivo."
        )

        AboutSection(
            title = "Licencia",
            content = "QR Pro Max es software propietario. El nombre, diseño, código y contenido de la aplicación están protegidos y no pueden ser redistribuidos o modificados sin autorización."
        )

        AboutSection(
            title = "Créditos",
            content = "QR Pro Max fue creada y desarrollada por Alehei. La aplicación utiliza bibliotecas de código abierto para determinadas funciones relacionadas con la lectura y generación de códigos QR."
        )

        AboutSection(
            title = "¿Necesitas una aplicación?",
            content = "También se aceptan comisiones para el desarrollo de aplicaciones personalizadas. Si tienes una idea o necesitas una aplicación para un proyecto, negocio o uso personal, puedes contactar con Alehei para hablar sobre tu proyecto."
        )

        Spacer(modifier = Modifier.height(32.dp))

        // Pie de página
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "© 2026 Alehei",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center
            )
            Text(
                text = "QR Pro Max · Todos los derechos reservados",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(top = 2.dp)
            )
        }
    }
}

@Composable
private fun AboutSection(
    title: String,
    content: String
) {
    Column(
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text(
            text = title,
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onBackground
        )
        Text(
            text = content,
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onBackground,
            modifier = Modifier.fillMaxWidth()
        )
    }
}
