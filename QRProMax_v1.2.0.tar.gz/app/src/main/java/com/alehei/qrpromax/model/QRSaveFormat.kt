package com.alehei.qrpromax.model

enum class QRSaveFormat {
    PNG,
    JPG,
    SVG
}