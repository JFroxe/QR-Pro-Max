package com.alehei.qrpromax.qr

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import androidx.core.content.ContextCompat
import androidx.compose.ui.graphics.toArgb
import com.alehei.qrpromax.model.ErrorCorrection
import com.alehei.qrpromax.model.EyeStyle
import com.alehei.qrpromax.model.ModuleStyle
import com.google.zxing.EncodeHintType
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel
import com.google.zxing.qrcode.encoder.Encoder
import com.google.zxing.qrcode.encoder.QRCode


fun renderQRCode(
    context: Context,
    config: com.alehei.qrpromax.model.QRConfig,
    size: Int = 800
): Bitmap {

    // ---------------------------------------------------------
    // NIVEL DE CORRECCIÓN
    // ---------------------------------------------------------

    val errorCorrection = when (config.errorCorrection) {

        ErrorCorrection.LOW ->
            ErrorCorrectionLevel.L

        ErrorCorrection.MEDIUM ->
            ErrorCorrectionLevel.M

        ErrorCorrection.QUARTILE ->
            ErrorCorrectionLevel.Q

        ErrorCorrection.HIGH ->
            ErrorCorrectionLevel.H
    }


    // ---------------------------------------------------------
    // GENERAR MATRIZ QR CON ZXING
    // ---------------------------------------------------------

    val hints = hashMapOf<EncodeHintType, Any>()

    hints[EncodeHintType.ERROR_CORRECTION] = errorCorrection
    hints[EncodeHintType.CHARACTER_SET] = "UTF-8"

    val qrCode: QRCode = Encoder.encode(
        config.content,
        errorCorrection,
        hints
    )

    val matrix = qrCode.matrix
    val moduleCount = matrix.width


    // ---------------------------------------------------------
    // BITMAP
    // ---------------------------------------------------------

    val bitmap = Bitmap.createBitmap(
        size,
        size,
        Bitmap.Config.ARGB_8888
    )

    val canvas = Canvas(bitmap)


    // ---------------------------------------------------------
    // FONDO
    // ---------------------------------------------------------

    val backgroundColor = config.backgroundColor.toArgb()
    val foregroundColor = config.foregroundColor.toArgb()

    canvas.drawColor(backgroundColor)


    // ---------------------------------------------------------
    // TAMAÑO DE CADA MÓDULO
    // ---------------------------------------------------------

    val quietZoneModules = 3
    
    val qrSizeModules = moduleCount + quietZoneModules * 2
    
    val moduleSize = size.toFloat() / qrSizeModules
    
    val offset = quietZoneModules * moduleSize


    // ---------------------------------------------------------
    // OBTENER XML DEL MÓDULO
    // ---------------------------------------------------------

    val moduleDrawableId = getModuleDrawableId(
        config.moduleStyle
    )
    
    // ---------------------------------------------------------
    // DIBUJAR MÓDULOS
    // ---------------------------------------------------------
    
    for (y in 0 until moduleCount) {
        for (x in 0 until moduleCount) {
    
            // Módulo vacío
            if (matrix.get(x, y) == 0.toByte()) {
                continue
            }
    
            if (isFinderPattern(x, y, moduleCount)) {
                continue
            }
    
            val left = offset + x * moduleSize
            val top = offset + y * moduleSize
    
            drawVector(
                context = context,
                canvas = canvas,
                drawableId = moduleDrawableId,
                left = left,
                top = top,
                size = moduleSize,
                color = foregroundColor
            )
        }
    }
    
    // ---------------------------------------------------------
    // DIBUJAR LOS TRES OJOS
    // ---------------------------------------------------------

    // Superior izquierdo
    drawFinderPattern(
        context = context,
        offset = offset,
        canvas = canvas,
        drawableId = getEyeDrawableId(config.eyeStyle),
        startX = 0,
        startY = 0,
        moduleSize = moduleSize,
        foregroundColor = foregroundColor,
        backgroundColor = backgroundColor
    )


    // Superior derecho
    drawFinderPattern(
        context = context,
        offset = offset,
        canvas = canvas,
        drawableId = getEyeDrawableId(config.eyeStyle),
        startX = moduleCount - 7,
        startY = 0,
        moduleSize = moduleSize,
        foregroundColor = foregroundColor,
        backgroundColor = backgroundColor
    )


    // Inferior izquierdo
    drawFinderPattern(
        context = context,
        offset = offset,
        canvas = canvas,
        drawableId = getEyeDrawableId(config.eyeStyle),
        startX = 0,
        startY = moduleCount - 7,
        moduleSize = moduleSize,
        foregroundColor = foregroundColor,
        backgroundColor = backgroundColor
    )

    if (config.logoEnabled && config.logoResId != null) {
    
        drawLogo(
            context = context,
            canvas = canvas,
            drawableId = config.logoResId,
            centerX = size / 2f,
            centerY = size / 2f,
            size = size * config.logoSize
        )
    }

    return bitmap
}

// ---------------------------------------------------------
// MÓDULO → XML
// ---------------------------------------------------------

private fun getModuleDrawableId(
    style: ModuleStyle
): Int {

    return when (style) {

        ModuleStyle.SQUARE ->
            com.alehei.qrpromax.R.drawable.module_square

        ModuleStyle.ROUNDED ->
            com.alehei.qrpromax.R.drawable.module_rounded

        ModuleStyle.DOTS ->
            com.alehei.qrpromax.R.drawable.module_dot

        ModuleStyle.HEART ->
            com.alehei.qrpromax.R.drawable.module_heart

        ModuleStyle.STAR ->
            com.alehei.qrpromax.R.drawable.module_star

        ModuleStyle.TRIANGLE ->
            com.alehei.qrpromax.R.drawable.module_triangle

        ModuleStyle.HEXAGON ->
            com.alehei.qrpromax.R.drawable.module_hexagon
        
        ModuleStyle.CLOVER ->
            com.alehei.qrpromax.R.drawable.module_clover
        
        ModuleStyle.PIECE ->
            com.alehei.qrpromax.R.drawable.module_piece
        
        ModuleStyle.MSG ->
            com.alehei.qrpromax.R.drawable.module_msg
        
        ModuleStyle.LIKE ->
            com.alehei.qrpromax.R.drawable.module_like
    }
}

// ---------------------------------------------------------
// OJO → XML
// ---------------------------------------------------------

private fun getEyeDrawableId(
    style: EyeStyle
): Int {

    return when (style) {

        EyeStyle.SQUARE ->
            com.alehei.qrpromax.R.drawable.eye_square

        EyeStyle.ROUNDED ->
            com.alehei.qrpromax.R.drawable.eye_rounded

        EyeStyle.CIRCLE ->
            com.alehei.qrpromax.R.drawable.eye_circle

        EyeStyle.OCTAGON ->
            com.alehei.qrpromax.R.drawable.eye_octagon

        EyeStyle.FLOWER ->
            com.alehei.qrpromax.R.drawable.eye_flower

        EyeStyle.BOW ->
            com.alehei.qrpromax.R.drawable.eye_bow
        
        EyeStyle.PUZZLE ->
            com.alehei.qrpromax.R.drawable.eye_puzzle
        
        EyeStyle.DROP ->
            com.alehei.qrpromax.R.drawable.eye_drop
    }
}


// ---------------------------------------------------------
// DETECTAR LOS TRES FINDER PATTERNS
// ---------------------------------------------------------

private fun isFinderPattern(
    x: Int,
    y: Int,
    moduleCount: Int
): Boolean {

    return (
        x < 7 && y < 7
    ) || (
        x >= moduleCount - 7 && y < 7
    ) || (
        x < 7 && y >= moduleCount - 7
    )
}


// ---------------------------------------------------------
// OJO COMPLETO
// ---------------------------------------------------------

private fun drawFinderPattern(
    context: Context,
    offset: Float,
    canvas: Canvas,
    drawableId: Int,
    startX: Int,
    startY: Int,
    moduleSize: Float,
    foregroundColor: Int,
    backgroundColor: Int
) {

    val centerX = offset + startX * moduleSize + moduleSize * 3.5f
    val centerY = offset + startY * moduleSize + moduleSize * 3.5f

    // ---------------------------------------------------------
    // CAPA EXTERIOR — 7 × 7
    // ---------------------------------------------------------

    drawVectorCentered(
        context = context,
        canvas = canvas,
        drawableId = drawableId,
        centerX = centerX,
        centerY = centerY,
        size = moduleSize * 7f,
        color = foregroundColor
    )


    // ---------------------------------------------------------
    // CAPA INTERMEDIA — 5 × 5
    // ---------------------------------------------------------

    drawVectorCentered(
        context = context,
        canvas = canvas,
        drawableId = drawableId,
        centerX = centerX,
        centerY = centerY,
        size = moduleSize * 5f,
        color = backgroundColor
    )


    // ---------------------------------------------------------
    // CENTRO — 3 × 3
    // ---------------------------------------------------------

    drawVectorCentered(
        context = context,
        canvas = canvas,
        drawableId = drawableId,
        centerX = centerX,
        centerY = centerY,
        size = moduleSize * 3f,
        color = foregroundColor
    )
}


// ---------------------------------------------------------
// DIBUJAR VECTOR EN UNA POSICIÓN
// ---------------------------------------------------------

private fun drawVector(
    context: Context,
    canvas: Canvas,
    drawableId: Int,
    left: Float,
    top: Float,
    size: Float,
    color: Int
) {

    val drawable = ContextCompat.getDrawable(
        context,
        drawableId
    ) ?: return

    drawable.setTint(color)

    drawable.setBounds(
        left.toInt(),
        top.toInt(),
        (left + size).toInt(),
        (top + size).toInt()
    )

    drawable.draw(canvas)
}


// ---------------------------------------------------------
// DIBUJAR VECTOR CENTRADO
// ---------------------------------------------------------

private fun drawVectorCentered(
    context: Context,
    canvas: Canvas,
    drawableId: Int,
    centerX: Float,
    centerY: Float,
    size: Float,
    color: Int
) {

    val left =
        centerX - size / 2f

    val top =
        centerY - size / 2f

    drawVector(
        context = context,
        canvas = canvas,
        drawableId = drawableId,
        left = left,
        top = top,
        size = size,
        color = color
    )
}

private fun drawLogo(
    context: Context,
    canvas: Canvas,
    drawableId: Int,
    centerX: Float,
    centerY: Float,
    size: Float
) {
    val drawable = ContextCompat.getDrawable(
        context,
        drawableId
    ) ?: return

    val left = centerX - size / 2f
    val top = centerY - size / 2f

    drawable.setBounds(
        left.toInt(),
        top.toInt(),
        (left + size).toInt(),
        (top + size).toInt()
    )

    // Importante:
    // NO usamos setTint() aquí.
    // El logo conserva los colores definidos en su XML.

    drawable.draw(canvas)
}