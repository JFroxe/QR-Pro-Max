package com.alehei.qrpromax.qr

import android.content.Context

object QRAdFrequency {

    private const val PREFS_NAME = "qr_pro_max_ad_prefs"
    private const val KEY_GENERATION_COUNT = "generation_count"

    // Mostrar un anuncio cada 3 generaciones.
    private const val GENERATIONS_PER_AD = 3

    fun registerGeneration(context: Context) {
        val prefs = context.getSharedPreferences(
            PREFS_NAME,
            Context.MODE_PRIVATE
        )

        val currentCount = prefs.getInt(
            KEY_GENERATION_COUNT,
            0
        )

        prefs.edit()
            .putInt(
                KEY_GENERATION_COUNT,
                currentCount + 1
            )
            .apply()
    }

    fun shouldShowAd(context: Context): Boolean {
        val prefs = context.getSharedPreferences(
            PREFS_NAME,
            Context.MODE_PRIVATE
        )

        val count = prefs.getInt(
            KEY_GENERATION_COUNT,
            0
        )

        return count >= GENERATIONS_PER_AD
    }

    fun resetGenerationCount(context: Context) {
        val prefs = context.getSharedPreferences(
            PREFS_NAME,
            Context.MODE_PRIVATE
        )

        prefs.edit()
            .putInt(
                KEY_GENERATION_COUNT,
                0
            )
            .apply()
    }

    fun getGenerationCount(context: Context): Int {
        val prefs = context.getSharedPreferences(
            PREFS_NAME,
            Context.MODE_PRIVATE
        )

        return prefs.getInt(
            KEY_GENERATION_COUNT,
            0
        )
    }
}