package com.alehei.qrpromax.qr

import android.graphics.Bitmap
import com.google.zxing.BarcodeFormat
import com.google.zxing.BinaryBitmap
import com.google.zxing.DecodeHintType
import com.google.zxing.MultiFormatReader
import com.google.zxing.RGBLuminanceSource
import com.google.zxing.common.GlobalHistogramBinarizer
import com.google.zxing.common.HybridBinarizer

fun decodeQRFromBitmap(bitmap: Bitmap): String? {

    val softwareBitmap = bitmap.copy(
        Bitmap.Config.ARGB_8888,
        false
    )

    val width = softwareBitmap.width
    val height = softwareBitmap.height

    val pixels = IntArray(width * height)

    softwareBitmap.getPixels(
        pixels,
        0,
        width,
        0,
        0,
        width,
        height
    )

    val hints = hashMapOf<DecodeHintType, Any>()

    hints[DecodeHintType.TRY_HARDER] = true

    hints[DecodeHintType.POSSIBLE_FORMATS] =
        listOf(
            BarcodeFormat.QR_CODE,

            // Códigos de barras comunes
            BarcodeFormat.EAN_13,
            BarcodeFormat.EAN_8,
            BarcodeFormat.UPC_A,
            BarcodeFormat.UPC_E,

            // Códigos alfanuméricos
            BarcodeFormat.CODE_128,
            BarcodeFormat.CODE_39,
            BarcodeFormat.CODE_93,

            // Otros formatos comunes
            BarcodeFormat.ITF,
            BarcodeFormat.CODABAR
        )

    // Intento normal
    decodeWithBinarizer(
        width,
        height,
        pixels,
        HybridBinarizer(
            RGBLuminanceSource(
                width,
                height,
                pixels
            )
        ),
        hints
    )?.let {
        return it
    }

    // Intento con otro método de binarización
    decodeWithBinarizer(
        width,
        height,
        pixels,
        GlobalHistogramBinarizer(
            RGBLuminanceSource(
                width,
                height,
                pixels
            )
        ),
        hints
    )?.let {
        return it
    }

    // Intento especial para códigos limpios
    hints[DecodeHintType.PURE_BARCODE] = true

    return decodeWithBinarizer(
        width,
        height,
        pixels,
        HybridBinarizer(
            RGBLuminanceSource(
                width,
                height,
                pixels
            )
        ),
        hints
    )
}

private fun decodeWithBinarizer(
    width: Int,
    height: Int,
    pixels: IntArray,
    binarizer: com.google.zxing.Binarizer,
    hints: HashMap<DecodeHintType, Any>
): String? {

    return try {

        val binaryBitmap = BinaryBitmap(
            binarizer
        )

        val reader = MultiFormatReader()

        val result = reader.decode(
            binaryBitmap,
            hints
        )

        result.text

    } catch (e: Exception) {

        android.util.Log.e(
            "QRImageDecoder",
            "Error leyendo código desde imagen",
            e
        )

        null
    }
}