package com.alehei.qrpromax.model

import com.alehei.qrpromax.R

enum class QRType(
    val title: String,
    val iconResId: Int
) {
    URL("URL", R.drawable.icon_url),
    TEXT("Texto", R.drawable.icon_text),
    WIFI("Wi-Fi", R.drawable.icon_wifi),
    CONTACT("Contacto", R.drawable.icon_contact),
    EMAIL("Email", R.drawable.icon_mail),
    PHONE("Teléfono", R.drawable.icon_phone),
    SMS("SMS", R.drawable.icon_sms),
    LOCATION("Ubicación", R.drawable.icon_pin)
}