package com.alehei.qrpromax

import android.net.Uri
import android.graphics.Bitmap
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.foundation.background
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.runtime.SideEffect
import androidx.core.view.WindowCompat
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.TextButton
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.ui.Modifier
import android.app.Activity
import androidx.activity.OnBackPressedCallback
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import com.alehei.qrpromax.qr.QRAds
import com.alehei.qrpromax.qr.verifyQRCode
import com.alehei.qrpromax.model.QRConfig
import com.alehei.qrpromax.model.ScannerStyle
import com.alehei.qrpromax.model.QRSaveFormat
import com.alehei.qrpromax.ui.screens.QRSettingsScreen
import com.alehei.qrpromax.ui.screens.QRConfigScreen
import com.alehei.qrpromax.ui.screens.QRResultScreen
import com.alehei.qrpromax.ui.screens.QRScanResultScreen
import com.alehei.qrpromax.ui.screens.QRScannerScreen
import com.alehei.qrpromax.ui.screens.QRAboutScreen
import com.alehei.qrpromax.ui.screens.QRSuggestScreen
import com.alehei.qrpromax.ui.theme.QRProMaxTheme
import com.alehei.qrpromax.qr.QRAdFrequency
import com.alehei.qrpromax.qr.generateQRCode
import com.alehei.qrpromax.qr.exportQRCodeToSvg
import com.alehei.qrpromax.qr.hasGoodQRContrast
import com.alehei.qrpromax.qr.renderQRCode
import com.google.android.gms.ads.MobileAds
import com.google.android.play.core.review.ReviewManagerFactory
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.ClipData
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileOutputStream
import android.provider.MediaStore
import android.widget.Toast

class MainActivity : ComponentActivity() {

    private var currentConfig by mutableStateOf(QRConfig())

    private var currentBitmap by mutableStateOf<Bitmap?>(null)

    private var showResult by mutableStateOf(false)

    private var showScanner by mutableStateOf(false)

    private var showSettings by mutableStateOf(false)

    private var showVerificationWarning by mutableStateOf(false)

    private var showAbout by mutableStateOf(false)

    private var showSuggest by mutableStateOf(false)

    private var scannedContent by mutableStateOf<String?>(null)

    private var qrVerified by mutableStateOf(false)

    private var qrContrastGood by mutableStateOf(true)

    private var appOpenAdAlreadyShown = false

    private val prefs by lazy {
        getSharedPreferences("qr_pro_max_prefs", MODE_PRIVATE)
    }
    
    private fun openScannerFromTile() {
        showAbout = false
        showSuggest = false
        showSettings = false
        showResult = false
        scannedContent = null
        showScanner = true
    }
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (intent.getBooleanExtra("open_scanner_from_tile", false)) {
            openScannerFromTile()
        }
        
        onBackPressedDispatcher.addCallback(
            this,
            object : OnBackPressedCallback(true) {

                override fun handleOnBackPressed() {

                    when {

                        showAbout -> {
                            showAbout = false
                            showSettings = true
                        }

                        showSuggest -> {
                            showSuggest = false
                            showSettings = true
                        }

                        scannedContent != null -> {
                            scannedContent = null
                            showScanner = true
                        }

                        showScanner -> {
                            showScanner = false
                        }

                        showSettings -> {
                            showSettings = false
                        }

                        showResult -> {
                            showResult = false
                        }

                        else -> {
                            // Estamos en la pantalla principal.
                            // Aquí sí permitimos salir de la aplicación.
                            finish()
                        }
                    }
                }
            }
        )

        MobileAds.initialize(this)
        QRAds.loadAppOpenAd(this)

        val savedScannerStyle = prefs
            .getString("scanner_style", ScannerStyle.CLASSIC.name)
            ?.let {
                try {
                    ScannerStyle.valueOf(it)
                } catch (e: Exception) {
                    ScannerStyle.CLASSIC
                }
            }
            ?: ScannerStyle.CLASSIC

        currentConfig = currentConfig.copy(
            scannerStyle = savedScannerStyle
        )

        setContent {
            val darkTheme = isSystemInDarkTheme()

            SideEffect {
                val controller = WindowCompat.getInsetsController(
                    window,
                    window.decorView
                )

                controller.isAppearanceLightStatusBars = !darkTheme
                controller.isAppearanceLightNavigationBars = !darkTheme
            }

            QRProMaxTheme {

                // Android puede dibujar la aplicación detrás de las barras
                // del sistema (especialmente en Android 15+).
                // safeDrawingPadding() reserva automáticamente el espacio
                // ocupado por la barra de estado, navegación y gestos.
                //
                // De esta forma los controles de QR Pro Max nunca quedan
                // debajo de los botones/gestos del sistema.
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(MaterialTheme.colorScheme.background)
                        .safeDrawingPadding()
                ) {
                    when {
                        showAbout -> {

                            QRAboutScreen(
                                onBack = {
                                    showAbout = false
                                    showSettings = true
                                }
                            )
                        }

                        showScanner -> {

                            QRScannerScreen(
                                scannerStyle = currentConfig.scannerStyle,
                                onScannerStyleChange = { style ->
                                    currentConfig = currentConfig.copy(
                                        scannerStyle = style
                                    )

                                    prefs.edit()
                                        .putString("scanner_style", style.name)
                                        .apply()
                                },
                                onBack = {
                                    showScanner = false
                                },
                                onResult = { result ->
                                    scannedContent = result
                                    showScanner = false
                                    registerQRInteraction()
                                }
                            )
                        }

                        showSuggest -> {

                            QRSuggestScreen(
                                onBack = {
                                    showSuggest = false
                                    showSettings = true
                                },
                                onSend = { description, imageUri ->

                                    sendSuggestionEmail(
                                        context = this@MainActivity,
                                        description = description,
                                        imageUri = imageUri
                                    )
                                }
                            )
                        }

                        showSettings -> {

                            QRSettingsScreen(
                                onBack = {
                                    showSettings = false
                                },
                                onSuggest = {
                                    showSettings = false
                                    showSuggest = true
                                },
                                onShareApp = {
                                    shareApp(this@MainActivity)
                                },
                                onRateApp = {
                                    rateApp(this@MainActivity)
                                },
                                onAbout = {
                                    showSettings = false
                                    showAbout = true
                                }
                            )
                        }

                        scannedContent != null -> {

                            QRScanResultScreen(
                                content = scannedContent!!,
                                onBack = {
                                    scannedContent = null
                                    showScanner = true
                                },
                                onCopy = { text ->
                                    val clipboard =
                                        getSystemService(android.content.Context.CLIPBOARD_SERVICE)
                                            as android.content.ClipboardManager

                                    val clip =
                                        android.content.ClipData.newPlainText(
                                            "QR",
                                            text
                                        )

                                    clipboard.setPrimaryClip(clip)
                                },
                                onShare = { text ->
                                    shareText(
                                        this@MainActivity,
                                        text
                                    )
                                },
                                onAction = { intent ->
                                    startActivity(intent)
                                }
                            )
                        }

                        showResult && currentBitmap != null -> {

                            QRResultScreen(
                                config = currentConfig,
                                verified = qrVerified,
                                contrastGood = qrContrastGood,
                                bitmap = currentBitmap!!,
                                onEdit = {
                                    showResult = false
                                },
                                onSave = { format, exportSize ->
                                    saveQRCode(
                                        this@MainActivity,
                                        currentBitmap!!,
                                        currentConfig,
                                        format,
                                        exportSize
                                    )
                                },
                                onShare = {
                                    shareQRCode(
                                        this@MainActivity,
                                        currentBitmap!!
                                    )
                                }
                            )
                        }

                        else -> {

                            QRConfigScreen(
                                initialConfig = currentConfig,
                                onScan = {
                                    showScanner = true
                                },

                                onSetting = {
                                    showSettings = true
                                },

                                onGenerate = { config ->

                                    currentConfig = config

                                    val bitmap = generateQRCode(
                                        this@MainActivity,
                                        config
                                    )

                                    currentBitmap = bitmap

                                    qrContrastGood =
                                        hasGoodQRContrast(
                                            foreground = config.foregroundColor,
                                            background = config.backgroundColor
                                        )

                                    qrVerified =
                                        verifyQRCode(
                                            bitmap = bitmap,
                                            expectedContent = config.content
                                        )

                                    // Registramos esta generación.
                                    QRAdFrequency.registerGeneration(
                                        this@MainActivity
                                    )

                                    registerQRInteraction()

                                    // Si corresponde mostrar anuncio,
                                    // lo mostramos antes de entrar al resultado.
                                    if (QRAdFrequency.shouldShowAd(this@MainActivity)) {

                                        QRAds.showInterstitialAd(
                                            activity = this@MainActivity,
                                            onFinished = {

                                                QRAdFrequency.resetGenerationCount(
                                                    this@MainActivity
                                                )

                                                showResult = true
                                            }
                                        )

                                    } else {

                                        // No corresponde anuncio.
                                        showResult = true
                                    }
                                }
                            )
                        }
                    }
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()

        if (!appOpenAdAlreadyShown) {
            appOpenAdAlreadyShown = true

            QRAds.showAppOpenAd(this)
        }
    }
    
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
    
        if (intent.getBooleanExtra("open_scanner_from_tile", false)) {
            openScannerFromTile()
        }
    }
    
    private fun requestAppReview() {

        val manager = ReviewManagerFactory.create(this)

        val request = manager.requestReviewFlow()

        request.addOnCompleteListener { task ->

            if (task.isSuccessful) {

                val reviewInfo = task.result

                val flow = manager.launchReviewFlow(
                    this,
                    reviewInfo
                )

                flow.addOnCompleteListener {
                    // No hacemos nada aquí.
                    // Google gestiona el flujo de valoración.
                }
            }
        }
    }

    private fun registerQRInteraction() {

        val count = prefs.getInt(
            "qr_interaction_count",
            0
        )

        val newCount = count + 1

        prefs.edit()
            .putInt(
                "qr_interaction_count",
                newCount
            )
            .apply()

        if (newCount >= 3) {

            val alreadyRequested = prefs.getBoolean(
                "review_requested",
                false
            )

            if (!alreadyRequested) {

                prefs.edit()
                    .putBoolean(
                        "review_requested",
                        true
                    )
                    .apply()

                requestAppReview()
            }
        }
    }
}

fun saveQRCode(
    context: Context,
    bitmap: Bitmap,
    config: QRConfig,
    format: QRSaveFormat,
    exportSize: Int
) {
    val outputSize = if (exportSize in setOf(720, 1080, 2340, 4240)) {
        exportSize
    } else {
        bitmap.width
    }
    val exportBitmap = if (format == QRSaveFormat.SVG) {
        null
    } else {
        renderQRCode(
            context = context,
            config = config,
            size = outputSize
        )
    }

    val extension = when (format) {
        QRSaveFormat.PNG -> "png"
        QRSaveFormat.JPG -> "jpg"
        QRSaveFormat.SVG -> "svg"
    }

    val mimeType = when (format) {
        QRSaveFormat.PNG -> "image/png"
        QRSaveFormat.JPG -> "image/jpeg"
        QRSaveFormat.SVG -> "image/svg+xml"
    }

    val filename =
        "QR_Pro_Max_${System.currentTimeMillis()}.$extension"

    val contentValues = ContentValues().apply {

        put(
            MediaStore.Images.Media.DISPLAY_NAME,
            filename
        )

        put(
            MediaStore.Images.Media.MIME_TYPE,
            mimeType
        )

        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q) {

            put(
                MediaStore.Images.Media.RELATIVE_PATH,
                "Pictures/QR Pro Max"
            )
        }
    }

    val resolver = context.contentResolver

    val uri = resolver.insert(
        MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
        contentValues
    )

    if (uri != null) {

        resolver.openOutputStream(uri)?.use { outputStream ->

            when (format) {

                QRSaveFormat.PNG -> {
                    exportBitmap!!.compress(
                        Bitmap.CompressFormat.PNG,
                        100,
                        outputStream
                    )
                }

                QRSaveFormat.JPG -> {
                    exportBitmap!!.compress(
                        Bitmap.CompressFormat.JPEG,
                        100,
                        outputStream
                    )
                }

                QRSaveFormat.SVG -> {

                    val svg = exportQRCodeToSvg(
                        context = context,
                        config = config,
                        size = outputSize
                    )

                    outputStream.write(
                        svg.toByteArray(Charsets.UTF_8)
                    )
                }
            }
        }

        Toast.makeText(
            context,
            "QR guardado en la galería",
            Toast.LENGTH_SHORT
        ).show()

    } else {

        Toast.makeText(
            context,
            "No se pudo guardar el QR",
            Toast.LENGTH_SHORT
        ).show()
    }
}


fun shareQRCode(
    context: Context,
    bitmap: Bitmap
) {

    try {

        val file = File.createTempFile(
            "qr_promax_",
            ".png",
            context.cacheDir
        )

        FileOutputStream(file).use { outputStream ->

            bitmap.compress(
                Bitmap.CompressFormat.PNG,
                100,
                outputStream
            )
        }

        val uri = FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            file
        )

        val intent = Intent(Intent.ACTION_SEND).apply {

            type = "image/png"

            putExtra(
                Intent.EXTRA_STREAM,
                uri
            )

            addFlags(
                Intent.FLAG_GRANT_READ_URI_PERMISSION
            )

            clipData = ClipData.newRawUri(
                "Código QR",
                uri
            )
        }

        context.startActivity(
            Intent.createChooser(
                intent,
                "Compartir código QR"
            )
        )

    } catch (e: Exception) {

        Toast.makeText(
            context,
            "No se pudo compartir el código QR",
            Toast.LENGTH_SHORT
        ).show()
    }
}

private fun shareText(
    context: android.content.Context,
    text: String
) {
    val intent = Intent(Intent.ACTION_SEND).apply {
        type = "text/plain"
        putExtra(Intent.EXTRA_TEXT, text)
    }

    context.startActivity(
        Intent.createChooser(
            intent,
            "Compartir"
        )
    )
}

private fun shareApp(context: Context) {

    val shareText =
        "Genera y escanea tus códigos QR fácil y rápido con QR Pro Max.\n" +
        "https://play.google.com/store/apps/details?id=com.alehei.qrpromax"

    val intent = Intent(Intent.ACTION_SEND).apply {
        type = "text/plain"
        putExtra(Intent.EXTRA_TEXT, shareText)
    }

    context.startActivity(
        Intent.createChooser(
            intent,
            "Compartir QR Pro Max"
        )
    )
}


private fun rateApp(context: Context) {

    val packageName = context.packageName

    val playStoreIntent = Intent(
        Intent.ACTION_VIEW,
        android.net.Uri.parse(
            "market://details?id=$packageName"
        )
    )

    try {
        context.startActivity(playStoreIntent)
    } catch (e: Exception) {

        val browserIntent = Intent(
            Intent.ACTION_VIEW,
            android.net.Uri.parse(
                "https://play.google.com/store/apps/details?id=$packageName"
            )
        )

        context.startActivity(browserIntent)
    }
}

private fun sendSuggestionEmail(
    context: Context,
    description: String,
    imageUri: Uri?
) {
    val emailBody = """
        Sugerencia para QR Pro Max

        $description

        ---
        Enviado desde QR Pro Max
        Versión 1.0.0
    """.trimIndent()

    val intent = Intent(Intent.ACTION_SEND).apply {

        type = if (imageUri != null) {
            "image/*"
        } else {
            "text/plain"
        }

        setPackage("com.google.android.gm")

        putExtra(
            Intent.EXTRA_EMAIL,
            arrayOf("dev.alehei@gmail.com")
        )

        putExtra(
            Intent.EXTRA_SUBJECT,
            "Sugerencia para QR Pro Max"
        )

        putExtra(
            Intent.EXTRA_TEXT,
            emailBody
        )

        imageUri?.let {
            putExtra(Intent.EXTRA_STREAM, it)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
    }

    try {

        context.startActivity(intent)

    } catch (e: Exception) {

        Toast.makeText(
            context,
            "Gmail no está instalado",
            Toast.LENGTH_SHORT
        ).show()
    }
}
