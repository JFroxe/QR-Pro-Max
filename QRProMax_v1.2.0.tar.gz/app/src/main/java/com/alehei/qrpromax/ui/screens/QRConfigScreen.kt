package com.alehei.qrpromax.ui.screens

import com.alehei.qrpromax.R
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.material3.OutlinedButton
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.Image
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.focus.FocusDirection
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.material3.Button
import androidx.compose.material3.IconButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Surface
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.layout.ContentScale
import androidx.compose.foundation.border
import androidx.compose.foundation.shape.CircleShape
import com.alehei.qrpromax.model.ErrorCorrection
import com.alehei.qrpromax.model.EyeStyle
import com.alehei.qrpromax.model.ModuleStyle
import com.alehei.qrpromax.model.QRConfig
import com.alehei.qrpromax.model.QRType
import com.alehei.qrpromax.qr.QRNativeAd
import com.alehei.qrpromax.qr.QRAds

@Composable
fun QRConfigScreen(
    initialConfig: QRConfig = QRConfig(),
    onScan: () -> Unit,
    onSetting: () -> Unit,
    onGenerate: (QRConfig) -> Unit
) {
    var expandedSection by remember {
        mutableStateOf("content")
    }
    var config by remember(initialConfig) {
        mutableStateOf(initialConfig)
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        bottomBar = {
            Surface(
                tonalElevation = 4.dp,
                shadowElevation = 8.dp,
                color = MaterialTheme.colorScheme.surface
            ) {
                Column(
                    modifier = Modifier.padding(
                        start = 16.dp,
                        end = 16.dp,
                        top = 10.dp,
                        bottom = 12.dp
                    )
                ) {
                    Button(
                        onClick = {
                            if (config.content.isNotBlank()) {
                                onGenerate(config)
                            }
                        },
                        enabled = config.content.isNotBlank(),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(54.dp),
                        shape = RoundedCornerShape(18.dp)
                    ) {
                        Text(
                            text = "Generar código QR",
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Text(
                        text = if (config.content.isBlank()) {
                            "Completa el contenido para continuar"
                        } else {
                            "${config.type.title} listo para generar"
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 7.dp),
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    ) { paddingValues ->

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            // HEADER FIJO
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(start = 16.dp, top = 8.dp, end = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "QR Pro Max",
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.ExtraBold
                    )
                    Text(
                        text = "Crea, personaliza y comparte",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                IconButton(
                    onClick = onScan
                ) {
                    Image(
                        painter = painterResource(
                            R.drawable.icon_scan
                        ),
                        contentDescription = "Escanear QR",
                        colorFilter = ColorFilter.tint(MaterialTheme.colorScheme.primary),
                        modifier = Modifier.size(24.dp)
                    )
                }

                IconButton(
                    onClick = onSetting
                ) {
                    Image(
                        painter = painterResource(
                            R.drawable.icon_setting
                        ),
                        contentDescription = "Extras de la app",
                        colorFilter = ColorFilter.tint(MaterialTheme.colorScheme.onSurface),
                        modifier = Modifier.size(24.dp)
                    )
                }
            }        
        
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp)
                    .verticalScroll(rememberScrollState())
                    .padding(bottom = 80.dp)
            ) {
                
                QRNativeAd(
                    adUnitId = QRAds.CONFIG_NATIVE_AD_UNIT_ID,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(
                            horizontal = 16.dp,
                            vertical = 8.dp
                        )
                )
    
                Text(
                    text = "Configura tu código",
                    modifier = Modifier.padding(top = 24.dp, bottom = 10.dp),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
    
                SectionCard(
                    title = "Contenido",
                    summary = "${config.type.title} · ${if (config.content.isBlank()) "sin completar" else "listo"}",
                    expanded = expandedSection == "content",
                    onClick = { expandedSection = if (expandedSection == "content") "" else "content" }
                ) {
                    TypeTab(
                        config = config,
                        onConfigChange = { config = it }
                    )
                }
    
                SectionCard(
                    title = "Diseño",
                    summary = "${config.moduleStyle.name.lowercase().replaceFirstChar { it.uppercase() }} · ${config.errorCorrection.name}",
                    expanded = expandedSection == "design",
                    onClick = { expandedSection = if (expandedSection == "design") "" else "design" }
                ) {
                    DesignTab(
                        config = config,
                        onConfigChange = { config = it }
                    )
                }
    
                SectionCard(
                    title = "Identidad",
                    summary = if (config.logoEnabled) "Logo seleccionado" else "Sin logo",
                    expanded = expandedSection == "identity",
                    onClick = { expandedSection = if (expandedSection == "identity") "" else "identity" }
                ) {
                    LogoTab(
                        config = config,
                        onConfigChange = { config = it }
                    )
                }
    

                
                Spacer(modifier = Modifier.height(4.dp))
            }
        }
    }
}

@Composable
private fun SectionCard(
    title: String,
    summary: String,
    expanded: Boolean,
    onClick: () -> Unit,
    content: @Composable () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (expanded) {
                MaterialTheme.colorScheme.surface
            } else {
                MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.58f)
            }
        ),
        border = if (expanded) {
            BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.35f))
        } else {
            null
        }
    ) {
        Column {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable(onClick = onClick)
                    .padding(horizontal = 18.dp, vertical = 16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = title,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = summary,
                        modifier = Modifier.padding(top = 3.dp),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Text(
                    text = if (expanded) "⌃" else "⌄",
                    style = MaterialTheme.typography.headlineSmall,
                    color = MaterialTheme.colorScheme.primary
                )
            }

            if (expanded) {
                Column(
                    modifier = Modifier.padding(
                        start = 18.dp,
                        end = 18.dp,
                        bottom = 18.dp
                    )
                ) {
                    content()
                }
            }
        }
    }
}

@Composable
private fun TypeTab(
    config: QRConfig,
    onConfigChange: (QRConfig) -> Unit
) {

    Column {

        Text(
            text = "Tipo de código",
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold
        )

        Spacer(
            modifier = Modifier.height(12.dp)
        )

        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {

            items(QRType.entries) { type ->

                FilterChip(
                    selected = config.type == type,
                    onClick = {
                        onConfigChange(
                            clearQRContent(config, type)
                        )
                    },
                    label = {
                        Row(
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Image(
                                painter = painterResource(type.iconResId),
                                contentDescription = type.title,
                                modifier = Modifier.size(16.dp),
                                colorFilter = ColorFilter.tint(MaterialTheme.colorScheme.onBackground)
                            )
                    
                            Spacer(modifier = Modifier.width(8.dp))
                    
                            Text(type.title)
                        }
                    }
                )
            }
        }

        Spacer(
            modifier = Modifier.height(24.dp)
        )

        Text(
            text = when (config.type) {
                QRType.URL -> "Introduce una dirección web."
                QRType.TEXT -> "Introduce el texto que quieres codificar."
                QRType.WIFI -> "Configura una red Wi-Fi."
                QRType.CONTACT -> "Introduce los datos del contacto."
                QRType.EMAIL -> "Configura el correo electrónico."
                QRType.PHONE -> "Introduce un número de teléfono."
                QRType.SMS -> "Configura el mensaje SMS."
                QRType.LOCATION -> "Introduce una ubicación."
            }
        )

        Spacer(
            modifier = Modifier.height(12.dp)
        )

        when (config.type) {
        
            QRType.URL -> {
        
                LineTextField(
                    value = config.url,
                    onValueChange = {
                        onConfigChange(
                            config.copy(
                                url = it,
                                content = it
                            )
                        )
                    },
                    label = "Dirección web",
                    placeholder = "https://ejemplo.com",
                    singleLine = true,
                    isLastField = true
                )
            }
        
            QRType.TEXT -> {
        
                LineTextField(
                    value = config.text,
                    onValueChange = {
                        onConfigChange(
                            config.copy(
                                text = it,
                                content = it
                            )
                        )
                    },
                    label = "Texto",
                    placeholder = "Escribe tu texto...",
                    singleLine = false,
                    minLines = 2
                )
            }
        
            QRType.PHONE -> {
        
                LineTextField(
                    value = config.phone,
                    onValueChange = {
                        onConfigChange(
                            config.copy(
                                phone = it,
                                content = "tel:$it"
                            )
                        )
                    },
                    label = "Teléfono",
                    keyboardType = KeyboardType.Phone,
                    singleLine = true,
                    isLastField = true
                )
            }
        
            QRType.SMS -> {
        
                LineTextField(
                    value = config.smsNumber,
                    onValueChange = {
                        onConfigChange(
                            config.copy(
                                smsNumber = it,
                                content = "SMSTO:$it:${config.smsMessage}"
                            )
                        )
                    },
                    label = "Número",
                    keyboardType = KeyboardType.Phone,
                    singleLine = true
                )
        
                Spacer(
                    modifier = Modifier.height(4.dp)
                )
        
                LineTextField(
                    value = config.smsMessage,
                    onValueChange = {
                        onConfigChange(
                            config.copy(
                                smsMessage = it,
                                content = "SMSTO:${config.smsNumber}:$it"
                            )
                        )
                    },
                    label = "Mensaje",
                    placeholder = "Escribe el mensaje...",
                    minLines = 2,
                    singleLine = false
                )
            }
        
            QRType.LOCATION -> {
        
                LineTextField(
                    value = config.latitude,
                    onValueChange = {
                        onConfigChange(
                            config.copy(
                                latitude = it,
                                content = "geo:$it,${config.longitude}"
                            )
                        )
                    },
                    label = "Latitud",
                    keyboardType = KeyboardType.Decimal,
                    singleLine = true
                )
        
                Spacer(
                    modifier = Modifier.height(12.dp)
                )
        
                LineTextField(
                    value = config.longitude,
                    onValueChange = {
                        onConfigChange(
                            config.copy(
                                longitude = it,
                                content = "geo:${config.latitude},$it"
                            )
                        )
                    },
                    label = "Longitud",
                    keyboardType = KeyboardType.Decimal,
                    singleLine = true
                )
        
                Spacer(
                    modifier = Modifier.height(4.dp)
                )
        
                LineTextField(
                    value = config.locationName,
                    onValueChange = {
                        onConfigChange(
                            config.copy(
                                locationName = it
                            )
                        )
                    },
                    label = "Nombre (opcional)",
                    placeholder = "Madrid",
                    singleLine = true,
                    isLastField = true
                )
            }
            
            QRType.WIFI -> {
            
                LineTextField(
                    value = config.wifiName,
                    onValueChange = {
                        onConfigChange(
                            config.copy(
                                wifiName = it,
                                content = "WIFI:T:${config.wifiSecurity};S:$it;P:${config.wifiPassword};;"
                            )
                        )
                    },
                    label = "SSID",
                    placeholder = "Nombre de red",
                    singleLine = true
                )
            
                Spacer(
                    modifier = Modifier.height(4.dp)
                )
            
                LineTextField(
                    value = config.wifiPassword,
                    onValueChange = {
                        onConfigChange(
                            config.copy(
                                wifiPassword = it,
                                content = "WIFI:T:${config.wifiSecurity};S:${config.wifiName};P:$it;;"
                            )
                        )
                    },
                    label = "Contraseña",
                    placeholder = "Password",
                    singleLine = true,
                    isLastField = true
                )
            
                Spacer(
                    modifier = Modifier.height(12.dp)
                )
            
                Text("Seguridad")
            
                Spacer(
                    modifier = Modifier.height(6.dp)
                )
            
                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                
                    if (config.wifiSecurity == "WPA") {
                        Button(
                            onClick = {
                                onConfigChange(
                                    config.copy(
                                        wifiSecurity = "WPA",
                                        content = buildWifiContent(
                                            config.wifiName,
                                            config.wifiPassword,
                                            "WPA",
                                            config.wifiHidden
                                        )
                                    )
                                )
                            }
                        ) {
                            Text("WPA")
                        }
                    } else {
                        OutlinedButton(
                            onClick = {
                                onConfigChange(
                                    config.copy(
                                        wifiSecurity = "WPA",
                                        content = buildWifiContent(
                                            config.wifiName,
                                            config.wifiPassword,
                                            "WPA",
                                            config.wifiHidden
                                        )
                                    )
                                )
                            }
                        ) {
                            Text("WPA")
                        }
                    }
                
                    if (config.wifiSecurity == "WEP") {
                        Button(
                            onClick = {
                                onConfigChange(
                                    config.copy(
                                        wifiSecurity = "WEP",
                                        content = buildWifiContent(
                                            config.wifiName,
                                            config.wifiPassword,
                                            "WEP",
                                            config.wifiHidden
                                        )
                                    )
                                )
                            }
                        ) {
                            Text("WEP")
                        }
                    } else {
                        OutlinedButton(
                            onClick = {
                                onConfigChange(
                                    config.copy(
                                        wifiSecurity = "WEP",
                                        content = buildWifiContent(
                                            config.wifiName,
                                            config.wifiPassword,
                                            "WEP",
                                            config.wifiHidden
                                        )
                                    )
                                )
                            }
                        ) {
                            Text("WEP")
                        }
                    }
                
                    if (config.wifiSecurity == "nopass") {
                        Button(
                            onClick = {
                                onConfigChange(
                                    config.copy(
                                        wifiSecurity = "nopass",
                                        content = buildWifiContent(
                                            config.wifiName,
                                            config.wifiPassword,
                                            "nopass",
                                            config.wifiHidden
                                        )
                                    )
                                )
                            }
                        ) {
                            Text("Ninguna")
                        }
                    } else {
                        OutlinedButton(
                            onClick = {
                                onConfigChange(
                                    config.copy(
                                        wifiSecurity = "nopass",
                                        content = buildWifiContent(
                                            config.wifiName,
                                            config.wifiPassword,
                                            "nopass",
                                            config.wifiHidden
                                        )
                                    )
                                )
                            }
                        ) {
                            Text("Ninguna")
                        }
                    }
                }
            }
            
            QRType.CONTACT -> {
            
                LineTextField(
                    value = config.contactFirstName,
                    onValueChange = {
                        onConfigChange(
                            config.copy(
                                contactFirstName = it,
                                content = buildContactContent(
                                    it,
                                    config.contactPhone,
                                    config.contactEmail,
                                    config.contactCompany,
                                    config.contactAddress,
                                    config.contactWebsite
                                )
                            )
                        )
                    },
                    label = "Nombre",
                    singleLine = true
                )
            
                Spacer(
                    modifier = Modifier.height(2.dp)
                )
            
                LineTextField(
                    value = config.contactPhone,
                    onValueChange = {
                        onConfigChange(
                            config.copy(
                                contactPhone = it,
                                content = buildContactContent(
                                    config.contactFirstName,
                                    it,
                                    config.contactEmail,
                                    config.contactCompany,
                                    config.contactAddress,
                                    config.contactWebsite
                                )
                            )
                        )
                    },
                    label = "Teléfono",
                    keyboardType = KeyboardType.Phone,
                    singleLine = true
                )
            
                Spacer(
                    modifier = Modifier.height(2.dp)
                )
            
                LineTextField(
                    value = config.contactEmail,
                    onValueChange = {
                        onConfigChange(
                            config.copy(
                                contactEmail = it,
                                content = buildContactContent(
                                    config.contactFirstName,
                                    config.contactPhone,
                                    it,
                                    config.contactCompany,
                                    config.contactAddress,
                                    config.contactWebsite
                                )
                            )
                        )
                    },
                    label = "Email",
                    singleLine = true
                )
            
                Spacer(
                    modifier = Modifier.height(2.dp)
                )
            
                LineTextField(
                    value = config.contactCompany,
                    onValueChange = {
                        onConfigChange(
                            config.copy(
                                contactCompany = it,
                                content = buildContactContent(
                                    config.contactFirstName,
                                    config.contactPhone,
                                    config.contactEmail,
                                    it,
                                    config.contactAddress,
                                    config.contactWebsite
                                )
                            )
                        )
                    },
                    label = "Empresa",
                    singleLine = true
                )
            
                Spacer(
                    modifier = Modifier.height(2.dp)
                )
            
                LineTextField(
                    value = config.contactAddress,
                    onValueChange = {
                        onConfigChange(
                            config.copy(
                                contactAddress = it,
                                content = buildContactContent(
                                    config.contactFirstName,
                                    config.contactPhone,
                                    config.contactEmail,
                                    config.contactCompany,
                                    it,
                                    config.contactWebsite
                                )
                            )
                        )
                    },
                    label = "Dirección",
                    singleLine = true
                )
            
                Spacer(
                    modifier = Modifier.height(2.dp)
                )
            
                LineTextField(
                    value = config.contactWebsite,
                    onValueChange = {
                        onConfigChange(
                            config.copy(
                                contactWebsite = it,
                                content = buildContactContent(
                                    config.contactFirstName,
                                    config.contactPhone,
                                    config.contactEmail,
                                    config.contactCompany,
                                    config.contactAddress,
                                    it
                                )
                            )
                        )
                    },
                    label = "Web",
                    placeholder = "https://ejemplo.com",
                    singleLine = true,
                    isLastField = true
                )
                
                Spacer(
                    modifier = Modifier.height(4.dp)
                )
            }
                        
            QRType.EMAIL -> {
            
                LineTextField(
                    value = config.emailAddress,
                    onValueChange = {
                        onConfigChange(
                            config.copy(
                                emailAddress = it,
                                content = "mailto:$it?subject=${config.emailSubject}&body=${config.emailMessage}"
                            )
                        )
                    },
                    label = "Correo electrónico",
                    placeholder = "correo@ejemplo.com",
                    singleLine = true
                )
            
                Spacer(
                    modifier = Modifier.height(4.dp)
                )
            
                LineTextField(
                    value = config.emailSubject,
                    onValueChange = {
                        onConfigChange(
                            config.copy(
                                emailSubject = it,
                                content = "mailto:${config.emailAddress}?subject=$it&body=${config.emailMessage}"
                            )
                        )
                    },
                    label = "Asunto",
                    singleLine = true
                )
            
                Spacer(
                    modifier = Modifier.height(4.dp)
                )
            
                LineTextField(
                    value = config.emailMessage,
                    onValueChange = {
                        onConfigChange(
                            config.copy(
                                emailMessage = it,
                                content = "mailto:${config.emailAddress}?subject=${config.emailSubject}&body=$it"
                            )
                        )
                    },
                    label = "Mensaje",
                    minLines = 2,
                    singleLine = false
                )
            }
        }
    }
}

@Composable
private fun DesignTab(
    config: QRConfig,
    onConfigChange: (QRConfig) -> Unit
) {

    Column {

        Text(
            text = "Diseño del QR",
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold
        )

        Spacer(
            modifier = Modifier.height(20.dp)
        )

        // =========================
        // MÓDULOS
        // =========================

        Text(
            text = "Forma de los módulos",
            fontWeight = FontWeight.SemiBold
        )

        Spacer(
            modifier = Modifier.height(8.dp)
        )

        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {

            item {
                ModuleStylePreview(
                    selected = config.moduleStyle == ModuleStyle.DOTS,
                    drawableId = com.alehei.qrpromax.R.drawable.module_dot,
                    onClick = {
                        onConfigChange(
                            config.copy(
                                moduleStyle = ModuleStyle.DOTS
                            )
                        )
                    }
                )
            }

            item {
                ModuleStylePreview(
                    selected = config.moduleStyle == ModuleStyle.HEART,
                    drawableId = com.alehei.qrpromax.R.drawable.module_heart,
                    onClick = {
                        onConfigChange(
                            config.copy(
                                moduleStyle = ModuleStyle.HEART
                            )
                        )
                    }
                )
            }

            item {
                ModuleStylePreview(
                    selected = config.moduleStyle == ModuleStyle.HEXAGON,
                    drawableId = com.alehei.qrpromax.R.drawable.module_hexagon,
                    onClick = {
                        onConfigChange(
                            config.copy(
                                moduleStyle = ModuleStyle.HEXAGON
                            )
                        )
                    }
                )
            }

            item {
                ModuleStylePreview(
                    selected = config.moduleStyle == ModuleStyle.ROUNDED,
                    drawableId = com.alehei.qrpromax.R.drawable.module_rounded,
                    onClick = {
                        onConfigChange(
                            config.copy(
                                moduleStyle = ModuleStyle.ROUNDED
                            )
                        )
                    }
                )
            }

            item {
                ModuleStylePreview(
                    selected = config.moduleStyle == ModuleStyle.SQUARE,
                    drawableId = com.alehei.qrpromax.R.drawable.module_square,
                    onClick = {
                        onConfigChange(
                            config.copy(
                                moduleStyle = ModuleStyle.SQUARE
                            )
                        )
                    }
                )
            }

            item {
                ModuleStylePreview(
                    selected = config.moduleStyle == ModuleStyle.STAR,
                    drawableId = com.alehei.qrpromax.R.drawable.module_star,
                    onClick = {
                        onConfigChange(
                            config.copy(
                                moduleStyle = ModuleStyle.STAR
                            )
                        )
                    }
                )
            }

            item {
                ModuleStylePreview(
                    selected = config.moduleStyle == ModuleStyle.TRIANGLE,
                    drawableId = com.alehei.qrpromax.R.drawable.module_triangle,
                    onClick = {
                        onConfigChange(
                            config.copy(
                                moduleStyle = ModuleStyle.TRIANGLE
                            )
                        )
                    }
                )
            }
            
            item {
                ModuleStylePreview(
                    selected = config.moduleStyle == ModuleStyle.CLOVER,
                    drawableId = com.alehei.qrpromax.R.drawable.module_clover,
                    onClick = {
                        onConfigChange(
                            config.copy(
                                moduleStyle = ModuleStyle.CLOVER
                            )
                        )
                    }
                )
            }
            
            item {
                ModuleStylePreview(
                    selected = config.moduleStyle == ModuleStyle.PIECE,
                    drawableId = com.alehei.qrpromax.R.drawable.module_piece,
                    onClick = {
                        onConfigChange(
                            config.copy(
                                moduleStyle = ModuleStyle.PIECE
                            )
                        )
                    }
                )
            }
            
            item {
                ModuleStylePreview(
                    selected = config.moduleStyle == ModuleStyle.MSG,
                    drawableId = com.alehei.qrpromax.R.drawable.module_msg,
                    onClick = {
                        onConfigChange(
                            config.copy(
                                moduleStyle = ModuleStyle.MSG
                            )
                        )
                    }
                )
            }
            
            item {
                ModuleStylePreview(
                    selected = config.moduleStyle == ModuleStyle.LIKE,
                    drawableId = com.alehei.qrpromax.R.drawable.module_like,
                    onClick = {
                        onConfigChange(
                            config.copy(
                                moduleStyle = ModuleStyle.LIKE
                            )
                        )
                    }
                )
            }
        }

        Spacer(
            modifier = Modifier.height(24.dp)
        )

        // =========================
        // OJOS
        // =========================

        Text(
            text = "Forma de los ojos",
            fontWeight = FontWeight.SemiBold
        )

        Spacer(
            modifier = Modifier.height(8.dp)
        )

        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {

            item {
                EyeStylePreview(
                    selected = config.eyeStyle == EyeStyle.CIRCLE,
                    drawableId = com.alehei.qrpromax.R.drawable.eye_circle,
                    onClick = {
                        onConfigChange(
                            config.copy(
                                eyeStyle = EyeStyle.CIRCLE
                            )
                        )
                    }
                )
            }

            item {
                EyeStylePreview(
                    selected = config.eyeStyle == EyeStyle.BOW,
                    drawableId = com.alehei.qrpromax.R.drawable.eye_bow,
                    onClick = {
                        onConfigChange(
                            config.copy(
                                eyeStyle = EyeStyle.BOW
                            )
                        )
                    }
                )
            }

            item {
                EyeStylePreview(
                    selected = config.eyeStyle == EyeStyle.FLOWER,
                    drawableId = com.alehei.qrpromax.R.drawable.eye_flower,
                    onClick = {
                        onConfigChange(
                            config.copy(
                                eyeStyle = EyeStyle.FLOWER
                            )
                        )
                    }
                )
            }

            item {
                EyeStylePreview(
                    selected = config.eyeStyle == EyeStyle.ROUNDED,
                    drawableId = com.alehei.qrpromax.R.drawable.eye_rounded,
                    onClick = {
                        onConfigChange(
                            config.copy(
                                eyeStyle = EyeStyle.ROUNDED
                            )
                        )
                    }
                )
            }

            item {
                EyeStylePreview(
                    selected = config.eyeStyle == EyeStyle.OCTAGON,
                    drawableId = com.alehei.qrpromax.R.drawable.eye_octagon,
                    onClick = {
                        onConfigChange(
                            config.copy(
                                eyeStyle = EyeStyle.OCTAGON
                            )
                        )
                    }
                )
            }

            item {
                EyeStylePreview(
                    selected = config.eyeStyle == EyeStyle.SQUARE,
                    drawableId = com.alehei.qrpromax.R.drawable.eye_square,
                    onClick = {
                        onConfigChange(
                            config.copy(
                                eyeStyle = EyeStyle.SQUARE
                            )
                        )
                    }
                )
            }
            
            item {
                EyeStylePreview(
                    selected = config.eyeStyle == EyeStyle.PUZZLE,
                    drawableId = com.alehei.qrpromax.R.drawable.eye_puzzle,
                    onClick = {
                        onConfigChange(
                            config.copy(
                                eyeStyle = EyeStyle.PUZZLE
                            )
                        )
                    }
                )
            }
            
            item {
                EyeStylePreview(
                    selected = config.eyeStyle == EyeStyle.DROP,
                    drawableId = com.alehei.qrpromax.R.drawable.eye_drop,
                    onClick = {
                        onConfigChange(
                            config.copy(
                                eyeStyle = EyeStyle.DROP
                            )
                        )
                    }
                )
            }
        }

        Spacer(
            modifier = Modifier.height(24.dp)
        )

        // =========================
        // CORRECCIÓN DE ERRORES
        // =========================

        Text(
            text = "Corrección de errores",
            fontWeight = FontWeight.SemiBold
        )

        Spacer(
            modifier = Modifier.height(8.dp)
        )

        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {

            items(ErrorCorrection.entries) { correction ->

                FilterChip(
                    selected = config.errorCorrection == correction,
                    onClick = {
                        onConfigChange(
                            config.copy(
                                errorCorrection = correction
                            )
                        )
                    },
                    label = {
                        Text(
                            when (correction) {
                                ErrorCorrection.LOW -> "Baja"
                                ErrorCorrection.MEDIUM -> "Media"
                                ErrorCorrection.QUARTILE -> "Alta"
                                ErrorCorrection.HIGH -> "Máxima"
                            }
                        )
                    }
                )
            }
        }

        Spacer(
            modifier = Modifier.height(24.dp)
        )

        QRColorSelector(
            selectedColor = config.foregroundColor,
            onColorChange = { color ->
                onConfigChange(
                    config.copy(
                        foregroundColor = color
                    )
                )
            }
        )
    }
}

@Composable
private fun ModuleStylePreview(
    selected: Boolean,
    drawableId: Int,
    onClick: () -> Unit
) {

    Surface(
        modifier = Modifier
            .size(64.dp)
            .clickable {
                onClick()
            },
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(
            width = if (selected) 2.dp else 1.dp,
            color = if (selected) {
                MaterialTheme.colorScheme.primary
            } else {
                MaterialTheme.colorScheme.outline
            }
        ),
        color = MaterialTheme.colorScheme.surface
    ) {

        Box(
            contentAlignment = Alignment.Center
        ) {

            androidx.compose.foundation.Image(
                painter = painterResource(drawableId),
                contentDescription = null,
                modifier = Modifier.size(34.dp),
                contentScale = ContentScale.Fit,
                colorFilter = ColorFilter.tint(
                    MaterialTheme.colorScheme.onSurface
                )
            )
        }
    }
}

@Composable
private fun EyeStylePreview(
    selected: Boolean,
    drawableId: Int,
    onClick: () -> Unit
) {

    Surface(
        modifier = Modifier
            .size(64.dp)
            .clickable {
                onClick()
            },
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(
            width = if (selected) 2.dp else 1.dp,
            color = if (selected) {
                MaterialTheme.colorScheme.primary
            } else {
                MaterialTheme.colorScheme.outline
            }
        ),
        color = MaterialTheme.colorScheme.surface
    ) {

        Box(
            contentAlignment = Alignment.Center
        ) {

            // Capa exterior
            androidx.compose.foundation.Image(
                painter = painterResource(drawableId),
                contentDescription = null,
                modifier = Modifier.size(46.dp),
                contentScale = ContentScale.Fit,
                colorFilter = ColorFilter.tint(
                    MaterialTheme.colorScheme.onSurface
                )
            )

            // Capa blanca
            androidx.compose.foundation.Image(
                painter = painterResource(drawableId),
                contentDescription = null,
                modifier = Modifier.size(32.dp),
                contentScale = ContentScale.Fit,
                colorFilter = ColorFilter.tint(
                    MaterialTheme.colorScheme.surface
                )
            )

            // Centro
            androidx.compose.foundation.Image(
                painter = painterResource(drawableId),
                contentDescription = null,
                modifier = Modifier.size(19.dp),
                contentScale = ContentScale.Fit,
                colorFilter = ColorFilter.tint(
                    MaterialTheme.colorScheme.onSurface
                )
            )
        }
    }
}

@Composable
private fun QRColorSelector(
    selectedColor: Color,
    onColorChange: (Color) -> Unit
) {
    val colors = listOf(
        Color.Black,
        Color(0xFF1565C0),
        Color(0xFFC62828),
        Color(0xFF2E7D32),
        Color(0xFF6A1B9A),
        Color(0xFFAD1457),
        Color(0xFFE65100),
        Color(0xFF5D4037)
    )

    var showColorDialog by remember {
        mutableStateOf(false)
    }

    Text(
        text = "Color del QR",
        fontWeight = FontWeight.SemiBold
    )
    Spacer(
        modifier = Modifier.height(10.dp)
    )

    LazyRow(
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {

        items(colors) { color ->

            Box(
                modifier = Modifier
                    .size(42.dp)
                    .background(
                        color = color,
                        shape = CircleShape
                    )
                    .border(
                        width = if (selectedColor == color) {
                            3.dp
                        } else {
                            1.dp
                        },
                        color = if (selectedColor == color) {
                            MaterialTheme.colorScheme.primary
                        } else {
                            MaterialTheme.colorScheme.outline
                        },
                        shape = CircleShape
                    )
                    .clickable {
                        onColorChange(color)
                    }
            )
        }

        item {

            Box(
                modifier = Modifier
                    .size(42.dp)
                    .border(
                        width = 1.dp,
                        color = MaterialTheme.colorScheme.outline,
                        shape = CircleShape
                    )
                    .clickable {
                        showColorDialog = true
                    },
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "+",
                    fontSize = 22.sp
                )
            }
        }
    }

    if (showColorDialog) {

        CustomColorDialog(
            initialColor = selectedColor,
            onDismiss = {
                showColorDialog = false
            },
            onColorSelected = { color ->
                onColorChange(color)
                showColorDialog = false
            }
        )
    }
}

@Composable
private fun CustomColorDialog(
    initialColor: Color,
    onDismiss: () -> Unit,
    onColorSelected: (Color) -> Unit
) {
    var hex by remember {
        mutableStateOf(
            String.format(
                "#%06X",
                initialColor.toArgb() and 0xFFFFFF
            )
        )
    }

    AlertDialog(
        onDismissRequest = onDismiss,

        title = {
            Text("Color personalizado")
        },

        text = {

            OutlinedTextField(
                value = hex,
                onValueChange = { value ->

                    var clean = value
                        .uppercase()
                        .replace("#", "")
                        .take(6)

                    hex = "#$clean"
                },
                label = {
                    Text("HEX")
                },
                placeholder = {
                    Text("#4285F4")
                },
                singleLine = true
            )
        },

        confirmButton = {

            TextButton(
                onClick = {

                    val clean = hex
                        .removePrefix("#")

                    if (clean.length == 6) {

                        try {

                            val color = Color(
                                android.graphics.Color.parseColor(
                                    "#$clean"
                                )
                            )

                            onColorSelected(color)

                        } catch (_: Exception) {
                        }
                    }
                }
            ) {
                Text("OK")
            }
        },

        dismissButton = {

            TextButton(
                onClick = onDismiss
            ) {
                Text("Cancelar")
            }
        }
    )
}

@Composable
private fun LogoTab(
    config: QRConfig,
    onConfigChange: (QRConfig) -> Unit
) {
    Column {
        Text(
            text = "Logo",
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold
        )

        Spacer(modifier = Modifier.height(12.dp))

        Text(
            text = "Elige un logo para el centro del QR",
            fontSize = 14.sp
        )

        Spacer(modifier = Modifier.height(12.dp))

        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {

            item {
                LogoPreview(
                    selected = !config.logoEnabled,
                    drawableId = R.drawable.logo_none,
                    onClick = {
                        onConfigChange(
                            config.copy(
                                logoEnabled = false,
                                logoResId = null
                            )
                        )
                    }
                )
            }

            item {
                LogoPreview(
                    selected = config.logoResId == R.drawable.logo_android,
                    drawableId = R.drawable.logo_android,
                    onClick = {
                        onConfigChange(
                            config.copy(
                                logoEnabled = true,
                                logoResId = R.drawable.logo_android,
                                logoAssetName = "android"
                            )
                        )
                    }
                )
            }

            item {
                LogoPreview(
                    selected = config.logoResId == R.drawable.logo_google,
                    drawableId = R.drawable.logo_google,
                    onClick = {
                        onConfigChange(
                            config.copy(
                                logoEnabled = true,
                                logoResId = R.drawable.logo_google,
                                logoAssetName = "google"
                            )
                        )
                    }
                )
            }
            
            item {
                LogoPreview(
                    selected = config.logoResId == R.drawable.logo_youtube,
                    drawableId = R.drawable.logo_youtube,
                    onClick = {
                        onConfigChange(
                            config.copy(
                                logoEnabled = true,
                                logoResId = R.drawable.logo_youtube,
                                logoAssetName = "youtube"
                            )
                        )
                    }
                )
            }
            
            item {
                LogoPreview(
                    selected = config.logoResId == R.drawable.logo_gmaps,
                    drawableId = R.drawable.logo_gmaps,
                    onClick = {
                        onConfigChange(
                            config.copy(
                                logoEnabled = true,
                                logoResId = R.drawable.logo_gmaps,
                                logoAssetName = "gmaps"
                            )
                        )
                    }
                )
            }
            
            item {
                LogoPreview(
                    selected = config.logoResId == R.drawable.logo_playstore,
                    drawableId = R.drawable.logo_playstore,
                    onClick = {
                        onConfigChange(
                            config.copy(
                                logoEnabled = true,
                                logoResId = R.drawable.logo_playstore,
                                logoAssetName = "playstore"
                            )
                        )
                    }
                )
            }
            
            item {
                LogoPreview(
                    selected = config.logoResId == R.drawable.logo_apple,
                    drawableId = R.drawable.logo_apple,
                    onClick = {
                        onConfigChange(
                            config.copy(
                                logoEnabled = true,
                                logoResId = R.drawable.logo_apple,
                                logoAssetName = "apple"
                            )
                        )
                    }
                )
            }

            item {
                LogoPreview(
                    selected = config.logoResId == R.drawable.logo_appstore,
                    drawableId = R.drawable.logo_appstore,
                    onClick = {
                        onConfigChange(
                            config.copy(
                                logoEnabled = true,
                                logoResId = R.drawable.logo_appstore,
                                logoAssetName = "appstore"
                            )
                        )
                    }
                )
            }
            
            item {
                LogoPreview(
                    selected = config.logoResId == R.drawable.logo_facebook,
                    drawableId = R.drawable.logo_facebook,
                    onClick = {
                        onConfigChange(
                            config.copy(
                                logoEnabled = true,
                                logoResId = R.drawable.logo_facebook,
                                logoAssetName = "facebook"
                            )
                        )
                    }
                )
            }

            item {
                LogoPreview(
                    selected = config.logoResId == R.drawable.logo_instagram,
                    drawableId = R.drawable.logo_instagram,
                    onClick = {
                        onConfigChange(
                            config.copy(
                                logoEnabled = true,
                                logoResId = R.drawable.logo_instagram,
                                logoAssetName = "instagram"
                            )
                        )
                    }
                )
            }
            
            item {
                LogoPreview(
                    selected = config.logoResId == R.drawable.logo_whatsapp,
                    drawableId = R.drawable.logo_whatsapp,
                    onClick = {
                        onConfigChange(
                            config.copy(
                                logoEnabled = true,
                                logoResId = R.drawable.logo_whatsapp,
                                logoAssetName = "whatsapp"
                            )
                        )
                    }
                )
            }
            
            item {
                LogoPreview(
                    selected = config.logoResId == R.drawable.logo_telegram,
                    drawableId = R.drawable.logo_telegram,
                    onClick = {
                        onConfigChange(
                            config.copy(
                                logoEnabled = true,
                                logoResId = R.drawable.logo_telegram,
                                logoAssetName = "telegram"
                            )
                        )
                    }
                )
            }
                        
            item {
                LogoPreview(
                    selected = config.logoResId == R.drawable.logo_twitter,
                    drawableId = R.drawable.logo_twitter,
                    onClick = {
                        onConfigChange(
                            config.copy(
                                logoEnabled = true,
                                logoResId = R.drawable.logo_twitter,
                                logoAssetName = "twitter"
                            )
                        )
                    }
                )
            }
            
            item {
                LogoPreview(
                    selected = config.logoResId == R.drawable.logo_x,
                    drawableId = R.drawable.logo_x,
                    onClick = {
                        onConfigChange(
                            config.copy(
                                logoEnabled = true,
                                logoResId = R.drawable.logo_x,
                                logoAssetName = "x"
                            )
                        )
                    }
                )
            }
                        
            item {
                LogoPreview(
                    selected = config.logoResId == R.drawable.logo_pinterest,
                    drawableId = R.drawable.logo_pinterest,
                    onClick = {
                        onConfigChange(
                            config.copy(
                                logoEnabled = true,
                                logoResId = R.drawable.logo_pinterest,
                                logoAssetName = "pinterest"
                            )
                        )
                    }
                )
            }
            
            item {
                LogoPreview(
                    selected = config.logoResId == R.drawable.logo_tiktok,
                    drawableId = R.drawable.logo_tiktok,
                    onClick = {
                        onConfigChange(
                            config.copy(
                                logoEnabled = true,
                                logoResId = R.drawable.logo_tiktok,
                                logoAssetName = "tiktok"
                            )
                        )
                    }
                )
            }
            
            item {
                LogoPreview(
                    selected = config.logoResId == R.drawable.logo_movistar,
                    drawableId = R.drawable.logo_movistar,
                    onClick = {
                        onConfigChange(
                            config.copy(
                                logoEnabled = true,
                                logoResId = R.drawable.logo_movistar,
                                logoAssetName = "movistar"
                            )
                        )
                    }
                )
            }
                                    
            item {
                LogoPreview(
                    selected = config.logoResId == R.drawable.logo_cash,
                    drawableId = R.drawable.logo_cash,
                    onClick = {
                        onConfigChange(
                            config.copy(
                                logoEnabled = true,
                                logoResId = R.drawable.logo_cash,
                                logoAssetName = "cash"
                            )
                        )
                    }
                )
            }
            
            item {
                LogoPreview(
                    selected = config.logoResId == R.drawable.logo_minipay,
                    drawableId = R.drawable.logo_minipay,
                    onClick = {
                        onConfigChange(
                            config.copy(
                                logoEnabled = true,
                                logoResId = R.drawable.logo_minipay,
                                logoAssetName = "minipay"
                            )
                        )
                    }
                )
            }
            
            item {
                LogoPreview(
                    selected = config.logoResId == R.drawable.logo_paypal,
                    drawableId = R.drawable.logo_paypal,
                    onClick = {
                        onConfigChange(
                            config.copy(
                                logoEnabled = true,
                                logoResId = R.drawable.logo_paypal,
                                logoAssetName = "paypal"
                            )
                        )
                    }
                )
            }
                        
            item {
                LogoPreview(
                    selected = config.logoResId == R.drawable.logo_amazon,
                    drawableId = R.drawable.logo_amazon,
                    onClick = {
                        onConfigChange(
                            config.copy(
                                logoEnabled = true,
                                logoResId = R.drawable.logo_amazon,
                                logoAssetName = "amazon"
                            )
                        )
                    }
                )
            }
            
            item {
                LogoPreview(
                    selected = config.logoResId == R.drawable.logo_twich,
                    drawableId = R.drawable.logo_twich,
                    onClick = {
                        onConfigChange(
                            config.copy(
                                logoEnabled = true,
                                logoResId = R.drawable.logo_twich,
                                logoAssetName = "twich"
                            )
                        )
                    }
                )
            }
                        
            item {
                LogoPreview(
                    selected = config.logoResId == R.drawable.logo_link,
                    drawableId = R.drawable.logo_link,
                    onClick = {
                        onConfigChange(
                            config.copy(
                                logoEnabled = true,
                                logoResId = R.drawable.logo_link,
                                logoAssetName = "link"
                            )
                        )
                    }
                )
            }
            
            item {
                LogoPreview(
                    selected = config.logoResId == R.drawable.logo_text,
                    drawableId = R.drawable.logo_text,
                    onClick = {
                        onConfigChange(
                            config.copy(
                                logoEnabled = true,
                                logoResId = R.drawable.logo_text,
                                logoAssetName = "text"
                            )
                        )
                    }
                )
            }
            
            item {
                LogoPreview(
                    selected = config.logoResId == R.drawable.logo_wifi,
                    drawableId = R.drawable.logo_wifi,
                    onClick = {
                        onConfigChange(
                            config.copy(
                                logoEnabled = true,
                                logoResId = R.drawable.logo_wifi,
                                logoAssetName = "wifi"
                            )
                        )
                    }
                )
            }
            
            item {
                LogoPreview(
                    selected = config.logoResId == R.drawable.logo_contact,
                    drawableId = R.drawable.logo_contact,
                    onClick = {
                        onConfigChange(
                            config.copy(
                                logoEnabled = true,
                                logoResId = R.drawable.logo_contact,
                                logoAssetName = "contact"
                            )
                        )
                    }
                )
            }
            
            item {
                LogoPreview(
                    selected = config.logoResId == R.drawable.logo_mail,
                    drawableId = R.drawable.logo_mail,
                    onClick = {
                        onConfigChange(
                            config.copy(
                                logoEnabled = true,
                                logoResId = R.drawable.logo_mail,
                                logoAssetName = "mail"
                            )
                        )
                    }
                )
            }
            
            item {
                LogoPreview(
                    selected = config.logoResId == R.drawable.logo_phone,
                    drawableId = R.drawable.logo_phone,
                    onClick = {
                        onConfigChange(
                            config.copy(
                                logoEnabled = true,
                                logoResId = R.drawable.logo_phone,
                                logoAssetName = "phone"
                            )
                        )
                    }
                )
            }
            
            item {
                LogoPreview(
                    selected = config.logoResId == R.drawable.logo_sms,
                    drawableId = R.drawable.logo_sms,
                    onClick = {
                        onConfigChange(
                            config.copy(
                                logoEnabled = true,
                                logoResId = R.drawable.logo_sms,
                                logoAssetName = "sms"
                            )
                        )
                    }
                )
            }
            
            item {
                LogoPreview(
                    selected = config.logoResId == R.drawable.logo_location,
                    drawableId = R.drawable.logo_location,
                    onClick = {
                        onConfigChange(
                            config.copy(
                                logoEnabled = true,
                                logoResId = R.drawable.logo_location,
                                logoAssetName = "location"
                            )
                        )
                    }
                )
            }
            
            

        }
    }
}

@Composable
private fun LogoPreview(
    selected: Boolean,
    drawableId: Int,
    onClick: () -> Unit
) {
    Surface(
        modifier = Modifier
            .size(64.dp)
            .clickable { onClick() },
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(
            width = if (selected) 2.dp else 1.dp,
            color = if (selected)
                MaterialTheme.colorScheme.primary
            else
                MaterialTheme.colorScheme.outline
        ),
        color = MaterialTheme.colorScheme.surface
    ) {
        Box(
            contentAlignment = Alignment.Center
        ) {
            Image(
                painter = painterResource(drawableId),
                contentDescription = null,
                modifier = Modifier.size(38.dp),
                contentScale = ContentScale.Fit,
            )
        }
    }
}

@Composable
fun LineTextField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    placeholder: String = "",
    singleLine: Boolean = true,
    minLines: Int = 1,
    isLastField: Boolean = false,
    keyboardType: KeyboardType = KeyboardType.Text
) {

    val focusManager = LocalFocusManager.current

    val imeAction = when {
        !singleLine -> ImeAction.Default
        isLastField -> ImeAction.Done
        else -> ImeAction.Next
    }

    androidx.compose.material3.TextField(
        value = value,
        onValueChange = onValueChange,
        modifier = Modifier.fillMaxWidth(),
        label = {
            Text(label)
        },
        placeholder = {
            if (placeholder.isNotEmpty()) {
                Text(placeholder)
            }
        },
        singleLine = singleLine,
        minLines = minLines,

        keyboardOptions = KeyboardOptions(
            keyboardType = keyboardType,
            imeAction = imeAction
        ),

        keyboardActions = KeyboardActions(
            onNext = {
                focusManager.moveFocus(
                    FocusDirection.Down
                )
            },
            onDone = {
                focusManager.clearFocus()
            }
        ),

        colors = androidx.compose.material3.TextFieldDefaults.colors(
            focusedContainerColor = androidx.compose.ui.graphics.Color.Transparent,
            unfocusedContainerColor = androidx.compose.ui.graphics.Color.Transparent,
            disabledContainerColor = androidx.compose.ui.graphics.Color.Transparent,
            errorContainerColor = androidx.compose.ui.graphics.Color.Transparent
        )
    )
}

fun buildContactContent(
    name: String,
    phone: String,
    email: String,
    company: String,
    address: String,
    website: String
): String {
    return "BEGIN:VCARD\n" +
            "VERSION:3.0\n" +
            "FN:$name\n" +
            "TEL:$phone\n" +
            "EMAIL:$email\n" +
            "ORG:$company\n" +
            "ADR:;;$address\n" +
            "URL:$website\n" +
            "END:VCARD"
}

private fun buildWifiContent(
    name: String,
    password: String,
    security: String,
    hidden: Boolean
): String {
    val escapedName = name
        .replace("\\", "\\\\")
        .replace(";", "\\;")
        .replace(",", "\\,")
        .replace(":", "\\:")

    val escapedPassword = password
        .replace("\\", "\\\\")
        .replace(";", "\\;")
        .replace(",", "\\,")
        .replace(":", "\\:")

    val hiddenValue = if (hidden) "H:true;" else ""

    return "WIFI:T:$security;S:$escapedName;P:$escapedPassword;$hiddenValue;"
}

private fun changeQRType(
    config: QRConfig,
    newType: QRType
): QRConfig {
    return config.copy(
        type = newType,

        content = "",

        url = "",
        text = "",
        phone = "",

        smsNumber = "",
        smsMessage = "",

        latitude = "",
        longitude = "",
        locationName = "",

        wifiName = "",
        wifiPassword = "",
        wifiSecurity = "WPA",
        wifiHidden = false,

        contactFirstName = "",
        contactLastName = "",
        contactPhone = "",
        contactEmail = "",
        contactCompany = "",
        contactAddress = "",
        contactWebsite = "",

        emailAddress = "",
        emailSubject = "",
        emailMessage = ""
    )
}

private fun clearQRContent(
    config: QRConfig,
    newType: QRType
): QRConfig {
    return config.copy(
        type = newType,

        // Contenido general
        content = "",

        // URL
        url = "",

        // Texto
        text = "",

        // Teléfono
        phone = "",

        // SMS
        smsNumber = "",
        smsMessage = "",

        // Ubicación
        latitude = "",
        longitude = "",
        locationName = "",

        // Wi-Fi
        wifiName = "",
        wifiPassword = "",
        wifiSecurity = "WPA",
        wifiHidden = false,

        // Contacto
        contactFirstName = "",
        contactLastName = "",
        contactPhone = "",
        contactEmail = "",
        contactCompany = "",
        contactAddress = "",
        contactWebsite = "",

        // Email
        emailAddress = "",
        emailSubject = "",
        emailMessage = ""
    )
}