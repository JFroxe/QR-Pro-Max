package com.alehei.qrpromax.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.Button
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.unit.dp
import com.alehei.qrpromax.R
import com.alehei.qrpromax.BuildConfig

@Composable
fun QRSettingsScreen(
    onBack: () -> Unit,
    onSuggest: () -> Unit,
    onShareApp: () -> Unit,
    onRateApp: () -> Unit,
    onAbout: () -> Unit
) {
    
    val versionName = BuildConfig.VERSION_NAME
    
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(24.dp)
    ) {

        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
        
            Text(
                text = "Ajustes",
                style = MaterialTheme.typography.headlineMedium,
                color = MaterialTheme.colorScheme.onBackground,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.weight(1f)
            )
        
            Button(
                onClick = onBack
            ) {
                Text("Volver")
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clickable { onSuggest() }
                .padding(vertical = 16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {

            Image(
                painter = painterResource(R.drawable.icon_suggest),
                colorFilter = ColorFilter.tint(MaterialTheme.colorScheme.onBackground),
                contentDescription = "Sugerir una mejora",
                modifier = Modifier.size(24.dp)
            )

            Spacer(modifier = Modifier.size(16.dp))

            Column {

                Text(
                    text = "Sugerir una mejora",
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onBackground
                )

                Spacer(modifier = Modifier.height(2.dp))

                Text(
                    text = "Ayúdanos a mejorar QR Pro Max",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clickable { onShareApp() }
                .padding(vertical = 16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
        
            Image(
                painter = painterResource(R.drawable.icon_share),
                colorFilter = ColorFilter.tint(
                    MaterialTheme.colorScheme.onBackground
                ),
                contentDescription = "Compartir QR Pro Max",
                modifier = Modifier.size(24.dp)
            )
        
            Spacer(modifier = Modifier.size(16.dp))
        
            Column {
        
                Text(
                    text = "Compartir QR Pro Max",
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onBackground
                )
        
                Spacer(modifier = Modifier.height(2.dp))
        
                Text(
                    text = "Comparte la aplicación con tus amigos",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
                
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clickable { onRateApp() }
                .padding(vertical = 16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
        
            Image(
                painter = painterResource(R.drawable.icon_star),
                colorFilter = ColorFilter.tint(
                    MaterialTheme.colorScheme.onBackground
                ),
                contentDescription = "Calificar QR Pro Max",
                modifier = Modifier.size(24.dp)
            )
        
            Spacer(modifier = Modifier.size(16.dp))
        
            Column {
        
                Text(
                    text = "Calificar en Google Play",
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onBackground
                )
        
                Spacer(modifier = Modifier.height(2.dp))
        
                Text(
                    text = "Déjanos tu valoración",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
        
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clickable { onAbout() }
                .padding(vertical = 16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {

            Image(
                painter = painterResource(R.drawable.icon_info),
                colorFilter = ColorFilter.tint(
                    MaterialTheme.colorScheme.onBackground
                ),
                contentDescription = "Info de la app",
                modifier = Modifier.size(24.dp)
            )
        
            Spacer(modifier = Modifier.size(16.dp))
            
            Column {

                Text(
                    text = "Acerca de QR Pro Max",
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onBackground
                )

                Spacer(modifier = Modifier.height(2.dp))

                Text(
                    text = "Información y créditos",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        Spacer(modifier = Modifier.weight(1f))

        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {

            Text(
                text = "QR Pro Max",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onBackground
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = "Versión $versionName",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        Spacer(modifier = Modifier.height(16.dp))
    }
}