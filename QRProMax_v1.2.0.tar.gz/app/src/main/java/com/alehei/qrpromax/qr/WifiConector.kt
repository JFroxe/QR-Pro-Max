package com.alehei.qrpromax.qr

import android.content.Context
import android.content.Intent
import android.net.wifi.WifiNetworkSuggestion
import android.os.Build
import android.provider.Settings

fun connectToWifi(
    context: Context,
    ssid: String,
    password: String,
    security: String,
    hidden: Boolean = false
): String {

    if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) {
        return "Esta función requiere Android 11 o superior"
    }

    if (ssid.isBlank()) {
        return "El nombre de la red está vacío"
    }

    return try {

        val builder = WifiNetworkSuggestion.Builder()
            .setSsid(ssid)

        if (hidden) {
            builder.setIsHiddenSsid(true)
        }

        when (security.uppercase()) {

            "NONE",
            "" -> {
                // Red abierta
            }

            "WPA",
            "WPA2" -> {
                if (password.isBlank()) {
                    return "La red WPA necesita contraseña"
                }

                builder.setWpa2Passphrase(password)
            }

            "WPA3" -> {
                if (password.isBlank()) {
                    return "La red WPA3 necesita contraseña"
                }

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    builder.setWpa3Passphrase(password)
                } else {
                    return "WPA3 requiere Android 11 o superior"
                }
            }

            "WEP" -> {
                return "Las redes WEP no son compatibles"
            }

            else -> {
                if (password.isBlank()) {
                    return "La red necesita contraseña"
                }

                builder.setWpa2Passphrase(password)
            }
        }

        val suggestion = builder.build()

        val networkList =
            arrayListOf<WifiNetworkSuggestion>()

        networkList.add(suggestion)

        val intent = Intent(
            Settings.ACTION_WIFI_ADD_NETWORKS
        ).apply {

            putParcelableArrayListExtra(
                Settings.EXTRA_WIFI_NETWORK_LIST,
                networkList
            )
        }

        context.startActivity(intent)

        "Conectando..."

    } catch (e: Exception) {

        "ERROR: ${e.javaClass.simpleName}: ${e.message}"
    }
}