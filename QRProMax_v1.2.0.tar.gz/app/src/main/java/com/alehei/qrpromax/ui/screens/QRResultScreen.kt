package com.alehei.qrpromax.ui.screens

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.graphics.Bitmap
import android.widget.Toast
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.clickable
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ripple
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.ui.draw.clip
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.alehei.qrpromax.model.QRConfig
import com.alehei.qrpromax.model.QRSaveFormat
import com.alehei.qrpromax.qr.QRAds
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView

@Composable
fun QRResultScreen(
    config: QRConfig,
    verified: Boolean,
    contrastGood: Boolean,
    bitmap: Bitmap,
    onEdit: () -> Unit,
    onSave: (QRSaveFormat, Int) -> Unit,
    onShare: () -> Unit
) {
    val context = LocalContext.current

    var selectedResolution by remember {
        mutableStateOf(1080)
    }

    var resolutionMenuExpanded by remember {
        mutableStateOf(false)
    }

    var isLoadingResolutionAd by remember {
        mutableStateOf(false)
    }

    /*
     * Guarda las resoluciones premium que ya fueron desbloqueadas
     * mediante Rewarded Ad mientras esta pantalla permanezca abierta.
     *
     * Al salir a "Editar QR", esta pantalla deja de existir y este
     * estado se reinicia. Al generar nuevamente el QR se vuelve a
     * comenzar en 1080 px y habrá que desbloquear nuevamente 2340/4240.
     */
    var unlockedResolutions by remember {
        mutableStateOf(emptySet<Int>())
    }

    fun chooseResolution(
        resolution: Int,
        adUnitId: String? = null
    ) {
        resolutionMenuExpanded = false

        if (isLoadingResolutionAd) {
            return
        }

        /*
         * 720 y 1080 son gratuitas.
         */
        if (adUnitId == null) {
            selectedResolution = resolution
            return
        }

        /*
         * Si esta calidad ya fue desbloqueada durante esta pantalla,
         * simplemente la seleccionamos sin mostrar otro anuncio.
         */
        if (resolution in unlockedResolutions) {
            selectedResolution = resolution
            return
        }

        val activity = context.findActivity()

        if (activity == null) {
            Toast.makeText(
                context,
                "No se pudo abrir el anuncio. Inténtalo de nuevo.",
                Toast.LENGTH_SHORT
            ).show()
            return
        }

        isLoadingResolutionAd = true

        QRAds.showResolutionRewardedAd(
            activity = activity,
            adUnitId = adUnitId,
            onRewarded = {
                /*
                 * El usuario completó el anuncio:
                 * desbloqueamos esta resolución para toda la vida
                 * de esta instancia de QRResultScreen.
                 */
                unlockedResolutions =
                    unlockedResolutions + resolution

                selectedResolution = resolution
                isLoadingResolutionAd = false
            },
            onUnavailable = {
                isLoadingResolutionAd = false

                Toast.makeText(
                    context,
                    "No se completó el anuncio; la calidad no se desbloqueó.",
                    Toast.LENGTH_SHORT
                ).show()
            }
        )
    }

    LaunchedEffect(verified, contrastGood) {
        when {
            !contrastGood -> {
                Toast.makeText(
                    context,
                    "Este QR es poco legible 🫠",
                    Toast.LENGTH_SHORT
                ).show()
            }

            verified -> {
                Toast.makeText(
                    context,
                    "QR verificado 😃",
                    Toast.LENGTH_SHORT
                ).show()
            }

            else -> {
                Toast.makeText(
                    context,
                    "Este QR podría no funcionar 😟",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(
                rememberScrollState()
            )
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Tu código QR",
                modifier = Modifier
                    .weight(1f)
                    .padding(end = 8.dp),
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )

            Box {
                OutlinedButton(
                    onClick = {
                        if (!isLoadingResolutionAd) {
                            resolutionMenuExpanded = true
                        }
                    }
                ) {
                    Text(
                        if (isLoadingResolutionAd) {
                            "Cargando…"
                        } else {
                            "$selectedResolution px ▾"
                        }
                    )
                }

                DropdownMenu(
                    expanded = resolutionMenuExpanded,
                    onDismissRequest = {
                        resolutionMenuExpanded = false
                    }
                ) {
                    DropdownMenuItem(
                        text = { Text("720 px") },
                        onClick = {
                            chooseResolution(720)
                        }
                    )

                    DropdownMenuItem(
                        text = { Text("1080 px") },
                        onClick = {
                            chooseResolution(1080)
                        }
                    )

                    DropdownMenuItem(
                        text = {
                            Text(
                                if (2340 in unlockedResolutions) {
                                    "2340 px · Desbloqueado"
                                } else {
                                    "2340 px · Ver anuncio"
                                }
                            )
                        },
                        onClick = {
                            chooseResolution(
                                2340,
                                QRAds.EXPORT_2340_REWARDED_AD_UNIT_ID
                            )
                        }
                    )

                    DropdownMenuItem(
                        text = {
                            Text(
                                if (4240 in unlockedResolutions) {
                                    "4240 px · Desbloqueado"
                                } else {
                                    "4240 px · Ver anuncio"
                                }
                            )
                        },
                        onClick = {
                            chooseResolution(
                                4240,
                                QRAds.EXPORT_4240_REWARDED_AD_UNIT_ID
                            )
                        }
                    )
                }
            }
        }

        Spacer(
            modifier = Modifier.height(8.dp)
        )

        Text(
            text = config.type.title,
            color = MaterialTheme.colorScheme.onBackground,
            fontSize = 16.sp
        )

        Spacer(
            modifier = Modifier.height(8.dp)
        )

        Image(
            bitmap = bitmap.asImageBitmap(),
            contentDescription = "Código QR generado",
            modifier = Modifier.size(300.dp)
        )

        Spacer(
            modifier = Modifier.height(32.dp)
        )

        var formatMenuExpanded by remember {
            mutableStateOf(false)
        }

        var selectedFormat by remember {
            mutableStateOf(QRSaveFormat.PNG)
        }

        val buttonShape = RoundedCornerShape(percent = 50)

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier
                    .weight(1f)
                    .height(40.dp)
                    .clip(buttonShape)
                    .background(
                        color = MaterialTheme.colorScheme.primary,
                        shape = buttonShape
                    ),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxSize()
                        .clickable(
                            indication = ripple(
                                color = MaterialTheme.colorScheme.onPrimary
                            ),
                            interactionSource = remember {
                                MutableInteractionSource()
                            }
                        ) {
                            onSave(
                                selectedFormat,
                                selectedResolution
                            )
                        },
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Text(
                            text = "Guardar",
                            style = MaterialTheme.typography.labelLarge,
                            color = MaterialTheme.colorScheme.onPrimary
                        )

                        Text(
                            text = selectedFormat.name,
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onPrimary.copy(
                                alpha = 0.7f
                            )
                        )
                    }
                }

                Box(
                    modifier = Modifier
                        .width(1.dp)
                        .height(28.dp)
                        .background(
                            MaterialTheme.colorScheme.onPrimary.copy(
                                alpha = 0.35f
                            )
                        )
                )

                Box(
                    modifier = Modifier
                        .width(48.dp)
                        .fillMaxSize()
                        .clickable(
                            indication = ripple(
                                color = MaterialTheme.colorScheme.onPrimary
                            ),
                            interactionSource = remember {
                                MutableInteractionSource()
                            }
                        ) {
                            formatMenuExpanded = true
                        },
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "▾",
                        color = MaterialTheme.colorScheme.onPrimary
                    )
                }

                DropdownMenu(
                    expanded = formatMenuExpanded,
                    onDismissRequest = {
                        formatMenuExpanded = false
                    }
                ) {
                    DropdownMenuItem(
                        text = {
                            Text("PNG")
                        },
                        onClick = {
                            selectedFormat = QRSaveFormat.PNG
                            formatMenuExpanded = false
                        }
                    )

                    DropdownMenuItem(
                        text = {
                            Text("JPG")
                        },
                        onClick = {
                            selectedFormat = QRSaveFormat.JPG
                            formatMenuExpanded = false
                        }
                    )

                    DropdownMenuItem(
                        text = {
                            Text("SVG")
                        },
                        onClick = {
                            selectedFormat = QRSaveFormat.SVG
                            formatMenuExpanded = false
                        }
                    )
                }
            }

            Button(
                onClick = onShare,
                modifier = Modifier
                    .weight(1f)
                    .height(40.dp)
            ) {
                Text("Compartir")
            }
        }

        Spacer(
            modifier = Modifier.height(12.dp)
        )

        OutlinedButton(
            onClick = onEdit,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Editar QR")
        }

        Spacer(
            modifier = Modifier.height(20.dp)
        )

        BannerAd()

        Spacer(
            modifier = Modifier.height(12.dp)
        )
    }
}

@Composable
private fun BannerAd() {
    val context = LocalContext.current

    val adView = remember {
        AdView(context).apply {
            adUnitId = QRAds.RESULT_BANNER_AD_UNIT_ID

            val density =
                context.resources.displayMetrics.density

            val screenWidthDp =
                context.resources.displayMetrics.widthPixels / density

            // QRResultScreen tiene 24.dp de padding a cada lado.
            val availableWidthDp =
                (screenWidthDp - 48f).toInt()

            setAdSize(
                AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(
                    context,
                    availableWidthDp
                )
            )

            loadAd(
                AdRequest.Builder().build()
            )
        }
    }

    DisposableEffect(adView) {
        onDispose {
            adView.destroy()
        }
    }

    AndroidView(
        factory = {
            adView
        },
        modifier = Modifier.fillMaxWidth()
    )
}

private tailrec fun Context.findActivity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findActivity()
    else -> null
}
