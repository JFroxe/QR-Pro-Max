
package com.alehei.qrpromax.qr

import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import com.google.zxing.BarcodeFormat
import com.google.zxing.BinaryBitmap
import com.google.zxing.DecodeHintType
import com.google.zxing.MultiFormatReader
import com.google.zxing.PlanarYUVLuminanceSource
import com.google.zxing.common.HybridBinarizer
import com.google.zxing.multi.GenericMultipleBarcodeReader
import java.util.concurrent.atomic.AtomicBoolean

class QRScannerAnalyzer(
    private val onResult: (String) -> Unit,
    private val onNoResult: () -> Unit
) : ImageAnalysis.Analyzer {

    private val captureRequested = AtomicBoolean(false)

    // Estas variables solo se modifican desde el analizador de cámara.
    private var captureSessionActive = false
    private var lastResult: String? = null
    private var matchCount = 0
    private var framesChecked = 0

    private val requiredMatches = 2
    private val maxFramesPerCapture = 20

    // Se llama cuando el usuario pulsa el botón.
    fun requestCapture() {
        captureRequested.set(true)
    }

    override fun analyze(image: ImageProxy) {
        try {
            // No analizar nada hasta que el usuario lo solicite.
            if (!captureRequested.get()) return

            if (!captureSessionActive) {
                captureSessionActive = true
                lastResult = null
                matchCount = 0
                framesChecked = 0
            }

            framesChecked++

            val plane = image.planes[0]
            val buffer = plane.buffer
            val rowStride = plane.rowStride
            val pixelStride = plane.pixelStride
            val width = image.width
            val height = image.height
            val data = ByteArray(width * height)

            if (pixelStride == 1) {
                buffer.rewind()
                buffer.get(data, 0, minOf(data.size, buffer.remaining()))
            } else {
                val rowData = ByteArray(rowStride)
                var offset = 0

                for (y in 0 until height) {
                    buffer.position(y * rowStride)

                    val bytesToRead =
                        minOf(rowStride, buffer.remaining())

                    buffer.get(rowData, 0, bytesToRead)

                    var x = 0
                    while (x < width && offset < data.size) {
                        data[offset++] = rowData[x * pixelStride]
                        x++
                    }
                }
            }

            val source = PlanarYUVLuminanceSource(
                data, width, height,
                0, 0, width, height, false
            )

            val bitmap = BinaryBitmap(HybridBinarizer(source))
            val hints = hashMapOf<DecodeHintType, Any>()

            hints[DecodeHintType.TRY_HARDER] = true
            hints[DecodeHintType.POSSIBLE_FORMATS] = listOf(
                BarcodeFormat.QR_CODE,
                BarcodeFormat.EAN_13,
                BarcodeFormat.EAN_8,
                BarcodeFormat.UPC_A,
                BarcodeFormat.UPC_E,
                BarcodeFormat.CODE_128,
                BarcodeFormat.CODE_39,
                BarcodeFormat.CODE_93,
                BarcodeFormat.ITF,
                BarcodeFormat.CODABAR
            )

            val results = try {
                GenericMultipleBarcodeReader(
                    MultiFormatReader()
                ).decodeMultiple(bitmap, hints)
            } catch (_: Exception) {
                null
            }

            if (results == null || results.size != 1 ||
                results[0].text.isNullOrEmpty()
            ) {
                lastResult = null
                matchCount = 0
            } else {
                val text = results[0].text

                if (text == lastResult) {
                    matchCount++
                } else {
                    lastResult = text
                    matchCount = 1
                }

                if (matchCount >= requiredMatches) {
                    captureRequested.set(false)
                    captureSessionActive = false
                    onResult(text)
                    return
                }
            }

            // Tras varios fotogramas, permitir que el usuario reintente.
            if (framesChecked >= maxFramesPerCapture) {
                captureRequested.set(false)
                captureSessionActive = false
                lastResult = null
                matchCount = 0
                onNoResult()
            }
        } catch (_: Exception) {
            // Un fotograma defectuoso no debe cerrar el escáner.
        } finally {
            image.close()
        }
    }
}
