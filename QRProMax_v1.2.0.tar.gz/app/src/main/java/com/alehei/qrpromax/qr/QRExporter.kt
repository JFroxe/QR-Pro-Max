package com.alehei.qrpromax.qr

import android.content.Context
import android.util.Log
import androidx.compose.ui.graphics.toArgb
import com.alehei.qrpromax.model.ErrorCorrection
import com.alehei.qrpromax.model.ModuleStyle
import com.alehei.qrpromax.model.EyeStyle
import com.alehei.qrpromax.model.QRConfig
import com.google.zxing.EncodeHintType
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel
import com.google.zxing.qrcode.encoder.Encoder

fun exportQRCodeToSvg(
    context: Context,
    config: QRConfig,
    size: Int = 800
): String {

    // ---------------------------------------------------------
    // NIVEL DE CORRECCIÓN
    // ---------------------------------------------------------
    val errorCorrection = when (config.errorCorrection) {
        ErrorCorrection.LOW -> ErrorCorrectionLevel.L
        ErrorCorrection.MEDIUM -> ErrorCorrectionLevel.M
        ErrorCorrection.QUARTILE -> ErrorCorrectionLevel.Q
        ErrorCorrection.HIGH -> ErrorCorrectionLevel.H
    }

    val hints = hashMapOf<EncodeHintType, Any>()
    hints[EncodeHintType.ERROR_CORRECTION] = errorCorrection
    hints[EncodeHintType.CHARACTER_SET] = "UTF-8"

    val qrCode = Encoder.encode(config.content, errorCorrection, hints)
    val matrix = qrCode.matrix
    val moduleCount = matrix.width

    val foreground = colorToSvg(config.foregroundColor.toArgb())
    val background = colorToSvg(config.backgroundColor.toArgb())

    // ---------------------------------------------------------
    // MARGEN / QUIET ZONE
    // ---------------------------------------------------------
    val quietZoneModules = 2 
    val totalModules = moduleCount + (quietZoneModules * 2)
    val pieceSize = size.toFloat() / totalModules
    val offset = quietZoneModules * pieceSize

    // ---------------------------------------------------------
    // PREPARACIÓN DEL LOGO
    // ---------------------------------------------------------
    val isLogoActive = config.logoEnabled && !config.logoAssetName.isNullOrBlank()
    var rawLogo = ""
    
    if (isLogoActive) {
        val assetName = config.logoAssetName!!
        // Asegurar la extensión .svg
        val fullPath = if (assetName.endsWith(".svg", ignoreCase = true)) {
            "logos/$assetName"
        } else {
            "logos/$assetName.svg"
        }
        
        rawLogo = loadSvgFromAssets(context, fullPath)
        
        // Fallback: Si no lo encuentra con .svg, intentar tal cual se proporcionó
        if (rawLogo.isBlank()) {
            rawLogo = loadSvgFromAssets(context, "logos/$assetName")
        }
    }

    val hasValidLogo = rawLogo.isNotBlank()

    // ---------------------------------------------------------
    // CÁLCULO DE ÁREA RESERVADA PARA EL LOGO
    // ---------------------------------------------------------
    val logoModulesCount = if (hasValidLogo) (moduleCount * config.logoSize).toInt() else 0
    val logoStartModule = (moduleCount - logoModulesCount) / 2
    val logoEndModule = logoStartModule + logoModulesCount

    val svg = StringBuilder()
    svg.append("""
        <svg xmlns="http://www.w3.org/2000/svg"
             xmlns:xlink="http://www.w3.org/1999/xlink"
             width="$size" height="$size"
             viewBox="0 0 $size $size">
    """.trimIndent())

    // ---------------------------------------------------------
    // DEFINICIONES DE MÓDULO Y OJO
    // ---------------------------------------------------------
    svg.append("\n<defs>\n")
    
    val moduleDef = defineSvgSymbol(
        context,
        "modules/module_${config.moduleStyle.fileName}.svg",
        "module-${config.moduleStyle.name}",
        cleanFill = true
    ) 
    svg.append(moduleDef)

    val eyeDef = defineSvgSymbol(
        context,
        "eyes/eye_${config.eyeStyle.fileName}.svg",
        "eye-${config.eyeStyle.name}",
        cleanFill = true
    )
    svg.append(eyeDef)
    
    svg.append("\n</defs>\n")

    // ---------------------------------------------------------
    // FONDO
    // ---------------------------------------------------------
    svg.append("""
        <rect width="100%" height="100%" fill="$background"/>
    """.trimIndent())

    // ---------------------------------------------------------
    // MÓDULOS
    // ---------------------------------------------------------
    for (y in 0 until moduleCount) {
        for (x in 0 until moduleCount) {
            if (matrix.get(x, y).toInt() == 0) continue
            if (isFinderPatternSvg(x, y, moduleCount)) continue
            
            // Omitir módulos en el área del logo
            if (hasValidLogo && x in logoStartModule until logoEndModule && y in logoStartModule until logoEndModule) {
                continue
            }

            val left = offset + x * pieceSize
            val top = offset + y * pieceSize

            svg.append("""
                <use xlink:href="#module-${config.moduleStyle.name}" href="#module-${config.moduleStyle.name}"
                     x="$left" y="$top"
                     width="$pieceSize" height="$pieceSize"
                     fill="$foreground"/>
            """.trimIndent())
        }
    }

    // ---------------------------------------------------------
    // OJOS
    // ---------------------------------------------------------
    drawEyeSvg(svg, offset, offset, 0, 0, pieceSize, config.eyeStyle, foreground, background)
    drawEyeSvg(svg, offset, offset, moduleCount - 7, 0, pieceSize, config.eyeStyle, foreground, background)
    drawEyeSvg(svg, offset, offset, 0, moduleCount - 7, pieceSize, config.eyeStyle, foreground, background)

    // ---------------------------------------------------------
    // LOGO
    // ---------------------------------------------------------
    if (hasValidLogo) {
        val logoSizePx = moduleCount * pieceSize * config.logoSize
        val logoLeft = (size - logoSizePx) / 2f
        val logoTop = (size - logoSizePx) / 2f

        svg.append("\n<!-- LOGO INICIO -->\n")

        val logoEmbedded = embedLogoSvg(rawLogo, logoLeft, logoTop, logoSizePx)
        svg.append(logoEmbedded)
        svg.append("\n<!-- LOGO FIN -->\n")
    }
    
    svg.append("\n</svg>")
    return svg.toString()
}

// ---------------------------------------------------------
// HELPERS
// ---------------------------------------------------------
private fun loadSvgFromAssets(context: Context, path: String): String =
    try {
        context.assets.open(path).bufferedReader().use { it.readText() }
    } catch (e: Exception) {
        Log.e("ExportQRCodeToSvg", "Error cargando asset desde ruta: $path", e)
        ""
    }

private fun defineSvgSymbol(
    context: Context,
    path: String,
    id: String,
    cleanFill: Boolean = false,
    defaultViewBox: String = "0 0 210 210"
): String {
    val source = loadSvgFromAssets(context, path)
    if (source.isBlank()) return ""

    val viewBoxRegex = Regex("""viewBox=["']([^"']+)["']""", RegexOption.IGNORE_CASE)
    val viewBox = viewBoxRegex.find(source)?.groupValues?.getOrNull(1)?.trim() ?: defaultViewBox

    var content = extractSvgContent(source)

    if (cleanFill) {
        content = content.replace(Regex("""\sfill=["']([^"']+)["']""", RegexOption.IGNORE_CASE), "")
                         .replace(Regex("""\sstyle=["'][^"']*fill:[^"']*["']""", RegexOption.IGNORE_CASE), "")
    }

    return """
        <symbol id="$id" viewBox="$viewBox">
            $content
        </symbol>
    """.trimIndent()
}

private fun embedLogoSvg(
    rawLogo: String,
    left: Float,
    top: Float,
    logoSizePx: Float
): String {

    val viewBoxRegex = Regex(
        """viewBox=["']([^"']+)["']""",
        RegexOption.IGNORE_CASE
    )

    val viewBox = viewBoxRegex
        .find(rawLogo)
        ?.groupValues
        ?.getOrNull(1)
        ?.trim()
        ?: "0 0 315 315"

    val parts = viewBox
        .split(Regex("""\s+|,"""))
        .mapNotNull { it.toFloatOrNull() }

    val viewBoxWidth =
        if (parts.size >= 4) parts[2] else 315f

    val viewBoxHeight =
        if (parts.size >= 4) parts[3] else 315f

    val viewBoxMinX =
        if (parts.size >= 4) parts[0] else 0f

    val viewBoxMinY =
        if (parts.size >= 4) parts[1] else 0f

    val scaleX = logoSizePx / viewBoxWidth
    val scaleY = logoSizePx / viewBoxHeight

    val content = extractSvgContent(rawLogo)

    return """
        <g transform="translate($left $top) scale($scaleX $scaleY) translate(${-viewBoxMinX} ${-viewBoxMinY})">
            $content
        </g>
    """.trimIndent()
}

private fun extractSvgContent(rawSvg: String): String {
    val startTagIndex = rawSvg.indexOf("<svg", ignoreCase = true)
    if (startTagIndex == -1) return rawSvg

    val startCloseIndex = rawSvg.indexOf('>', startTagIndex)
    if (startCloseIndex == -1) return rawSvg

    val endTagIndex = rawSvg.lastIndexOf("</svg>", ignoreCase = true)
    if (endTagIndex == -1 || endTagIndex <= startCloseIndex) return rawSvg

    return rawSvg.substring(startCloseIndex + 1, endTagIndex).trim()
}

private fun drawEyeSvg(
    svg: StringBuilder,
    offsetX: Float,
    offsetY: Float,
    startX: Int,
    startY: Int,
    pieceSize: Float,
    style: EyeStyle,
    foreground: String,
    background: String
) {
    val left = offsetX + startX * pieceSize
    val top = offsetY + startY * pieceSize

    // Exterior 7x7
    svg.append("""
        <use xlink:href="#eye-${style.name}" href="#eye-${style.name}"
             x="$left" y="$top"
             width="${pieceSize * 7f}" height="${pieceSize * 7f}"
             fill="$foreground"/>
    """.trimIndent())

    // Interior 5x5
    svg.append("""
        <use xlink:href="#eye-${style.name}" href="#eye-${style.name}"
             x="${left + pieceSize}" y="${top + pieceSize}"
             width="${pieceSize * 5f}" height="${pieceSize * 5f}"
             fill="$background"/>
    """.trimIndent())

    // Centro 3x3
    svg.append("""
        <use xlink:href="#eye-${style.name}" href="#eye-${style.name}"
             x="${left + pieceSize * 2}" y="${top + pieceSize * 2}"
             width="${pieceSize * 3f}" height="${pieceSize * 3f}"
             fill="$foreground"/>
    """.trimIndent())
}

private fun isFinderPatternSvg(x: Int, y: Int, moduleCount: Int): Boolean =
    (x < 7 && y < 7) || (x >= moduleCount - 7 && y < 7) || (x < 7 && y >= moduleCount - 7)

private fun colorToSvg(color: Int): String {
    val red = (color shr 16) and 0xFF
    val green = (color shr 8) and 0xFF
    val blue = color and 0xFF
    return String.format("#%02X%02X%02X", red, green, blue)
}
