package com.alehei.qrpromax.ui.theme

import androidx.compose.ui.graphics.Color

val BrandDeep = Color(0xFF12313B)
val BrandTeal = Color(0xFF0F766E)
val BrandMint = Color(0xFF38BFA0)
val BrandSky = Color(0xFF2F80ED)
val Ink = Color(0xFF17323A)
val Mist = Color(0xFFF3F7F7)
val Night = Color(0xFF0D1D22)
val NightSurface = Color(0xFF162A30)