package com.alehei.qrpromax.qr

import android.view.LayoutInflater
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.viewinterop.AndroidView
import com.alehei.qrpromax.R
import com.google.android.gms.ads.AdLoader
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.nativead.NativeAd
import com.google.android.gms.ads.nativead.NativeAdView

@Composable
fun QRNativeAd(
    adUnitId: String,
    modifier: Modifier = Modifier
) {

    AndroidView(
        modifier = modifier,
        factory = { context ->

            val adView = LayoutInflater.from(context)
                .inflate(
                    R.layout.native_ad_qr_promax,
                    null
                ) as NativeAdView

            val adLoader = AdLoader.Builder(
                context,
                adUnitId
            )
                .forNativeAd { nativeAd ->

                    populateNativeAdView(
                        nativeAd,
                        adView
                    )
                }
                .build()

            adLoader.loadAd(
                AdRequest.Builder().build()
            )

            adView
        }
    )
}

private fun populateNativeAdView(
    nativeAd: NativeAd,
    adView: NativeAdView
) {

    val headlineView =
        adView.findViewById<TextView>(
            R.id.native_ad_headline
        )

    val bodyView =
        adView.findViewById<TextView>(
            R.id.native_ad_body
        )

    val iconView =
        adView.findViewById<ImageView>(
            R.id.native_ad_icon
        )

    val callToActionView =
        adView.findViewById<Button>(
            R.id.native_ad_call_to_action
        )

    headlineView.text =
        nativeAd.headline

    adView.headlineView =
        headlineView

    if (nativeAd.body != null) {

        bodyView.text =
            nativeAd.body

        bodyView.visibility =
            View.VISIBLE

        adView.bodyView =
            bodyView

    } else {

        bodyView.visibility =
            View.GONE
    }

    if (nativeAd.icon != null) {

        iconView.setImageDrawable(
            nativeAd.icon?.drawable
        )

        iconView.visibility =
            View.VISIBLE

        adView.iconView =
            iconView

    } else {

        iconView.visibility =
            View.GONE
    }

    if (nativeAd.callToAction != null) {

        callToActionView.text =
            nativeAd.callToAction

        callToActionView.visibility =
            View.VISIBLE

        adView.callToActionView =
            callToActionView

    } else {

        callToActionView.visibility =
            View.GONE
    }

    adView.setNativeAd(
        nativeAd
    )
}