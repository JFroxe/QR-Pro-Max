package com.alehei.qrpromax.ui.screens

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.ImageDecoder
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.Camera
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.core.CameraSelector
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.alehei.qrpromax.R
import com.alehei.qrpromax.model.ScannerStyle
import com.alehei.qrpromax.qr.QRScannerAnalyzer
import com.alehei.qrpromax.qr.decodeQRFromBitmap
import java.util.concurrent.Executors


private const val FRAME_SIZE_PX = 1450f
private const val QR_AREA_SIZE_PX = 1050f
private const val QR_OFFSET_PX = 200f


@Composable
fun QRScannerScreen(
    scannerStyle: ScannerStyle,
    onScannerStyleChange: (ScannerStyle) -> Unit,
    onBack: () -> Unit,
    onResult: (String) -> Unit
) {

    var camera by remember {
        mutableStateOf<Camera?>(null)
    }

    var scannerAnalyzer by remember {
        mutableStateOf<QRScannerAnalyzer?>(null)
    }
    
    var torchEnabled by remember {
        mutableStateOf(false)
    }

    var selectedScannerStyle by remember {
        mutableStateOf(scannerStyle)
    }

    var showScannerStyles by remember {
        mutableStateOf(false)
    }


    /*
     * Bitmap seleccionado de la galería
     */
    var selectedImageBitmap by remember {
        mutableStateOf<Bitmap?>(null)
    }


    val analysisExecutor = remember {
        Executors.newSingleThreadExecutor()
    }


    DisposableEffect(Unit) {

        onDispose {
            analysisExecutor.shutdown()
        }
    }


    val context = LocalContext.current

    val lifecycleOwner =
        LocalLifecycleOwner.current


    /*
     * GALERÍA
     */
    val galleryLauncher =
        rememberLauncherForActivityResult(
            contract = ActivityResultContracts.GetContent()
        ) { uri: Uri? ->
    
            if (uri == null) {
                return@rememberLauncherForActivityResult
            }
    
            val bitmap =
                decodeBitmapFromUri(
                    context = context,
                    uri = uri
                )
    
            if (bitmap == null) {
    
                Toast.makeText(
                    context,
                    "No pudimos abrir la imagen",
                    Toast.LENGTH_SHORT
                ).show()
    
            } else {
    
                selectedImageBitmap = bitmap
            }
        }


    /*
     * PERMISO DE CÁMARA
     */
    var hasCameraPermission by remember {

        mutableStateOf(
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.CAMERA
            ) ==
                PackageManager.PERMISSION_GRANTED
        )
    }


    var permissionRequestCount by remember {

        mutableStateOf(
            getPermissionRequestCount(
                context
            )
        )
    }


    val cameraPermissionLauncher =
        rememberLauncherForActivityResult(
            ActivityResultContracts.RequestPermission()
        ) { granted ->

            if (granted) {

                hasCameraPermission = true

            } else {

                hasCameraPermission = false

                incrementPermissionRequestCount(
                    context
                )

                permissionRequestCount =
                    getPermissionRequestCount(
                        context
                    )
            }
        }


    LaunchedEffect(Unit) {

        if (!hasCameraPermission) {

            cameraPermissionLauncher.launch(
                Manifest.permission.CAMERA
            )
        }
    }


    /*
     * ANIMACIÓN DEL ESCÁNER
     */
    val infiniteTransition =
        rememberInfiniteTransition(
            label = "scanner"
        )


    val linePosition by
        infiniteTransition.animateFloat(
            initialValue = 0f,
            targetValue = 1f,
            animationSpec =
                infiniteRepeatable(
                    animation =
                        tween(
                            durationMillis = 1800,
                            easing = LinearEasing
                        ),
                    repeatMode =
                        RepeatMode.Reverse
                ),
            label = "scannerLine"
        )


    /*
     * SI TENEMOS UNA IMAGEN SELECCIONADA,
     * MOSTRAMOS EL RECORTADOR
     */
    if (selectedImageBitmap != null) {

        QRImageCropScreen(

            bitmap =
                selectedImageBitmap!!,

            onDismiss = {

                selectedImageBitmap = null
            },

            onCropAndRead = { croppedBitmap ->

                val resultQR =
                    decodeQRFromBitmap(
                        croppedBitmap
                    )


                if (resultQR != null) {

                    selectedImageBitmap = null

                    onResult(
                        resultQR
                    )

                    true

                } else {

                    Toast.makeText(
                        context,
                        "No se reconoce ningún QR en el recorte",
                        Toast.LENGTH_SHORT
                    ).show()

                    false
                }
            }
        )

        return
    }
    
    /*
     * PANTALLA PRINCIPAL DEL ESCÁNER
     */
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black),
        contentAlignment =
            Alignment.Center
    ) {

        if (hasCameraPermission) {

            AndroidView(

                factory = { ctx ->

                    val previewView =
                        PreviewView(ctx)


                    val cameraProviderFuture =
                        ProcessCameraProvider
                            .getInstance(ctx)


                    cameraProviderFuture.addListener({

                        val cameraProvider =
                            cameraProviderFuture.get()


                        val preview =
                            Preview.Builder()
                                .build()
                                .also {

                                    it.surfaceProvider =
                                        previewView
                                            .surfaceProvider
                                }


                        val imageAnalysis =
                            ImageAnalysis.Builder()
                                .setBackpressureStrategy(
                                    ImageAnalysis
                                        .STRATEGY_KEEP_ONLY_LATEST
                                )
                                .build()


                        val analyzer = QRScannerAnalyzer(
                            onResult = { result ->
                                ContextCompat.getMainExecutor(ctx).execute {
                                    onResult(result)
                                }
                            },
                            onNoResult = {
                                ContextCompat.getMainExecutor(ctx).execute {
                                    Toast.makeText(
                                        ctx,
                                        "No se detectó ningún código. Centra el código e inténtalo de nuevo.",
                                        Toast.LENGTH_SHORT
                                    ).show()
                                }
                            }
                        )
                        
                        scannerAnalyzer = analyzer
                        
                        imageAnalysis.setAnalyzer(
                            analysisExecutor,
                            analyzer
                        )


                        try {

                            cameraProvider.unbindAll()


                            camera =
                                cameraProvider
                                    .bindToLifecycle(

                                        lifecycleOwner,

                                        CameraSelector
                                            .DEFAULT_BACK_CAMERA,

                                        imageAnalysis,

                                        preview
                                    )

                        } catch (_: Exception) {
                        }

                    }, ContextCompat.getMainExecutor(ctx))


                    previewView
                },

                modifier =
                    Modifier.fillMaxSize()
            )


            /*
             * MARCO DEL ESCÁNER
             */
            val frameSize =
                280.dp

            val qrAreaSize =
                frameSize *
                    (QR_AREA_SIZE_PX /
                            FRAME_SIZE_PX)

            val qrOffset =
                frameSize *
                    (QR_OFFSET_PX /
                            FRAME_SIZE_PX)

            val lineHeight =
                qrAreaSize *
                    (42f / 966f)

            val lineTravel =
                qrAreaSize -
                    lineHeight


            Box(
                modifier =
                    Modifier.size(
                        frameSize
                    )
            ) {

                Image(

                    painter =
                        painterResource(
                            getScannerDrawable(
                                selectedScannerStyle
                            )
                        ),

                    contentDescription = null,

                    modifier =
                        Modifier.fillMaxSize(),

                    colorFilter =
                        ColorFilter.tint(
                            Color.White
                        )
                )


                Image(

                    painter =
                        painterResource(
                            R.drawable.scan_line
                        ),

                    contentDescription = null,

                    modifier =
                        Modifier
                            .size(
                                width =
                                    qrAreaSize,
                                height =
                                    qrAreaSize *
                                        (42f / 966f)
                            )
                            .offset(

                                x =
                                    qrOffset,

                                y =
                                    qrOffset +
                                        lineTravel *
                                            linePosition
                            ),

                    colorFilter =
                        ColorFilter.tint(
                            MaterialTheme
                                .colorScheme
                                .primary
                        )
                )
            }

        } else {

            /*
             * PERMISO DENEGADO
             */
            Column(

                modifier =
                    Modifier
                        .fillMaxSize()
                        .padding(24.dp),

                verticalArrangement =
                    Arrangement.Center,

                horizontalAlignment =
                    Alignment.CenterHorizontally
            ) {

                Text(

                    text =
                        "Para escanear mediante la cámara necesitas habilitar sus permisos. Permite que QR Pro Max pueda acceder a tu cámara.",

                    style =
                        MaterialTheme
                            .typography
                            .bodyLarge,

                    color =
                        Color.White,

                    textAlign =
                        TextAlign.Center
                )


                Spacer(
                    modifier =
                        Modifier.height(16.dp)
                )


                if (permissionRequestCount < 3) {

                    Button(

                        onClick = {

                            cameraPermissionLauncher
                                .launch(
                                    Manifest.permission.CAMERA
                                )
                        }

                    ) {

                        Text(
                            "Conceder permiso"
                        )
                    }

                } else {

                    OutlinedButton(

                        onClick = {

                            val intent =
                                android.content.Intent(

                                    Settings
                                        .ACTION_APPLICATION_DETAILS_SETTINGS,

                                    Uri.fromParts(
                                        "package",
                                        context.packageName,
                                        null
                                    )
                                )

                            intent.addFlags(
                                android.content.Intent
                                    .FLAG_ACTIVITY_NEW_TASK
                            )

                            context.startActivity(
                                intent
                            )
                        }

                    ) {

                        Text(
                            "Abrir ajustes"
                        )
                    }
                }
            }
        }

        Button(
            onClick = {
                scannerAnalyzer?.requestCapture()
            },
            enabled = scannerAnalyzer != null,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 112.dp)
        ) {
            Text("Capturar QR")
        }        

        /*
         * BOTONES INFERIORES
         */
        Row(

            modifier =
                Modifier
                    .align(
                        Alignment.BottomCenter
                    )
                    .padding(
                        start = 20.dp,
                        end = 20.dp,
                        bottom = 28.dp
                    ),

            horizontalArrangement =
                Arrangement.spacedBy(12.dp)
        ) {

            /*
             * FOTO
             */
            ScannerButton(

                iconResId =
                    R.drawable.icon_scan_image,

                label =
                    "Foto",

                onClick = {

                    galleryLauncher.launch(
                        "image/*"
                    )
                }
            )


            /*
             * LUZ
             */
            ScannerButton(

                iconResId =
                    R.drawable.icon_flashlight,

                label =
                    "Luz",

                iconColor =
                    if (torchEnabled) {

                        MaterialTheme
                            .colorScheme
                            .primary

                    } else {

                        Color.White
                    },

                onClick = {

                    val currentCamera =
                        camera
                            ?: return@ScannerButton


                    if (
                        currentCamera
                            .cameraInfo
                            .hasFlashUnit()
                    ) {

                        torchEnabled =
                            !torchEnabled


                        currentCamera
                            .cameraControl
                            .enableTorch(
                                torchEnabled
                            )
                    }
                }
            )


            /*
             * MARCO
             */
            ScannerButton(

                iconResId =
                    R.drawable.icon_frame,

                label =
                    "Marco",

                onClick = {

                    if (showScannerStyles) {

                        onScannerStyleChange(
                            selectedScannerStyle
                        )
                    }


                    showScannerStyles =
                        !showScannerStyles
                }
            )


            /*
             * VOLVER
             */
            ScannerButton(

                iconResId =
                    R.drawable.icon_back,

                label =
                    "Volver",

                onClick =
                    onBack
            )
        }


        /*
         * ESTILOS DEL ESCÁNER
         */
        if (showScannerStyles) {

            LazyRow(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {

                item {

                    ScannerStyleOption(
                        selected =
                            selectedScannerStyle ==
                                ScannerStyle.CLASSIC,

                        drawableId =
                            R.drawable.scanner_classic,

                        onClick = {

                            selectedScannerStyle =
                                ScannerStyle.CLASSIC
                        }
                    )
                }


                item {

                    ScannerStyleOption(
                        selected =
                            selectedScannerStyle ==
                                ScannerStyle.ROUNDED,

                        drawableId =
                            R.drawable.scanner_rounded,

                        onClick = {

                            selectedScannerStyle =
                                ScannerStyle.ROUNDED
                        }
                    )
                }


                item {

                    ScannerStyleOption(
                        selected =
                            selectedScannerStyle ==
                                ScannerStyle.FLOWER,

                        drawableId =
                            R.drawable.scanner_flower,

                        onClick = {

                            selectedScannerStyle =
                                ScannerStyle.FLOWER
                        }
                    )
                }


                item {

                    ScannerStyleOption(
                        selected =
                            selectedScannerStyle ==
                                ScannerStyle.LINES,

                        drawableId =
                            R.drawable.scanner_lines,

                        onClick = {

                            selectedScannerStyle =
                                ScannerStyle.LINES
                        }
                    )
                }


                item {

                    ScannerStyleOption(
                        selected =
                            selectedScannerStyle ==
                                ScannerStyle.LITE,

                        drawableId =
                            R.drawable.scanner_lite,

                        onClick = {

                            selectedScannerStyle =
                                ScannerStyle.LITE
                        }
                    )
                }


                item {

                    ScannerStyleOption(
                        selected =
                            selectedScannerStyle ==
                                ScannerStyle.HANDS,

                        drawableId =
                            R.drawable.scanner_hands,

                        onClick = {

                            selectedScannerStyle =
                                ScannerStyle.HANDS
                        }
                    )
                }


                item {

                    ScannerStyleOption(
                        selected =
                            selectedScannerStyle ==
                                ScannerStyle.STARS,

                        drawableId =
                            R.drawable.scanner_stars,

                        onClick = {

                            selectedScannerStyle =
                                ScannerStyle.STARS
                        }
                    )
                }


                item {

                    ScannerStyleOption(
                        selected =
                            selectedScannerStyle ==
                                ScannerStyle.MINECRAFT,

                        drawableId =
                            R.drawable.scanner_minecraft,

                        onClick = {

                            selectedScannerStyle =
                                ScannerStyle.MINECRAFT
                        }
                    )
                }


                item {

                    ScannerStyleOption(
                        selected =
                            selectedScannerStyle ==
                                ScannerStyle.SCAN_HERE,

                        drawableId =
                            R.drawable.scanner_scan_here,

                        onClick = {

                            selectedScannerStyle =
                                ScannerStyle.SCAN_HERE
                        }
                    )
                }


                item {

                    ScannerStyleOption(
                        selected =
                            selectedScannerStyle ==
                                ScannerStyle.VECTORS,

                        drawableId =
                            R.drawable.scanner_vectors,

                        onClick = {

                            selectedScannerStyle =
                                ScannerStyle.VECTORS
                        }
                    )
                }
            }
        }
    }
}


/*
 * DECODIFICAR BITMAP DE LA GALERÍA
 */
private fun decodeBitmapFromUri(
    context: Context,
    uri: Uri
): Bitmap? {

    return try {

        if (
            Build.VERSION.SDK_INT >=
            Build.VERSION_CODES.P
        ) {

            ImageDecoder.decodeBitmap(

                ImageDecoder.createSource(
                    context.contentResolver,
                    uri
                )
            )

        } else {

            @Suppress("DEPRECATION")

            android.provider.MediaStore
                .Images
                .Media
                .getBitmap(
                    context.contentResolver,
                    uri
                )
        }

    } catch (_: Exception) {

        null
    }
}


/*
 * PERMISOS
 */
fun getPermissionRequestCount(
    context: Context
): Int {

    val prefs =
        context.getSharedPreferences(
            "qrscanner_prefs",
            Context.MODE_PRIVATE
        )

    return prefs.getInt(
        "camera_permission_count",
        0
    )
}


fun incrementPermissionRequestCount(
    context: Context
) {

    val prefs =
        context.getSharedPreferences(
            "qrscanner_prefs",
            Context.MODE_PRIVATE
        )

    val current =
        prefs.getInt(
            "camera_permission_count",
            0
        )


    prefs.edit()
        .putInt(
            "camera_permission_count",
            current + 1
        )
        .apply()
}


/*
 * ESTILOS DEL ESCÁNER
 */
private fun getScannerDrawable(
    style: ScannerStyle
): Int {

    return when (style) {

        ScannerStyle.CLASSIC ->
            R.drawable.scanner_classic

        ScannerStyle.ROUNDED ->
            R.drawable.scanner_rounded

        ScannerStyle.FLOWER ->
            R.drawable.scanner_flower

        ScannerStyle.LINES ->
            R.drawable.scanner_lines

        ScannerStyle.LITE ->
            R.drawable.scanner_lite

        ScannerStyle.HANDS ->
            R.drawable.scanner_hands

        ScannerStyle.STARS ->
            R.drawable.scanner_stars

        ScannerStyle.MINECRAFT ->
            R.drawable.scanner_minecraft

        ScannerStyle.SCAN_HERE ->
            R.drawable.scanner_scan_here

        ScannerStyle.VECTORS ->
            R.drawable.scanner_vectors
    }
}


/*
 * BOTÓN DEL ESCÁNER
 */
@Composable
private fun ScannerButton(
    iconResId: Int,
    label: String,
    onClick: () -> Unit,
    iconColor: Color = Color.White
) {

    Box(

        modifier =
            Modifier
                .size(72.dp)
                .clip(
                    RoundedCornerShape(16.dp)
                )
                .background(
                    Color.Black.copy(
                        alpha = 0.65f
                    )
                )
                .clickable {
                    onClick()
                },

        contentAlignment =
            Alignment.Center
    ) {

        Column(

            horizontalAlignment =
                Alignment.CenterHorizontally,

            verticalArrangement =
                Arrangement.Center
        ) {

            Image(

                painter =
                    painterResource(
                        iconResId
                    ),

                contentDescription =
                    label,

                modifier =
                    Modifier.size(28.dp),

                colorFilter =
                    ColorFilter.tint(
                        iconColor
                    )
            )


            Text(

                text =
                    label,

                style =
                    MaterialTheme
                        .typography
                        .labelSmall,

                color =
                    Color.White
            )
        }
    }
}


/*
 * OPCIÓN DE ESTILO
 */
@Composable
private fun ScannerStyleOption(
    selected: Boolean,
    drawableId: Int,
    onClick: () -> Unit
) {

    Box(

        modifier =
            Modifier
                .size(58.dp)
                .clip(
                    RoundedCornerShape(12.dp)
                )
                .background(

                    if (selected)

                        MaterialTheme
                            .colorScheme
                            .primary

                    else

                        Color.Black.copy(
                            alpha = 0.65f
                        )
                )
                .clickable {
                    onClick()
                }
                .padding(8.dp),

        contentAlignment =
            Alignment.Center
    ) {

        Image(

            painter =
                painterResource(
                    drawableId
                ),

            contentDescription =
                null,

            modifier =
                Modifier.fillMaxSize(),

            colorFilter =
                ColorFilter.tint(
                    Color.White
                )
        )
    }
}