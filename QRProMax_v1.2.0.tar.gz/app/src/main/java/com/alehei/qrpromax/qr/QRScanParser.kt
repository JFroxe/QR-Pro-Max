package com.alehei.qrpromax.qr

enum class QRScanType {
    URL,
    TEXT,
    WIFI,
    CONTACT,
    EMAIL,
    PHONE,
    SMS,
    LOCATION
}

data class QRScanData(
    val type: QRScanType,
    val rawContent: String,
    val title: String = "",
    val subtitle: String = "",
    val value1: String = "",
    val value2: String = "",
    val value3: String = "",
    val value4: String = "",
    val value5: String = ""
)

fun parseQRContent(content: String): QRScanData {

    val trimmed = content.trim()

    // URL
    if (isUrlContent(trimmed)) {
        return QRScanData(
            type = QRScanType.URL,
            rawContent = content,
            title = "URL",
            value1 = normalizeUrl(trimmed)
        )
    }

    // Wi-Fi
    if (trimmed.startsWith("WIFI:", ignoreCase = true)) {
    
        val wifiData = trimmed.substringAfter("WIFI:")
    
        val ssid = extractWifiValue(wifiData, "S")
        val password = extractWifiValue(wifiData, "P")
        val security = extractWifiValue(wifiData, "T")
    
        return QRScanData(
            type = QRScanType.WIFI,
            rawContent = content,
            title = "Wi-Fi",
            value1 = ssid,
            value2 = password,
            value3 = security
        )
    }

    if (trimmed.startsWith("MECARD:", ignoreCase = true)) {
    
        val mecardData = trimmed.substringAfter("MECARD:")
    
        val name = extractMecardValue(mecardData, "N")
        val company = extractMecardValue(mecardData, "ORG")
        val phone = extractMecardValue(mecardData, "TEL")
        val email = extractMecardValue(mecardData, "EMAIL")
        val address = extractMecardValue(mecardData, "ADR")
        val website = extractMecardValue(mecardData, "URL")
    
        return QRScanData(
            type = QRScanType.CONTACT,
            rawContent = content,
            title = "Contacto",
            subtitle = name,
            value1 = phone,
            value2 = email,
            value3 = company,
            value4 = address,
            value5 = website
        )
    }
    
    // Contacto / vCard
    if (trimmed.contains("BEGIN:VCARD", ignoreCase = true)) {
    
        val name = extractVCardValue(trimmed, "FN")
            .ifEmpty {
                extractVCardValue(trimmed, "N")
            }
    
        val phone = extractVCardValue(trimmed, "TEL")
        val email = extractVCardValue(trimmed, "EMAIL")
        val company = extractVCardValue(trimmed, "ORG")
        val address = extractVCardValue(trimmed, "ADR")
        val website = extractVCardValue(trimmed, "URL")
    
        return QRScanData(
            type = QRScanType.CONTACT,
            rawContent = content,
            title = "Contacto",
            subtitle = name,
            value1 = phone,
            value2 = email,
            value3 = company,
            value4 = address,
            value5 = website
        )
    }

    // Email
    if (
        trimmed.startsWith("mailto:", ignoreCase = true)
    ) {
        val email = trimmed.substringAfter(":", "")

        return QRScanData(
            type = QRScanType.EMAIL,
            rawContent = content,
            title = "Email",
            value1 = email
        )
    }

    // Teléfono
    if (
        trimmed.startsWith("tel:", ignoreCase = true)
    ) {
        val phone = trimmed.substringAfter(":", "")

        return QRScanData(
            type = QRScanType.PHONE,
            rawContent = content,
            title = "Teléfono",
            value1 = phone
        )
    }

    // SMS
    if (
        trimmed.startsWith("SMSTO:", ignoreCase = true)
    ) {
        val data = trimmed.substringAfter(":", "")
        val parts = data.split(":", limit = 2)

        val number = parts.getOrNull(0) ?: ""
        val message = parts.getOrNull(1) ?: ""

        return QRScanData(
            type = QRScanType.SMS,
            rawContent = content,
            title = "SMS",
            value1 = number,
            value2 = message
        )
    }

    // Ubicación
    if (
        trimmed.startsWith("geo:", ignoreCase = true)
    ) {
        val coordinates = trimmed.substringAfter(":", "")
        val parts = coordinates.split(",", limit = 2)

        val latitude = parts.getOrNull(0) ?: ""
        val longitude = parts.getOrNull(1) ?: ""

        return QRScanData(
            type = QRScanType.LOCATION,
            rawContent = content,
            title = "Ubicación",
            value1 = latitude,
            value2 = longitude
        )
    }

    // Texto normal
    return QRScanData(
        type = QRScanType.TEXT,
        rawContent = content,
        title = "Texto",
        value1 = content
    )
}

private fun extractWifiValue(
    content: String,
    key: String
): String {

    val regex = Regex(
        "(?:^|;)${key}:((?:\\\\.|[^;])*)"
    )

    val match = regex.find(content)

    return match
        ?.groupValues
        ?.getOrNull(1)
        ?.replace("\\;", ";")
        ?.replace("\\\\", "\\")
        ?: ""
}

private fun extractMecardValue(
    content: String,
    key: String
): String {

    val regex = Regex(
        "(?:^|;)${key}:((?:\\\\.|[^;])*)"
    )

    val match = regex.find(content)

    return match
        ?.groupValues
        ?.getOrNull(1)
        ?.replace("\\;", ";")
        ?.replace("\\\\", "\\")
        ?: ""
}

private fun extractVCardValue(
    content: String,
    key: String
): String {

    val regex = Regex(
        "(?im)^${key}(?:;[^:]*)?:([^\\r\\n]*)"
    )

    return regex
        .find(content)
        ?.groupValues
        ?.getOrNull(1)
        ?.trim()
        ?: ""
}

private fun isUrlContent(content: String): Boolean {

    if (
        content.startsWith("http://", ignoreCase = true) ||
        content.startsWith("https://", ignoreCase = true)
    ) {
        return true
    }

    if (content.startsWith("www.", ignoreCase = true)) {
        return true
    }

    val urlRegex = Regex(
        "^(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,}(?::\\d+)?(?:[/?#].*)?$"
    )

    return urlRegex.matches(content)
}

private fun normalizeUrl(content: String): String {

    return if (
        content.startsWith("http://", ignoreCase = true) ||
        content.startsWith("https://", ignoreCase = true)
    ) {
        content
    } else {
        "https://$content"
    }
}