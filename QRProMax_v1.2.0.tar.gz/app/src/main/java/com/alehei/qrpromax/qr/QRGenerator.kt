package com.alehei.qrpromax.qr

import android.content.Context
import android.graphics.Bitmap
import com.alehei.qrpromax.model.QRConfig
import com.google.zxing.BarcodeFormat
import com.google.zxing.MultiFormatWriter
import com.google.zxing.common.BitMatrix

fun generateQRCode(
    text: String,
    size: Int = 800
): Bitmap {

    val matrix: BitMatrix = MultiFormatWriter().encode(
        text,
        BarcodeFormat.QR_CODE,
        size,
        size
    )

    val bitmap = Bitmap.createBitmap(
        size,
        size,
        Bitmap.Config.RGB_565
    )

    for (x in 0 until size) {
        for (y in 0 until size) {

            bitmap.setPixel(
                x,
                y,
                if (matrix[x, y]) {
                    android.graphics.Color.BLACK
                } else {
                    android.graphics.Color.WHITE
                }
            )
        }
    }

    return bitmap
}


fun generateQRCode(
    context: Context,
    config: QRConfig,
    size: Int = 800
): Bitmap {

    return renderQRCode(
        context = context,
        config = config,
        size = size
    )
}