package com.alehei.qrpromax.ui.screens

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.widget.Toast

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp

import com.alehei.qrpromax.R
import com.alehei.qrpromax.qr.QRScanData
import com.alehei.qrpromax.qr.QRScanType
import com.alehei.qrpromax.qr.connectToWifi
import com.alehei.qrpromax.qr.parseQRContent
import com.alehei.qrpromax.qr.QRNativeAd
import com.alehei.qrpromax.qr.QRAds

@Composable
fun QRScanResultScreen(
    content: String,
    onBack: () -> Unit,
    onCopy: (String) -> Unit,
    onShare: (String) -> Unit,
    onAction: (Intent) -> Unit
) {
    val data = parseQRContent(content)
    val context = androidx.compose.ui.platform.LocalContext.current

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(24.dp),
        verticalArrangement = Arrangement.Center
    ) {

        ScanInfoCard(
            data = data
        )

        Spacer(
            modifier = Modifier.height(20.dp)
        )

        PrimaryScanAction(
            data = data,
            context = context,
            onAction = onAction,
            onCopy = {
                onCopy(
                    buildCopyText(data)
                )
            },
            onShare = {
                onShare(
                    buildCopyText(data)
                )
            }
        )

        Spacer(
            modifier = Modifier.height(12.dp)
        )

        OutlinedButton(
            onClick = onBack,
            modifier = Modifier
                .fillMaxWidth()
                .height(52.dp),
            shape = RoundedCornerShape(28.dp),
            colors = ButtonDefaults.outlinedButtonColors(
                contentColor = MaterialTheme.colorScheme.primary
            )
        ) {
            Text(
                text = "Escanear",
                fontWeight = FontWeight.SemiBold
            )
        }
        
        Spacer(
            modifier = Modifier.height(16.dp)
        )
        
        QRNativeAd(
            adUnitId = QRAds.SCAN_RESULT_NATIVE_AD_UNIT_ID,
            modifier = Modifier.fillMaxWidth()
        )
    }
}


@Composable
private fun ScanInfoCard(
    data: QRScanData
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(
                RoundedCornerShape(20.dp)
            )
            .background(
                MaterialTheme.colorScheme.surfaceVariant
            )
            .border(
                width = 1.dp,
                color = MaterialTheme.colorScheme.outlineVariant,
                shape = RoundedCornerShape(20.dp)
            )
            .padding(20.dp)
    ) {

        Row(
            verticalAlignment = Alignment.CenterVertically
        ) {

            Image(
                painter = painterResource(
                    when (data.type) {

                        QRScanType.URL ->
                            R.drawable.icon_url

                        QRScanType.TEXT ->
                            R.drawable.icon_text

                        QRScanType.WIFI ->
                            R.drawable.icon_wifi

                        QRScanType.CONTACT ->
                            R.drawable.icon_contact

                        QRScanType.EMAIL ->
                            R.drawable.icon_mail

                        QRScanType.PHONE ->
                            R.drawable.icon_phone

                        QRScanType.SMS ->
                            R.drawable.icon_sms

                        QRScanType.LOCATION ->
                            R.drawable.icon_pin
                    }
                ),
                contentDescription = data.title,
                modifier = Modifier.size(28.dp)
            )

            Spacer(
                modifier = Modifier.width(8.dp)
            )

            Text(
                text = data.title,
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )
        }

        Spacer(
            modifier = Modifier.height(16.dp)
        )

        when (data.type) {

            QRScanType.URL -> {

                Text(
                    text = data.value1,
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurface,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            }


            QRScanType.PHONE -> {

                Text(
                    text = data.value1,
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }


            QRScanType.EMAIL -> {

                Text(
                    text = data.value1,
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }


            QRScanType.SMS -> {

                Text(
                    text = data.value1,
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurface
                )

                if (data.value2.isNotEmpty()) {

                    Spacer(
                        modifier = Modifier.height(8.dp)
                    )

                    Text(
                        text = data.value2,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }


            QRScanType.LOCATION -> {

                Text(
                    text = "${data.value1}, ${data.value2}",
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }


            QRScanType.WIFI -> {

                Text(
                    text = "Red: ${data.value1}",
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurface
                )

                if (data.value2.isNotEmpty()) {

                    Spacer(
                        modifier = Modifier.height(8.dp)
                    )

                    Text(
                        text = "Contraseña: ${data.value2}",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                if (data.value3.isNotEmpty()) {

                    Spacer(
                        modifier = Modifier.height(8.dp)
                    )

                    Text(
                        text = "Seguridad: ${data.value3}",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }


            QRScanType.CONTACT -> {

                if (data.subtitle.isNotEmpty()) {

                    Text(
                        text = data.subtitle,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Medium,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                if (data.value1.isNotEmpty()) {

                    Spacer(
                        modifier = Modifier.height(8.dp)
                    )

                    Text(
                        text = "📞 ${data.value1}",
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                if (data.value2.isNotEmpty()) {

                    Spacer(
                        modifier = Modifier.height(8.dp)
                    )

                    Text(
                        text = "📧 ${data.value2}",
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                if (data.value3.isNotEmpty()) {

                    Spacer(
                        modifier = Modifier.height(8.dp)
                    )

                    Text(
                        text = "🏢 ${data.value3}",
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                if (data.value4.isNotEmpty()) {

                    Spacer(
                        modifier = Modifier.height(8.dp)
                    )

                    Text(
                        text = "📍 ${data.value4}",
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                if (data.value5.isNotEmpty()) {

                    Spacer(
                        modifier = Modifier.height(8.dp)
                    )

                    Text(
                        text = "🌐 ${data.value5}",
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
            }


            QRScanType.TEXT -> {

                Text(
                    text = data.value1,
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurface,
                    maxLines = 5,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}


@Composable
private fun PrimaryScanAction(
    data: QRScanData,
    context: Context,
    onAction: (Intent) -> Unit,
    onCopy: () -> Unit,
    onShare: () -> Unit
) {
    Column(
        modifier = Modifier.fillMaxWidth()
    ) {

        when (data.type) {

            QRScanType.URL -> {

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {

                    ScanActionButton(
                        text = "Abrir",
                        onClick = {
                            onAction(
                                Intent(
                                    Intent.ACTION_VIEW,
                                    Uri.parse(data.value1)
                                )
                            )
                        },
                        modifier = Modifier.weight(1f)
                    )

                    ScanActionButton(
                        text = "Copiar",
                        onClick = onCopy,
                        modifier = Modifier.weight(1f)
                    )
                }

                Spacer(
                    modifier = Modifier.height(12.dp)
                )

                ScanActionButton(
                    text = "Compartir",
                    onClick = onShare,
                    modifier = Modifier.fillMaxWidth()
                )
            }


            QRScanType.PHONE -> {

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {

                    ScanActionButton(
                        text = "Llamar",
                        onClick = {
                            onAction(
                                Intent(
                                    Intent.ACTION_DIAL,
                                    Uri.parse(
                                        "tel:${data.value1}"
                                    )
                                )
                            )
                        },
                        modifier = Modifier.weight(1f)
                    )

                    ScanActionButton(
                        text = "SMS",
                        onClick = {
                            onAction(
                                Intent(
                                    Intent.ACTION_SENDTO,
                                    Uri.parse(
                                        "smsto:${data.value1}"
                                    )
                                )
                            )
                        },
                        modifier = Modifier.weight(1f)
                    )
                }

                Spacer(
                    modifier = Modifier.height(12.dp)
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {

                    ScanActionButton(
                        text = "Copiar",
                        onClick = onCopy,
                        modifier = Modifier.weight(1f)
                    )

                    ScanActionButton(
                        text = "Compartir",
                        onClick = onShare,
                        modifier = Modifier.weight(1f)
                    )
                }
            }


            QRScanType.EMAIL -> {

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {

                    ScanActionButton(
                        text = "Enviar email",
                        onClick = {
                            onAction(
                                Intent(
                                    Intent.ACTION_SENDTO,
                                    Uri.parse(
                                        "mailto:${data.value1}"
                                    )
                                )
                            )
                        },
                        modifier = Modifier.weight(1f)
                    )

                    ScanActionButton(
                        text = "Copiar",
                        onClick = onCopy,
                        modifier = Modifier.weight(1f)
                    )
                }

                Spacer(
                    modifier = Modifier.height(12.dp)
                )

                ScanActionButton(
                    text = "Compartir",
                    onClick = onShare,
                    modifier = Modifier.fillMaxWidth()
                )
            }


            QRScanType.SMS -> {

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {

                    ScanActionButton(
                        text = "Enviar SMS",
                        onClick = {
                            onAction(
                                Intent(
                                    Intent.ACTION_SENDTO,
                                    Uri.parse(
                                        "smsto:${data.value1}"
                                    )
                                ).apply {
                                    putExtra(
                                        "sms_body",
                                        data.value2
                                    )
                                }
                            )
                        },
                        modifier = Modifier.weight(1f)
                    )

                    ScanActionButton(
                        text = "Copiar",
                        onClick = onCopy,
                        modifier = Modifier.weight(1f)
                    )
                }

                Spacer(
                    modifier = Modifier.height(12.dp)
                )

                ScanActionButton(
                    text = "Compartir",
                    onClick = onShare,
                    modifier = Modifier.fillMaxWidth()
                )
            }


            QRScanType.LOCATION -> {

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {

                    ScanActionButton(
                        text = "Abrir mapa",
                        onClick = {
                            onAction(
                                Intent(
                                    Intent.ACTION_VIEW,
                                    Uri.parse(
                                        "geo:${data.value1},${data.value2}"
                                    )
                                )
                            )
                        },
                        modifier = Modifier.weight(1f)
                    )

                    ScanActionButton(
                        text = "Copiar",
                        onClick = onCopy,
                        modifier = Modifier.weight(1f)
                    )
                }

                Spacer(
                    modifier = Modifier.height(12.dp)
                )

                ScanActionButton(
                    text = "Compartir",
                    onClick = onShare,
                    modifier = Modifier.fillMaxWidth()
                )
            }


            QRScanType.WIFI -> {

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {

                    ScanActionButton(
                        text = "Wi-Fi",
                        onClick = {

                            val result = connectToWifi(
                                context = context,
                                ssid = data.value1,
                                password = data.value2,
                                security = data.value3
                            )

                            Toast.makeText(
                                context,
                                result,
                                Toast.LENGTH_LONG
                            ).show()
                        },
                        modifier = Modifier.weight(1f)
                    )

                    ScanActionButton(
                        text = "Copiar",
                        onClick = onCopy,
                        modifier = Modifier.weight(1f)
                    )
                }

                Spacer(
                    modifier = Modifier.height(12.dp)
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {

                    ScanActionButton(
                        text = "Ajustes Wi-Fi",
                        onClick = {
                            onAction(
                                Intent(
                                    Settings.ACTION_WIFI_SETTINGS
                                )
                            )
                        },
                        modifier = Modifier.weight(1f)
                    )

                    ScanActionButton(
                        text = "Compartir",
                        onClick = onShare,
                        modifier = Modifier.weight(1f)
                    )
                }
            }


            QRScanType.CONTACT -> {

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {

                    ScanActionButton(
                        text = "Guardar",
                        onClick = {

                            val intent = Intent(
                                Intent.ACTION_INSERT
                            ).apply {

                                type =
                                    "vnd.android.cursor.dir/contact"

                                putExtra(
                                    "name",
                                    data.subtitle
                                )

                                if (data.value1.isNotEmpty()) {
                                    putExtra(
                                        "phone",
                                        data.value1
                                    )
                                }

                                if (data.value2.isNotEmpty()) {
                                    putExtra(
                                        "email",
                                        data.value2
                                    )
                                }

                                if (data.value3.isNotEmpty()) {
                                    putExtra(
                                        "company",
                                        data.value3
                                    )
                                }

                                if (data.value4.isNotEmpty()) {
                                    putExtra(
                                        "address",
                                        data.value4
                                    )
                                }

                                if (data.value5.isNotEmpty()) {
                                    putExtra(
                                        "website",
                                        data.value5
                                    )
                                }
                            }

                            onAction(intent)
                        },
                        modifier = Modifier.weight(1f)
                    )

                    ScanActionButton(
                        text = "Llamar",
                        onClick = {

                            if (data.value1.isNotEmpty()) {

                                onAction(
                                    Intent(
                                        Intent.ACTION_DIAL,
                                        Uri.parse(
                                            "tel:${data.value1}"
                                        )
                                    )
                                )
                            }
                        },
                        modifier = Modifier.weight(1f)
                    )
                }

                Spacer(
                    modifier = Modifier.height(12.dp)
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {

                    ScanActionButton(
                        text = "Enviar email",
                        onClick = {

                            if (data.value2.isNotEmpty()) {

                                onAction(
                                    Intent(
                                        Intent.ACTION_SENDTO,
                                        Uri.parse(
                                            "mailto:${data.value2}"
                                        )
                                    )
                                )
                            }
                        },
                        modifier = Modifier.weight(1f)
                    )

                    ScanActionButton(
                        text = "Copiar",
                        onClick = onCopy,
                        modifier = Modifier.weight(1f)
                    )
                }

                Spacer(
                    modifier = Modifier.height(12.dp)
                )

                ScanActionButton(
                    text = "Compartir",
                    onClick = onShare,
                    modifier = Modifier.fillMaxWidth()
                )
            }


            QRScanType.TEXT -> {

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {

                    ScanActionButton(
                        text = "Copiar",
                        onClick = onCopy,
                        modifier = Modifier.weight(1f)
                    )

                    ScanActionButton(
                        text = "Compartir",
                        onClick = onShare,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }
    }
}


@Composable
private fun ScanActionButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Button(
        onClick = onClick,
        modifier = modifier
            .height(52.dp),
        shape = RoundedCornerShape(28.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = MaterialTheme.colorScheme.primary,
            contentColor = MaterialTheme.colorScheme.onPrimary
        ),
        elevation = ButtonDefaults.buttonElevation(
            defaultElevation = 2.dp,
            pressedElevation = 0.dp
        )
    ) {
        Text(
            text = text,
            fontWeight = FontWeight.SemiBold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}


private fun buildCopyText(
    data: QRScanData
): String {

    return when (data.type) {

        QRScanType.URL -> {
            data.value1
        }

        QRScanType.PHONE -> {
            data.value1
        }

        QRScanType.EMAIL -> {
            data.value1
        }

        QRScanType.SMS -> {

            buildString {

                if (data.value1.isNotEmpty()) {
                    append("Número: ")
                    append(data.value1)
                }

                if (data.value2.isNotEmpty()) {

                    if (isNotEmpty()) {
                        append("\n")
                    }

                    append("Mensaje: ")
                    append(data.value2)
                }
            }
        }

        QRScanType.LOCATION -> {
            "${data.value1}, ${data.value2}"
        }

        QRScanType.WIFI -> {

            buildString {

                if (data.value1.isNotEmpty()) {
                    append("Red: ")
                    append(data.value1)
                }

                if (data.value2.isNotEmpty()) {

                    if (isNotEmpty()) {
                        append("\n")
                    }

                    append("Contraseña: ")
                    append(data.value2)
                }

                if (data.value3.isNotEmpty()) {

                    if (isNotEmpty()) {
                        append("\n")
                    }

                    append("Seguridad: ")
                    append(data.value3)
                }
            }
        }

        QRScanType.CONTACT -> {

            buildString {

                if (data.subtitle.isNotEmpty()) {
                    append(data.subtitle)
                }

                if (data.value1.isNotEmpty()) {

                    if (isNotEmpty()) {
                        append("\n")
                    }

                    append("Teléfono: ")
                    append(data.value1)
                }

                if (data.value2.isNotEmpty()) {

                    if (isNotEmpty()) {
                        append("\n")
                    }

                    append("Email: ")
                    append(data.value2)
                }

                if (data.value3.isNotEmpty()) {

                    if (isNotEmpty()) {
                        append("\n")
                    }

                    append("Empresa: ")
                    append(data.value3)
                }

                if (data.value4.isNotEmpty()) {

                    if (isNotEmpty()) {
                        append("\n")
                    }

                    append("Dirección: ")
                    append(data.value4)
                }

                if (data.value5.isNotEmpty()) {

                    if (isNotEmpty()) {
                        append("\n")
                    }

                    append("Web: ")
                    append(data.value5)
                }
            }
        }

        QRScanType.TEXT -> {
            data.value1
        }
    }
}
