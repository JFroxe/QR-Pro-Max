package com.alehei.qrpromax.qr

import androidx.compose.ui.graphics.Color
import kotlin.math.max
import kotlin.math.min

fun getQRContrast(
    foreground: Color,
    background: Color
): Double {

    val foregroundLuminance = relativeLuminance(foreground)
    val backgroundLuminance = relativeLuminance(background)

    val lighter = max(
        foregroundLuminance,
        backgroundLuminance
    )

    val darker = min(
        foregroundLuminance,
        backgroundLuminance
    )

    return (lighter + 0.05) / (darker + 0.05)
}

private fun relativeLuminance(color: Color): Double {

    fun convert(channel: Float): Double {
        val value = channel.toDouble()

        return if (value <= 0.03928) {
            value / 12.92
        } else {
            Math.pow(
                (value + 0.055) / 1.055,
                2.4
            )
        }
    }

    val r = convert(color.red)
    val g = convert(color.green)
    val b = convert(color.blue)

    return (
        0.2126 * r +
        0.7152 * g +
        0.0722 * b
    )
}

fun hasGoodQRContrast(
    foreground: Color,
    background: Color = Color.White
): Boolean {
    return getQRContrast(
        foreground,
        background
    ) >= 3.0
}