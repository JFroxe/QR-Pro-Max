package com.alehei.qrpromax.ui.theme

import android.app.Activity
import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = BrandMint,
    onPrimary = BrandDeep,
    secondary = BrandSky,
    tertiary = Color(0xFFFFB86B),
    background = Night,
    surface = NightSurface,
    surfaceVariant = Color(0xFF233C43),
    onBackground = Color(0xFFEAF5F4),
    onSurface = Color(0xFFEAF5F4),
    onSurfaceVariant = Color(0xFFB8CECC)
)

private val LightColorScheme = lightColorScheme(
    primary = BrandTeal,
    onPrimary = Color.White,
    secondary = BrandSky,
    tertiary = Color(0xFFE58A2B),
    background = Mist,
    surface = Color.White,
    surfaceVariant = Color(0xFFE4EEEE),
    onBackground = Ink,
    onSurface = Ink,
    onSurfaceVariant = Color(0xFF5E7478)
)

@Composable
fun QRProMaxTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }

        darkTheme -> DarkColorScheme
        else -> LightColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}