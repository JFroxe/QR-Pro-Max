package com.alehei.qrpromax.model

enum class ScannerStyle {
    CLASSIC,
    ROUNDED,
    FLOWER,
    LINES,
    LITE,
    HANDS,
    STARS,
    MINECRAFT,
    SCAN_HERE,
    VECTORS
}