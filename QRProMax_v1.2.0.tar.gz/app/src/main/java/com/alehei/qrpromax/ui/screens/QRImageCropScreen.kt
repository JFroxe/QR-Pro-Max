package com.alehei.qrpromax.ui.screens

import android.graphics.Bitmap
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import kotlin.math.max
import kotlin.math.min

@Composable
fun QRImageCropScreen(
    bitmap: Bitmap,
    onDismiss: () -> Unit,
    onCropAndRead: (Bitmap) -> Boolean
) {
    BackHandler { onDismiss() }

    var imageBounds by remember(bitmap) { mutableStateOf(Rect.Zero) }
    var cropRect by remember(bitmap) { mutableStateOf(Rect.Zero) }
    var activeHandle by remember { mutableStateOf<Handle?>(null) }
    var draggingCrop by remember { mutableStateOf(false) }
    var gestureStartPosition by remember { mutableStateOf(Offset.Zero) }
    var gestureStartRect by remember { mutableStateOf(Rect.Zero) }

    val imageBitmap = remember(bitmap) { bitmap.asImageBitmap() }

    val canvasModifier = Modifier
        .fillMaxSize()
        .onSizeChanged { size ->
            if (bitmap.width <= 0 || bitmap.height <= 0) return@onSizeChanged

            val bitmapWidth = bitmap.width.toFloat()
            val bitmapHeight = bitmap.height.toFloat()
            val scale = min(
                size.width.toFloat() / bitmapWidth,
                size.height.toFloat() / bitmapHeight
            )

            val displayedWidth = bitmapWidth * scale
            val displayedHeight = bitmapHeight * scale
            val left = (size.width - displayedWidth) / 2f
            val top = (size.height - displayedHeight) / 2f

            imageBounds = Rect(
                left,
                top,
                left + displayedWidth,
                top + displayedHeight
            )
        }
        .pointerInput(Unit) {
            detectDragGestures(
                onDragStart = { position ->
                    gestureStartPosition = position
                    gestureStartRect = cropRect

                    val detectedHandle = detectHandle(position, cropRect)
                    activeHandle = detectedHandle
                    draggingCrop =
                        detectedHandle == null && cropRect.contains(position)
                },
                onDrag = { change, _ ->
                    change.consume()

                    val totalDrag = change.position - gestureStartPosition

                    when {
                        activeHandle != null -> {
                            cropRect = resizeCropRect(
                                rect = gestureStartRect,
                                handle = activeHandle!!,
                                drag = totalDrag,
                                bounds = imageBounds
                            )
                        }

                        draggingCrop -> {
                            cropRect = moveCropRect(
                                rect = gestureStartRect,
                                drag = totalDrag,
                                bounds = imageBounds
                            )
                        }
                    }
                },
                onDragEnd = {
                    activeHandle = null
                    draggingCrop = false
                    gestureStartPosition = Offset.Zero
                    gestureStartRect = Rect.Zero
                },
                onDragCancel = {
                    activeHandle = null
                    draggingCrop = false
                    gestureStartPosition = Offset.Zero
                    gestureStartRect = Rect.Zero
                }
            )
        }

    LaunchedEffect(imageBounds) {
        if (
            cropRect == Rect.Zero &&
            imageBounds.width > 0f &&
            imageBounds.height > 0f
        ) {
            val cropSize = min(
                imageBounds.width,
                imageBounds.height
            ) * 0.70f

            val cropLeft =
                imageBounds.left +
                    (imageBounds.width - cropSize) / 2f

            val cropTop =
                imageBounds.top +
                    (imageBounds.height - cropSize) / 2f

            cropRect = Rect(
                cropLeft,
                cropTop,
                cropLeft + cropSize,
                cropTop + cropSize
            )
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
    ) {
        Image(
            bitmap = imageBitmap,
            contentDescription = null,
            contentScale = ContentScale.Fit,
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black)
        )

        Canvas(modifier = canvasModifier) {
            if (
                imageBounds.width <= 0f ||
                imageBounds.height <= 0f ||
                cropRect.width <= 0f ||
                cropRect.height <= 0f
            ) {
                return@Canvas
            }

            drawRect(
                color = Color.Black.copy(alpha = 0.58f),
                topLeft = Offset(imageBounds.left, imageBounds.top),
                size = androidx.compose.ui.geometry.Size(
                    imageBounds.width,
                    cropRect.top - imageBounds.top
                )
            )

            drawRect(
                color = Color.Black.copy(alpha = 0.58f),
                topLeft = Offset(imageBounds.left, cropRect.bottom),
                size = androidx.compose.ui.geometry.Size(
                    imageBounds.width,
                    imageBounds.bottom - cropRect.bottom
                )
            )

            drawRect(
                color = Color.Black.copy(alpha = 0.58f),
                topLeft = Offset(imageBounds.left, cropRect.top),
                size = androidx.compose.ui.geometry.Size(
                    cropRect.left - imageBounds.left,
                    cropRect.height
                )
            )

            drawRect(
                color = Color.Black.copy(alpha = 0.58f),
                topLeft = Offset(cropRect.right, cropRect.top),
                size = androidx.compose.ui.geometry.Size(
                    imageBounds.right - cropRect.right,
                    cropRect.height
                )
            )

            drawRect(
                color = Color.White.copy(alpha = 0.90f),
                topLeft = Offset(cropRect.left, cropRect.top),
                size = androidx.compose.ui.geometry.Size(
                    cropRect.width,
                    cropRect.height
                ),
                style = androidx.compose.ui.graphics.drawscope.Stroke(width = 2f)
            )

            val thirdWidth = cropRect.width / 3f
            val thirdHeight = cropRect.height / 3f

            drawLine(
                color = Color.White.copy(alpha = 0.28f),
                start = Offset(cropRect.left + thirdWidth, cropRect.top),
                end = Offset(cropRect.left + thirdWidth, cropRect.bottom),
                strokeWidth = 1f
            )

            drawLine(
                color = Color.White.copy(alpha = 0.28f),
                start = Offset(cropRect.left + thirdWidth * 2f, cropRect.top),
                end = Offset(cropRect.left + thirdWidth * 2f, cropRect.bottom),
                strokeWidth = 1f
            )

            drawLine(
                color = Color.White.copy(alpha = 0.28f),
                start = Offset(cropRect.left, cropRect.top + thirdHeight),
                end = Offset(cropRect.right, cropRect.top + thirdHeight),
                strokeWidth = 1f
            )

            drawLine(
                color = Color.White.copy(alpha = 0.28f),
                start = Offset(cropRect.left, cropRect.top + thirdHeight * 2f),
                end = Offset(cropRect.right, cropRect.top + thirdHeight * 2f),
                strokeWidth = 1f
            )

            val cornerLength = 34f
            val cornerWidth = 7f

            drawCorner(
                canvas = this,
                position = Offset(cropRect.left, cropRect.top),
                horizontalDirection = 1f,
                verticalDirection = 1f,
                length = cornerLength,
                strokeWidth = cornerWidth
            )

            drawCorner(
                canvas = this,
                position = Offset(cropRect.right, cropRect.top),
                horizontalDirection = -1f,
                verticalDirection = 1f,
                length = cornerLength,
                strokeWidth = cornerWidth
            )

            drawCorner(
                canvas = this,
                position = Offset(cropRect.left, cropRect.bottom),
                horizontalDirection = 1f,
                verticalDirection = -1f,
                length = cornerLength,
                strokeWidth = cornerWidth
            )

            drawCorner(
                canvas = this,
                position = Offset(cropRect.right, cropRect.bottom),
                horizontalDirection = -1f,
                verticalDirection = -1f,
                length = cornerLength,
                strokeWidth = cornerWidth
            )
        }

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(64.dp)
                .background(Color.Black.copy(alpha = 0.55f))
                .align(Alignment.TopCenter)
        ) {
            IconButton(
                onClick = onDismiss,
                modifier = Modifier.align(Alignment.CenterStart)
            ) {
                Icon(
                    imageVector = Icons.Default.Close,
                    contentDescription = "Cancelar",
                    tint = Color.White
                )
            }

            Text(
                text = "Ajustar QR",
                color = Color.White,
                modifier = Modifier.align(Alignment.Center)
            )

            IconButton(
                onClick = {
                    if (
                        cropRect.width > 0f &&
                        cropRect.height > 0f &&
                        imageBounds.width > 0f &&
                        imageBounds.height > 0f
                    ) {
                        val croppedBitmap = createCroppedBitmap(
                            bitmap = bitmap,
                            cropRect = cropRect,
                            imageBounds = imageBounds
                        )

                        onCropAndRead(croppedBitmap)
                    }
                },
                modifier = Modifier.align(Alignment.CenterEnd)
            ) {
                Icon(
                    imageVector = Icons.Default.Check,
                    contentDescription = "Aceptar",
                    tint = Color.White
                )
            }
        }

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(92.dp)
                .background(Color.Black.copy(alpha = 0.55f))
                .align(Alignment.BottomCenter)
        ) {
            Text(
                text = "Coloca el QR dentro del marco",
                color = Color.White,
                modifier = Modifier.align(Alignment.Center)
            )
        }
    }
}

private enum class Handle {
    TOP_LEFT,
    TOP_RIGHT,
    BOTTOM_LEFT,
    BOTTOM_RIGHT
}

private fun detectHandle(
    position: Offset,
    rect: Rect
): Handle? {
    val touchRadius = 65f

    val handles = listOf(
        Handle.TOP_LEFT to Offset(rect.left, rect.top),
        Handle.TOP_RIGHT to Offset(rect.right, rect.top),
        Handle.BOTTOM_LEFT to Offset(rect.left, rect.bottom),
        Handle.BOTTOM_RIGHT to Offset(rect.right, rect.bottom)
    )

    handles.forEach { (handle, point) ->
        val dx = position.x - point.x
        val dy = position.y - point.y

        if (dx * dx + dy * dy <= touchRadius * touchRadius) {
            return handle
        }
    }

    return null
}

private fun resizeCropRect(
    rect: Rect,
    handle: Handle,
    drag: Offset,
    bounds: Rect
): Rect {
    val minSize = 120f

    return when (handle) {
        Handle.TOP_LEFT -> {
            val fixedX = rect.right
            val fixedY = rect.bottom
            val requestedLeft = rect.left + drag.x
            val requestedTop = rect.top + drag.y

            val maxSize = min(
                fixedX - bounds.left,
                fixedY - bounds.top
            )

            val size = max(
                minSize,
                min(
                    maxSize,
                    max(
                        fixedX - requestedLeft,
                        fixedY - requestedTop
                    )
                )
            )

            Rect(
                fixedX - size,
                fixedY - size,
                fixedX,
                fixedY
            )
        }

        Handle.TOP_RIGHT -> {
            val fixedX = rect.left
            val fixedY = rect.bottom
            val requestedRight = rect.right + drag.x
            val requestedTop = rect.top + drag.y

            val maxSize = min(
                bounds.right - fixedX,
                fixedY - bounds.top
            )

            val size = max(
                minSize,
                min(
                    maxSize,
                    max(
                        requestedRight - fixedX,
                        fixedY - requestedTop
                    )
                )
            )

            Rect(
                fixedX,
                fixedY - size,
                fixedX + size,
                fixedY
            )
        }

        Handle.BOTTOM_LEFT -> {
            val fixedX = rect.right
            val fixedY = rect.top
            val requestedLeft = rect.left + drag.x
            val requestedBottom = rect.bottom + drag.y

            val maxSize = min(
                fixedX - bounds.left,
                bounds.bottom - fixedY
            )

            val size = max(
                minSize,
                min(
                    maxSize,
                    max(
                        fixedX - requestedLeft,
                        requestedBottom - fixedY
                    )
                )
            )

            Rect(
                fixedX - size,
                fixedY,
                fixedX,
                fixedY + size
            )
        }

        Handle.BOTTOM_RIGHT -> {
            val fixedX = rect.left
            val fixedY = rect.top
            val requestedRight = rect.right + drag.x
            val requestedBottom = rect.bottom + drag.y

            val maxSize = min(
                bounds.right - fixedX,
                bounds.bottom - fixedY
            )

            val size = max(
                minSize,
                min(
                    maxSize,
                    max(
                        requestedRight - fixedX,
                        requestedBottom - fixedY
                    )
                )
            )

            Rect(
                fixedX,
                fixedY,
                fixedX + size,
                fixedY + size
            )
        }
    }
}

private fun moveCropRect(
    rect: Rect,
    drag: Offset,
    bounds: Rect
): Rect {
    val width = rect.width
    val height = rect.height

    var newLeft = rect.left + drag.x
    var newTop = rect.top + drag.y

    newLeft = newLeft.coerceIn(
        bounds.left,
        bounds.right - width
    )

    newTop = newTop.coerceIn(
        bounds.top,
        bounds.bottom - height
    )

    return Rect(
        newLeft,
        newTop,
        newLeft + width,
        newTop + height
    )
}

private fun createCroppedBitmap(
    bitmap: Bitmap,
    cropRect: Rect,
    imageBounds: Rect
): Bitmap {
    val scaleX =
        bitmap.width.toFloat() / imageBounds.width

    val scaleY =
        bitmap.height.toFloat() / imageBounds.height

    var left =
        ((cropRect.left - imageBounds.left) * scaleX).toInt()

    var top =
        ((cropRect.top - imageBounds.top) * scaleY).toInt()

    var right =
        ((cropRect.right - imageBounds.left) * scaleX).toInt()

    var bottom =
        ((cropRect.bottom - imageBounds.top) * scaleY).toInt()

    left = left.coerceIn(0, bitmap.width - 1)
    top = top.coerceIn(0, bitmap.height - 1)
    right = right.coerceIn(left + 1, bitmap.width)
    bottom = bottom.coerceIn(top + 1, bitmap.height)

    return Bitmap.createBitmap(
        bitmap,
        left,
        top,
        right - left,
        bottom - top
    )
}

private fun drawCorner(
    canvas: androidx.compose.ui.graphics.drawscope.DrawScope,
    position: Offset,
    horizontalDirection: Float,
    verticalDirection: Float,
    length: Float,
    strokeWidth: Float
) {
    canvas.drawLine(
        color = Color.White,
        start = position,
        end = Offset(
            position.x + length * horizontalDirection,
            position.y
        ),
        strokeWidth = strokeWidth
    )

    canvas.drawLine(
        color = Color.White,
        start = position,
        end = Offset(
            position.x,
            position.y + length * verticalDirection
        ),
        strokeWidth = strokeWidth
    )

    canvas.drawCircle(
        color = Color.White,
        radius = strokeWidth / 2f,
        center = position
    )
}
