package com.alehei.qrpromax.model

import androidx.compose.ui.graphics.Color
import com.alehei.qrpromax.model.ScannerStyle

data class QRConfig(
    val type: QRType = QRType.URL,
    val content: String = "",

    val url: String = "",
    val text: String = "",
    val phone: String = "",

    val smsNumber: String = "",
    val smsMessage: String = "",

    val latitude: String = "",
    val longitude: String = "",
    val locationName: String = "",

    // Wi-Fi
    val wifiName: String = "",
    val wifiPassword: String = "",
    val wifiSecurity: String = "WPA",
    val wifiHidden: Boolean = false,

    // Contacto
    val contactFirstName: String = "",
    val contactLastName: String = "",
    val contactPhone: String = "",
    val contactEmail: String = "",
    val contactCompany: String = "",
    val contactAddress: String = "",
    val contactWebsite: String = "",

    // Email
    val emailAddress: String = "",
    val emailSubject: String = "",
    val emailMessage: String = "",

    val foregroundColor: Color = Color.Black,
    val backgroundColor: Color = Color.White,

    val moduleStyle: ModuleStyle = ModuleStyle.SQUARE,
    
    val eyeStyle: EyeStyle = EyeStyle.SQUARE,    
    val errorCorrection: ErrorCorrection = ErrorCorrection.MEDIUM,
    
    val logoEnabled: Boolean = false,
    val logoResId: Int? = null,
    val logoAssetName: String? = null,
    val logoSize: Float = 0.20f,
    
    val scannerStyle: ScannerStyle = ScannerStyle.CLASSIC
)


enum class ModuleStyle(val fileName: String) {
    SQUARE("square"),
    ROUNDED("rounded"),
    DOTS("dots"),
    HEART("heart"),
    STAR("star"),
    TRIANGLE("triangle"),
    HEXAGON("hexagon"),
    CLOVER("clover"),
    PIECE("piece"),
    MSG("msg"),
    LIKE("like")
}

enum class EyeStyle(val fileName: String) {
    SQUARE("square"),
    ROUNDED("rounded"),
    CIRCLE("circle"),
    OCTAGON("octagon"),
    FLOWER("flower"),
    BOW("bow"),
    PUZZLE("puzzle"),
    DROP("drop")
}

enum class ErrorCorrection {
    LOW,
    MEDIUM,
    QUARTILE,
    HIGH
}