package com.alehei.qrpromax.qr

import android.graphics.Bitmap
import com.google.zxing.BinaryBitmap
import com.google.zxing.BarcodeFormat
import com.google.zxing.DecodeHintType
import com.google.zxing.MultiFormatReader
import com.google.zxing.RGBLuminanceSource
import com.google.zxing.common.HybridBinarizer

fun verifyQRCode(
    bitmap: Bitmap,
    expectedContent: String
): Boolean {

    val sizes = listOf(
        bitmap.width,
        400,
        250,
        160
    )

    var successfulTests = 0

    for (size in sizes.distinct()) {

        val testBitmap = if (
            bitmap.width == size &&
            bitmap.height == size
        ) {
            bitmap
        } else {
            Bitmap.createScaledBitmap(
                bitmap,
                size,
                size,
                true
            )
        }

        if (decodeQRCode(testBitmap, expectedContent)) {
            successfulTests++
        }
    }

    /*
     * Exigimos que el QR funcione en al menos
     * 3 de las pruebas.
     *
     * Esto evita considerar "válido" un diseño
     * que solamente funciona en tamaño grande.
     */
    return successfulTests >= 3
}

private fun decodeQRCode(
    bitmap: Bitmap,
    expectedContent: String
): Boolean {

    return try {

        val width = bitmap.width
        val height = bitmap.height

        val pixels = IntArray(width * height)

        bitmap.getPixels(
            pixels,
            0,
            width,
            0,
            0,
            width,
            height
        )

        val source = RGBLuminanceSource(
            width,
            height,
            pixels
        )

        val binaryBitmap = BinaryBitmap(
            HybridBinarizer(source)
        )

        val hints = hashMapOf<DecodeHintType, Any>()

        hints[DecodeHintType.TRY_HARDER] = true
        hints[DecodeHintType.POSSIBLE_FORMATS] =
            listOf(BarcodeFormat.QR_CODE)

        val result = MultiFormatReader().decode(
            binaryBitmap,
            hints
        )

        result.text == expectedContent

    } catch (_: Exception) {
        false
    }
}