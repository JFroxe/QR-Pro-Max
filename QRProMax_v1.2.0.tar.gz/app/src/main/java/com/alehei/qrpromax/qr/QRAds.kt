package com.alehei.qrpromax.qr

import android.app.Activity
import android.content.Context
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.appopen.AppOpenAd
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback

object QRAds {

    // APP OPEN
    const val APP_OPEN_AD_UNIT_ID =
        "ca-app-pub-2226991833099162/8660726202"

    // INTERSTITIAL
    const val INTERSTITIAL_AD_UNIT_ID =
        "ca-app-pub-2226991833099162/4758983526"

    // NATIVE ADVANCED
    const val CONFIG_NATIVE_AD_UNIT_ID =
        "ca-app-pub-2226991833099162/6041829939"

    // BANNER
    const val RESULT_BANNER_AD_UNIT_ID =
        "ca-app-pub-2226991833099162/3653112969"

    // NATIVE - RESULTADO DE ESCANEO
    const val SCAN_RESULT_NATIVE_AD_UNIT_ID =
        "ca-app-pub-2226991833099162/7453226366"

    // REWARDED - EXPORT.
    const val EXPORT_2340_REWARDED_AD_UNIT_ID =
        "ca-app-pub-2226991833099162/3514863236"

    const val EXPORT_4240_REWARDED_AD_UNIT_ID =
        "ca-app-pub-2226991833099162/9812678276"
    
    
    // =========================================================
    // APP OPEN
    // =========================================================

    private var appOpenAd: AppOpenAd? = null
    private var isLoadingAppOpen = false
    private var isShowingAppOpen = false

    private var pendingActivity: Activity? = null
    private var pendingShow = false


    // =========================================================
    // INTERSTITIAL
    // =========================================================

    private var interstitialAd: InterstitialAd? = null
    private var isLoadingInterstitial = false
    private var isShowingInterstitial = false


    // =========================================================
    // APP OPEN - CARGAR
    // =========================================================

    fun loadAppOpenAd(context: Context) {

        if (
            appOpenAd != null ||
            isLoadingAppOpen
        ) {
            return
        }

        isLoadingAppOpen = true

        val request =
            AdRequest.Builder().build()

        AppOpenAd.load(
            context,
            APP_OPEN_AD_UNIT_ID,
            request,
            object : AppOpenAd.AppOpenAdLoadCallback() {

                override fun onAdLoaded(
                    ad: AppOpenAd
                ) {

                    appOpenAd = ad
                    isLoadingAppOpen = false

                    if (pendingShow) {

                        val activity =
                            pendingActivity

                        pendingShow = false
                        pendingActivity = null

                        if (
                            activity != null &&
                            !activity.isFinishing
                        ) {
                            showLoadedAppOpenAd(
                                activity
                            )
                        }
                    }
                }

                override fun onAdFailedToLoad(
                    error: LoadAdError
                ) {

                    appOpenAd = null
                    isLoadingAppOpen = false

                    pendingShow = false
                    pendingActivity = null
                }
            }
        )
    }


    // =========================================================
    // APP OPEN - MOSTRAR
    // =========================================================

    fun showAppOpenAd(
        activity: Activity,
        onFinished: () -> Unit = {}
    ) {

        if (isShowingAppOpen) {
            onFinished()
            return
        }

        val ad = appOpenAd

        if (ad == null) {

            pendingActivity = activity
            pendingShow = true

            loadAppOpenAd(activity)

            return
        }

        showLoadedAppOpenAd(
            activity = activity,
            onFinished = onFinished
        )
    }


    private fun showLoadedAppOpenAd(
        activity: Activity,
        onFinished: () -> Unit = {}
    ) {

        if (isShowingAppOpen) {
            onFinished()
            return
        }

        if (activity.isFinishing) {
            onFinished()
            return
        }

        val ad = appOpenAd

        if (ad == null) {
            onFinished()
            return
        }

        isShowingAppOpen = true
        appOpenAd = null

        ad.fullScreenContentCallback =
            object :
                com.google.android.gms.ads.FullScreenContentCallback() {

                override fun
                    onAdDismissedFullScreenContent() {

                    isShowingAppOpen = false

                    loadAppOpenAd(activity)

                    onFinished()
                }

                override fun
                    onAdFailedToShowFullScreenContent(
                        error: AdError
                    ) {

                    isShowingAppOpen = false
                    appOpenAd = null

                    loadAppOpenAd(activity)

                    onFinished()
                }

                override fun
                    onAdShowedFullScreenContent() {
                    // Anuncio visible.
                }
            }

        ad.show(activity)
    }


    // =========================================================
    // INTERSTITIAL - CARGAR
    // =========================================================

    fun loadInterstitialAd(
        context: Context
    ) {

        if (
            interstitialAd != null ||
            isLoadingInterstitial ||
            isShowingInterstitial
        ) {
            return
        }

        isLoadingInterstitial = true

        val request =
            AdRequest.Builder().build()

        InterstitialAd.load(
            context,
            INTERSTITIAL_AD_UNIT_ID,
            request,
            object : InterstitialAdLoadCallback() {

                override fun onAdLoaded(
                    ad: InterstitialAd
                ) {

                    interstitialAd = ad
                    isLoadingInterstitial = false
                }

                override fun onAdFailedToLoad(
                    error: LoadAdError
                ) {

                    interstitialAd = null
                    isLoadingInterstitial = false
                }
            }
        )
    }


    // =========================================================
    // INTERSTITIAL - MOSTRAR
    // =========================================================

    fun showInterstitialAd(
        activity: Activity,
        onFinished: () -> Unit = {}
    ) {

        if (isShowingInterstitial) {
            onFinished()
            return
        }

        val ad = interstitialAd

        if (ad == null) {

            loadInterstitialAd(activity)

            onFinished()

            return
        }

        isShowingInterstitial = true
        interstitialAd = null

        ad.fullScreenContentCallback =
            object :
                com.google.android.gms.ads.FullScreenContentCallback() {

                override fun
                    onAdDismissedFullScreenContent() {

                    isShowingInterstitial = false

                    loadInterstitialAd(activity)

                    onFinished()
                }

                override fun
                    onAdFailedToShowFullScreenContent(
                        error: AdError
                    ) {

                    isShowingInterstitial = false
                    interstitialAd = null

                    loadInterstitialAd(activity)

                    onFinished()
                }

                override fun
                    onAdShowedFullScreenContent() {
                    // Anuncio visible.
                }
            }

        ad.show(activity)
    }

    fun showResolutionRewardedAd(
        activity: Activity,
        adUnitId: String,
        onRewarded: () -> Unit,
        onUnavailable: () -> Unit
    ) {
        if (activity.isFinishing || activity.isDestroyed) {
            onUnavailable()
            return
        }

        RewardedAd.load(
            activity,
            adUnitId,
            AdRequest.Builder().build(),
            object : RewardedAdLoadCallback() {
                override fun onAdLoaded(ad: RewardedAd) {
                    if (activity.isFinishing || activity.isDestroyed) {
                        onUnavailable()
                        return
                    }

                    var callbackDelivered = false

                    fun reportUnavailable() {
                        if (!callbackDelivered) {
                            callbackDelivered = true
                            onUnavailable()
                        }
                    }

                    ad.fullScreenContentCallback =
                        object : FullScreenContentCallback() {
                            override fun onAdDismissedFullScreenContent() {
                                reportUnavailable()
                            }

                            override fun onAdFailedToShowFullScreenContent(
                                error: AdError
                            ) {
                                reportUnavailable()
                            }
                        }

                    ad.show(activity) {
                        if (!callbackDelivered) {
                            callbackDelivered = true
                            onRewarded()
                        }
                    }
                }

                override fun onAdFailedToLoad(error: LoadAdError) {
                    onUnavailable()
                }
            }
        )
    }
}